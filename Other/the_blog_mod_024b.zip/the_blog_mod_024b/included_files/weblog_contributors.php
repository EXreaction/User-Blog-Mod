<?php
/***************************************************************************
 *                          weblog_contributors.php
 *                       -----------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   
 *   Maintained by: TheBlogMod.com Community
 *   Support: Visit www.TheBlogMod.com
 *
 *   $Id: weblog_contributors.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

//	
// Start initial var setup
//
if( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) || isset($HTTP_POST_VARS[POST_WEBLOG_URL]) )
{
	$weblog_id = ( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) ) ? intval($HTTP_GET_VARS[POST_WEBLOG_URL]) : intval($HTTP_POST_VARS[POST_WEBLOG_URL]);
}
else
{
	$weblog_id = 0;
}

$user_exists = FALSE;

//
// Make sure that the weblog exists
//
if ( $weblog_id )
{
	$sql = "SELECT w.* FROM " . WEBLOGS_TABLE . " w WHERE w.weblog_id = $weblog_id";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't obtain weblogs information.", "", __LINE__, __FILE__, $sql);
	}

	if ( !($weblog_data = $db->sql_fetchrow($result)) )
	{
		message_die(GENERAL_ERROR, 'Weblog_not_exist');
	}
}
else
{
	message_die(GENERAL_MESSAGE, 'Weblog_not_exist');
}

if ( $weblog_data['deleted'] )
{
	message_die(GENERAL_ERROR, sprintf($lang['Weblog_deactivated'], $weblog_data['weblog_name']));
}

$template_dir = get_template_dir ($weblog_data['template_id']);

//
// Check to see if the owner added a user to the blocked list
//
if ( $userdata['user_weblog'] == $weblog_id && isset($HTTP_POST_VARS['addcontributor']) )
{
	$contributor_user = htmlspecialchars($HTTP_POST_VARS['contributoruser']);

	// Now, attempt to find a user with such a username
	$sql = "SELECT username, user_id FROM " . USERS_TABLE . " WHERE username = '" . str_replace("\'", "''", $contributor_user) . "'";
	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't obtain username information.", "", __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$user_id = $row['user_id'];
	}
	else
	{
		weblog_message_die(GENERAL_ERROR, $lang['User_not_exist'] . '<br /><br />' . sprintf($lang['Click_return_contributors'], '<a href="' . append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>'));
	}

	// See if that contributor hasn't already been added
	$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE user_id = $user_id AND weblog_id = $weblog_id";
	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't obtain contributor information.", "", __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		weblog_message_die (GENERAL_ERROR, $lang['Contributor_already_added'] . '<br /><br />' . sprintf($lang['Click_return_contributors'], '<a href="' . append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>'));
	}

	if ( $contributor_user == $userdata['username'] )
	{
		weblog_message_die (GENERAL_ERROR, $lang['No_contributor_owner'] . '<br /><br />' . sprintf($lang['Click_return_contributors'], '<a href="' . append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>'));
	}

	if ( $contributor_user == ANONYMOUS )
	{
		weblog_message_die (GENERAL_ERROR, $lang['No_guest_contributors'] . '<br /><br />' . sprintf($lang['Click_return_contributors'], '<a href="' . append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>'));
	}

	// Now insert new user to contributor table
	$sql = "INSERT INTO " . WEBLOG_CONTRIBUTORS_TABLE . " (user_id, weblog_id) VALUES ($user_id, $weblog_id)";
	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't obtain insert contributor information.", "", __LINE__, __FILE__, $sql);
	}

	weblog_message_die (GENERAL_MESSAGE, $lang['Contributor_added'] . '<br /><br />' . sprintf($lang['Click_return_contributors'], '<a href="' . append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>'));
}
else if ( $userdata['user_weblog'] == $weblog_id && isset($HTTP_POST_VARS['removecontributor']) )
{
	$contributor_user = htmlspecialchars($HTTP_POST_VARS['contributoruser']);

	// Now, attempt to find a user with such a username
	$sql = "SELECT username, user_id FROM " . USERS_TABLE . " WHERE username = '" . str_replace("\'", "''", $contributor_user) . "'";
	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't obtain username information.", "", __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$user_id = $row['user_id'];
	}
	else
	{
		weblog_message_die(GENERAL_ERROR, $lang['User_not_exist'] . '<br /><br />' . sprintf($lang['Click_return_contributors'], '<a href="' . append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>'));
	}

	if ( $userdata['username'] == $contributor_user )
	{
		weblog_message_die(GENERAL_ERROR, $lang['User_no_remove_selfcontributor']);
	}

	// Now, attempt to find a user that is a friend of the owner
	$sql = "SELECT user_id FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE weblog_id = $weblog_id";
	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't obtain contributor information.", "", __LINE__, __FILE__, $sql);
	}

	if (!( $row = $db->sql_fetchrow($result) ))
	{
		weblog_message_die(GENERAL_ERROR, $lang['User_not_contributor'] . '<br /><br />' . sprintf($lang['Click_return_contributors'], '<a href="' . append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>'));
	}

	// Remove the contributor
	$sql = "DELETE FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE user_id = $user_id AND weblog_id = $weblog_id";
	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't delete contributor information.", "", __LINE__, __FILE__, $sql);
	}

	weblog_message_die (GENERAL_MESSAGE, $lang['Contributor_removed'] . '<br /><br />' . sprintf($lang['Click_return_contributors'], '<a href="' . append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>') );
}

$page_title = $weblog_data['weblog_name'] . ' :: ' . $lang['Contributors'];
//
// Start output of page
//
use_weblog_header ( $weblog_data, $template_dir );

$template->set_filenames(array(
	'body' => '../../weblogs/templates/' . $template_dir . '/weblog_contributors_body.htm')
);

if ( $weblog_data['font'] == '0' )
	$font = 'Arial';
else if ( $weblog_data['font'] == '1' )
	$font = 'Comic Sans MS';
else if ( $weblog_data['font'] == '2' )
	$font = 'Courier New';
else if ( $weblog_data['font'] == '3' )
	$font = 'Georgia';
else if ( $weblog_data['font'] == '4' )
	$font = 'Verdana';
else if ( $weblog_data['font'] == '5' )
	$font = 'Times New Roman';
else if ( $weblog_data['font'] == '6' )
	$font = 'Trebuchet';
else
	$font = 'Verdana';

$template->assign_vars(array(
	'BACKGROUND_COLOR' => $weblog_data['background_color'],
	'ENTRY_BG_COLOR' => $weblog_data['entry_bg_color'],
	'BORDER_COLOR' => $weblog_data['border_color'],
	'BACKGROUND_IMAGE' => $weblog_data['background_image'],
	'BACKGROUND_IMAGE_FIXED' => ( $weblog_data['background_image_fixed'] ) ? 'fixed' : 'scroll',
	'BACKGROUND_REPEAT' => $weblog_data['tile_bg'],
	'BACKGROUND_POSITION' => $weblog_data['bg_ypos'] . ' ' . $weblog_data['bg_xpos'],
	'SB_FACE_COLOR' => $weblog_data['sb_face_color'],
	'SB_HIGHLIGHT_COLOR' => $weblog_data['sb_highlight_color'],
	'SB_SHADOW_COLOR' => $weblog_data['sb_shadow_color'],
	'SB_3DLIGHT_COLOR' => $weblog_data['sb_3dlight_color'],
	'SB_ARROW_COLOR' => $weblog_data['sb_arrow_color'],
	'SB_TRACK_COLOR' => $weblog_data['sb_track_color'],
	'SB_DARKSHADOW_COLOR' => $weblog_data['sb_darkshadow_color'],
	'FONT' => $font,
	'FONT_COLOR' => $weblog_data['font_color'],
	'FONT_SIZE' => $weblog_data['font_size'],
	'NORMAL_LINK_COLOR' => $weblog_data['normal_link_color'],
	'NORMAL_LINK_UNDERLINED' => ( $weblog_data['normal_link_underline'] ) ? 'underline' : 'none',
	'ACTIVE_LINK_COLOR' => $weblog_data['active_link_color'],
	'ACTIVE_LINK_UNDERLINED' => ( $weblog_data['active_link_underline'] ) ? 'underline': 'none',
	'HOVER_LINK_COLOR' => $weblog_data['hover_link_color'],
	'HOVER_LINK_UNDERLINED' => ( $weblog_data['hover_link_underline'] ) ? 'underline': 'none',
	'VISITED_LINK_COLOR' => $weblog_data['visited_link_color'],
	'VISITED_LINK_UNDERLINED' => ( $weblog_data['visited_link_underline'] ) ? 'underline': 'none',
	'WEBLOG_TITLE_COLOR' => $weblog_data['weblog_title_color'],
	'WEBLOG_TITLE_FONT_SIZE' => $weblog_data['weblog_title_font_size'],
	'ENTRY_TITLE_COLOR' => $weblog_data['entry_title_color'],
	'ENTRY_TITLE_FONT_SIZE' => $weblog_data['entry_title_font_size'],
	'DATE_TIME_COLOR' => $weblog_data['date_time_color'],
	'DATE_TIME_FONT_SIZE' => $weblog_data['date_time_font_size'],
	'BLOCK_TITLE_COLOR' => $weblog_data['block_title_color'],
	'BLOCK_TITLE_FONT_SIZE' => $weblog_data['block_title_font_size'],
	'BLOCK_BG_COLOR' => $weblog_data['block_bg_color'],
	'BLOCK_BORDER_COLOR' => $weblog_data['block_border_color'])
);

//
// Parse the header
//
// $template->pparse('header');

//
// Find the users that are contributors
//
$sql = "SELECT u.username, u.user_id, c.user_id FROM " . WEBLOG_CONTRIBUTORS_TABLE . " c, " . USERS_TABLE . " u
	WHERE c.weblog_id = $weblog_id
		AND u.user_id = c.user_id";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't get contributors information.", "", __LINE__, __FILE__, $sql);
}
	
while ( $row = $db->sql_fetchrow($result) )
{
	$template->assign_block_vars('contribrow', array(
		'U_PROFILE' => append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $row['user_id']),
		'CONTRIBUTOR' => $row['username'])
	);
}

//
// Generate page
//
$template->assign_vars(array(
	'L_CONTRIBUTORS' => $lang['Contributors'],
	'L_CURRENT_CONTRIBUTORS' => $lang['Current_contributors'],
	'L_REMOVE_CONTRIBUTOR' => $lang['Remove_contributor'],
	'L_INDEX' => sprintf($lang['Forum_Index'], $board_config['sitename']),
	'L_WEBLOGS' => $lang['Weblogs'],
	'L_ADD_CONTRIBUTOR' => $lang['Add_contributor'],

	'U_INDEX' => append_sid('index.'.$phpEx),
	'U_WEBLOGS' => append_sid("weblogs.$phpEx"),
	'U_WEBLOG' => append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']),

	'S_CONTRIBUTOR_ACTION' => append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id"),
	'WEBLOG_NAME' => $weblog_data['weblog_name'])
);

//
// Output the body
//
$template->pparse('body');


$template->assign_vars(array(
	'L_POWERED_BY' => sprintf($lang['Weblog_powered_by'], WEBLOGS_MOD_VERSION))
);
//
// Output the footer
//
use_weblog_footer ( $weblog_data, $template_dir);

?>