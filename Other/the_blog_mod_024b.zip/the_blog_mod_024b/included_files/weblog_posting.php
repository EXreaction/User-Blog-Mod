<?php
/***************************************************************************
 *                            weblog_posting.php
 *                         ------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 TheBlogMod.com (Formerly by Hyperion)
 *   
 *   forum		  : http://www.TheBlogMod.com community
 *   email		  : Managed by support [at] TheBlogMod.com
 *
 *   $Id: weblog_posting.php,v 1.0.1 2004/09/05, 13:17:43 Hyperion Exp $
 *	- Updated 20051205 to CHMOD 0755 to 0777
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/bbcode.'.$phpEx);
include($phpbb_root_path . 'includes/functions_post.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

if ( isset($HTTP_POST_VARS[POST_REPLY_URL]) || isset($HTTP_GET_VARS[POST_REPLY_URL]) )
{
	$reply_id = ( isset($HTTP_POST_VARS[POST_REPLY_URL]) ) ? $HTTP_POST_VARS[POST_REPLY_URL] : $HTTP_GET_VARS[POST_REPLY_URL];
	$reply_id = intval($reply_id);
}
else
{
	$reply_id = 0;
}

if ( isset($HTTP_POST_VARS[POST_ENTRY_URL]) || isset($HTTP_GET_VARS[POST_ENTRY_URL]) )
{
	$entry_id = ( isset($HTTP_POST_VARS[POST_ENTRY_URL]) ) ? $HTTP_POST_VARS[POST_ENTRY_URL] : $HTTP_GET_VARS[POST_ENTRY_URL];
	$entry_id = intval($entry_id);
}
else
{
	$entry_id = 0;
}

if ( isset($HTTP_POST_VARS[POST_WEBLOG_URL]) || isset($HTTP_GET_VARS[POST_WEBLOG_URL]) )
{
	$weblog_id = ( isset($HTTP_POST_VARS[POST_WEBLOG_URL]) ) ? $HTTP_POST_VARS[POST_WEBLOG_URL] : $HTTP_GET_VARS[POST_WEBLOG_URL];
	$weblog_id = intval($weblog_id);
}
else
{
	$weblog_id = 0;
}

if ( isset($HTTP_POST_VARS[POST_TRACKBACK_URL]) || isset($HTTP_GET_VARS[POST_TRACKBACK_URL]) )
{
	$tb_id = ( isset($HTTP_POST_VARS[POST_TRACKBACK_URL]) ) ? $HTTP_POST_VARS[POST_TRACKBACK_URL] : $HTTP_GET_VARS[POST_TRACKBACK_URL];
	$tb_id = intval($tb_id);
}
else
{
	$tb_id = 0;
}

if ( isset($HTTP_GET_VARS['popup']) || isset($HTTP_POST_VARS['popup']))
{
	$popup = ( isset($HTTP_GET_VARS['popup']) ) ? intval($HTTP_GET_VARS['popup']) : intval($HTTP_POST_VARS['popup']);
}

if ( isset($HTTP_POST_VARS['mode']) || isset($HTTP_GET_VARS['mode']) )
{
	$mode = ( isset($HTTP_POST_VARS['mode']) ) ? $HTTP_POST_VARS['mode'] : $HTTP_GET_VARS['mode'];
}
else
{
	$mode = '';
}

$confirm = ( $HTTP_POST_VARS['confirm'] ) ? TRUE : 0;

//
// Text based parameters
//
$params = array('username' => 'username', 'uploaded_images' => 'uploaded_images', 'subject' => 'subject', 'action_text' => 'action_text', 'category' => 'category');
while( list($var, $param) = @each($params) )
{
	if ( !empty($HTTP_POST_VARS[$param]) )
	{
		$$var = trim($HTTP_POST_VARS[$param]);
	}
	else
	{
		$$var = '';
	}
}

//
// Integer parameters
//
$mood = -1;
$params = array('entry_access' => 'entry_access', 'mood' => 'mood', 'action' => 'action', 'year' => 'year', 'month' => 'month', 'day' => 'day');
while( list($var, $param) = @each($params) )
{
	if ( !empty($HTTP_POST_VARS[$param]) )
	{
		$$var = intval($HTTP_POST_VARS[$param]);
	}
	else if ( $var != 'mood' )
	{
		$$var = 0;
	}
}

//
// Parameters with only on or off
//
$params = array('memorable' => 'memorable', 'disable_replies' => 'disable_replies', 'disable_html' => 'disable_html', 'disable_bbcode' => 'disable_bbcode', 'disable_smilies' => 'disable_smilies', 'attach_sig' => 'attach_sig');
while( list($var, $param) = @each($params) )
{
	if ( !empty($HTTP_POST_VARS[$param]) )
	{
		$$var = ( !empty($HTTP_POST_VARS[$param]) ) ? 1 : 0;
	}
	else
	{
		$$var = 0;
	}
}

function check_image_type(&$type)
{
	switch( $type )
	{
		case 'jpeg':
		case 'pjpeg':
		case 'jpg':
			return '.jpg';
			break;
		case 'gif':
			return '.gif';
			break;
		case 'png':
			return '.png';
			break;
		default:
			break;
	}

	return false;
}

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_POSTING);
init_userprefs($userdata);
//
// End session management
//

$hour = date("G");
$minute = date("i");
$second = date("s");

if ( !$month )
{
	$month = create_date("n", time(), $board_config['board_timezone']);
}
else if ( $month < 1 || $month > 12 )
{
	$month = 1;
}

if ( !$day )
{
	$day = create_date("j", time(), $board_config['board_timezone']);
}
else if ( $day < 1 || $day > 31 )
{
	$day = 1;
}

if ( $year < 1970 || $year > 2038 || !$year )
{
	$year = create_date("Y", time(), $board_config['board_timezone']);
}

if ( isset($HTTP_POST_VARS['submit']) )
{
	// First, we must take into account the fact that day, month and year could be 1 higher or one lower than it should be relative to server time.
	$change = mktime(0,0,0,$month, $day, $year) - mktime(0,0,0,create_date("n", time(), $board_config['board_timezone']), create_date("j", time(), $board_config['board_timezone']), create_date("Y", time(), $board_config['board_timezone']));
	$target_date = time() + $change;
}

$hidden_form_fields = '';

//
// Check to make sure whatever is requested actually exists
//
if ( $tb_id )
{
	$tb_data = '';
	$sql = "SELECT * FROM " . WEBLOG_TRACKBACKS_TABLE . " WHERE tb_id = $tb_id";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting trackback information', '', __LINE__, __FILE__, $sql);
	}

	$tb_data = array();
	if ( $row = $db->sql_fetchrow($result) )
	{
		$tb_data = $row;
	}
	else
	{
		message_die(GENERAL_ERROR, $lang['Trackback_not_exist']);
	}

	// Also get the entry data
	$sql = "SELECT * FROM " . WEBLOG_ENTRIES_TABLE . " WHERE entry_id = " . $tb_data['tb_entry'] . " AND entry_deleted <> " . TRUE;
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting reply information', '', __LINE__, __FILE__, $sql);
	}

	$entry_data = array();
	if ( $row = $db->sql_fetchrow($result) )
	{
		$entry_data = $row;
	}
	else
	{
		message_die(GENERAL_ERROR, $lang['Entry_not_exist']);
	}

	$sql = "SELECT w.*, u.user_id FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
			WHERE w.weblog_id = " . $entry_data['weblog_id'] . "
				AND w.weblog_id = u.user_weblog";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error retrieving the trackback\'s weblog', '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$weblog_data = $row;
	}
	else
	{
		// If a reply doesn't belong to a weblog or an entry, it doesn't exist.
		message_die(GENERAL_ERROR, $lang['Weblog_not_exist']);
	}

	$entry_id = $tb_data['tb_entry'];
	$weblog_id = $weblog_data['weblog_id'];
}
else if ( $reply_id )
{
	$reply_data = '';
	$sql = "SELECT * FROM " . WEBLOG_REPLIES_TABLE . " WHERE reply_id = $reply_id";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting reply information', '', __LINE__, __FILE__, $sql);
	}

	$reply_data = array();
	if ( $row = $db->sql_fetchrow($result) )
	{
		$reply_data = $row;
	}
	else
	{
		message_die(GENERAL_ERROR, $lang['Reply_not_exist']);
	}

	// Also get the entry data
	$sql = "SELECT * FROM " . WEBLOG_ENTRIES_TABLE . " WHERE entry_id = " . $reply_data['entry_id'] . " AND entry_deleted <> " . TRUE;
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting reply information', '', __LINE__, __FILE__, $sql);
	}

	$entry_data = array();
	if ( $row = $db->sql_fetchrow($result) )
	{
		$entry_data = $row;
	}
	else
	{
		message_die(GENERAL_ERROR, $lang['Entry_not_exist']);
	}

	$sql = "SELECT w.*, u.user_id FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
			WHERE w.weblog_id = " . $entry_data['weblog_id'] . "
				AND w.weblog_id = u.user_weblog";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error retrieving the reply\'s weblog', '', __LINE__, __FILE__, $sql);
	}

	$weblog_data = array();
	if ( $row = $db->sql_fetchrow($result) )
	{
		$weblog_data = $row;
	}
	else
	{
		// If a reply doesn't belong to a weblog or an entry, it doesn't exist.
		message_die(GENERAL_ERROR, $lang['Weblog_not_exist']);
	}

	$entry_id = $reply_data['entry_id'];
	$weblog_id = $weblog_data['weblog_id'];
}
else if ( $entry_id )
{
	$entry_data = '';
	$sql = "SELECT * FROM " . WEBLOG_ENTRIES_TABLE . " WHERE entry_id = $entry_id AND entry_deleted <> " . TRUE;
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting entry information', '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$entry_data = $row;
	}
	else
	{
		message_die(GENERAL_ERROR, $lang['Entry_not_exist']);
	}

	$sql = "SELECT w.*, u.user_id FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
			WHERE w.weblog_id = " . $entry_data['weblog_id'] . "
				AND w.weblog_id = u.user_weblog";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error retrieving the entry\'s weblog', '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$weblog_data = $row;
	}
	else
	{
		// If an entry does not belong to a weblog, it doesn't exist
		message_die(GENERAL_ERROR, $lang['Weblog_not_exist']);
	}
	$weblog_id = $weblog_data['weblog_id'];

}
else if ( $weblog_id )
{
	$weblog_data = '';
	$sql = "SELECT w.*, u.* FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u WHERE w.weblog_id = $weblog_id AND u.user_weblog = w.weblog_id";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting weblog information', '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$weblog_data = $row;
	}
	else
	{
		message_die(GENERAL_ERROR, $lang['Weblog_not_exist']);
	}
}

//
// Was cancel pressed? If so then redirect to the appropriate
// page, no point in continuing with any further checks
//
if ( isset($HTTP_POST_VARS['cancel']) )
{
	if ( $tb_id )
	{
		$redirect = "weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id&amp;tb=1";
		$post_append = "#$post_id";
	}
	else if ( $entry_id )
	{
		$redirect = "weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id";
		$post_append = '';
	}
	else if ( $weblog_id )
	{
		$redirect = "weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id";
		$post_append = '';
	}
	else
	{
		$redirect = "weblogs.$phpEx";
		$post_append = '';
	}

	redirect(append_sid($redirect, true) . $post_append);
}

$template_dir = get_template_dir ( $weblog_data['template_id'] );

if ( $weblog_data['deleted'] )
{
	weblog_message_die(GENERAL_ERROR, sprintf($lang['Weblog_deactivated'], $weblog_data['weblog_name']));
}

//
// Fetch Contributor data
//
$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE weblog_id = $weblog_id AND user_id = " . $userdata['user_id'];
if ( !($result = $db->sql_query($sql)) )
{
	weblog_message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$contributor = FALSE;
if ( $row = $db->sql_fetchrow($result) || $userdata['user_level'] == ADMIN )
{
	$contributor = TRUE;
}

$auth_level = get_auth_level($weblog_data, $contributor);


if ( !$board_config['allow_html'] )
{
	$disable_html = 1;
}


if ( !$board_config['allow_bbcode'] )
{
	$disable_bbcode = 1;
}

if ( !$board_config['allow_smilies'] )
{
	$disable_smilies = 1;
}

if ( $disable_html )
{
	$html_on = 0;
}
else
{
	$html_on = 1;
}

if ( $disable_bbcode )
{
	$bbcode_on = 0;
}
else
{
	$bbcode_on = 1;
	$bbcode_uid = make_bbcode_uid();
}

if ( $disable_smilies )
{
	$smilies_on = 0;
}
else
{
	$smilies_on = 1;
}

//
// Handle Submissions (excluding image uploads)
//
if ( isset($HTTP_POST_VARS['submit']) )
{
	if ( !$userdata['user_allowweblog'] )
	{
		weblog_message_die(GENERAL_ERROR, $lang['Owner_banned']);
	}

	// Always going to be a message that needs to be taken care of
	$message = ( isset($HTTP_POST_VARS['message']) ) ? $HTTP_POST_VARS['message'] : '';
	$error_msg = '';

	if ( empty($subject) && ($mode == 'newentry' || $mode == 'editentry') )
	{
		$error_msg .= (!empty($error_msg)) ? '<br />' . $lang['Subject_empty'] : $lang['Subject_empty'];
	}

	if ( !empty($action_text) )
	{
		$action_text = trim($action_text);
	}

// ADD ON category by willow at TheBlogMod.com
	if ( !empty($category) ) 
   	{ 
      	   $category = trim($category); 
	} 


	if ( empty($message) )
	{
		if ( $mode == 'newentry' || $mode == 'editentry' )
		{
			$error_msg .= (!empty($error_msg)) ? '<br />' . $lang['Entry_empty'] : $lang['Entry_empty'];
		}
		else
		{
			$error_msg .= (!empty($error_msg)) ? '<br />' . $lang['Reply_empty'] : $lang['Reply_empty'];
		}

	}
	else
	{
		$message = prepare_message($message, $html_on, $bbcode_on, $smilies_on, $bbcode_uid);
	}

	// Check username
	if (!empty($username))
	{
		$username = trim(strip_tags($username));

		if (!$userdata['session_logged_in'])
		{
			include($phpbb_root_path . 'includes/functions_validate.'.$phpEx);

			$result = validate_username($username);
			if ($result['error'])
			{
				$error_msg .= (!empty($error_msg)) ? '<br />' . $result['error_msg'] : $result['error_msg'];
			}
		}
		else
		{
			$username = '';
		}
	}

	if ( !empty($error_msg) )
	{
		weblog_message_die (GENERAL_ERROR, $error_msg . '<br /><br />' . $lang['Try_again']);
	}

	if ( $mode == 'newentry' || $mode == 'editentry' )
	{
		//
		// Handle any Trackback Pings
		//
		$maximum = 0;

		// First, get the maximum entry id
		$sql = "SELECT MAX(entry_id) AS maximum FROM " . WEBLOG_ENTRIES_TABLE;
		if ( !($result = $db->sql_query($sql)) )
		{
			weblog_message_die(GENERAL_ERROR, 'Could not query maximum entry id in database', '', __LINE__, __FILE__, $sql);
		}

		if ( $row = $db->sql_fetchrow($result) )
		{
			$maximum = $row['maximum'];
		}

		$maximum++;

		$tb_excerpt = ( isset($HTTP_POST_VARS['tb_excerpt']) ) ? stripslashes(strip_tags($HTTP_POST_VARS['tb_excerpt'])) : '';
		$tb_urls = ( isset($HTTP_POST_VARS['tb_urls']) ) ? stripslashes($HTTP_POST_VARS['tb_urls']) : '';

		$tb_result = '';

		if ( $mode == 'newentry' )
		{
			if ( !empty($tb_urls) && !empty($tb_excerpt) )
			{
				include('includes/functions_trackback.php');

				$tb_result = do_trackback_pings ($tb_excerpt, $tb_urls, $weblog_data['weblog_name'], stripslashes($subject), $maximum);
			}

			if ( $weblog_data['weblog_id'] != $userdata['user_weblog'] && $userdata['user_level'] != ADMIN && !$contributor )
			{
				weblog_message_die (GENERAL_ERROR, $lang['No_add_entries']);
			}

			$sql = "INSERT INTO " . WEBLOG_ENTRIES_TABLE . " (entry_id, weblog_id, entry_access, entry_subject, entry_text, bbcode_uid, entry_mood, entry_currently, currently_text, entry_time, enable_bbcode, enable_smilies, enable_html, memorable, no_replies, entry_last_post_userid, entry_poster_id, category)
					VALUES ($maximum, $weblog_id, $entry_access, '" . str_replace("\'", "''", $subject) . "', '" . str_replace("\'", "''", $message) . "', '$bbcode_uid', $mood, $action, '" . str_replace("\'", "''", $action_text) . "', $target_date, $bbcode_on, $smilies_on, $html_on, $memorable, $disable_replies, " . $userdata['user_id'] . ", " . $userdata['user_id'] . ", '" . str_replace("\'", "''", $category) . "'" .")";
			if ( !($result = $db->sql_query($sql)) )
			{
				weblog_message_die(GENERAL_ERROR, 'Could not insert entry into database', '', __LINE__, __FILE__, $sql);
			}

			$sql = "UPDATE " . WEBLOGS_TABLE . "
				SET weblog_entries = weblog_entries + 1
				WHERE weblog_id = $weblog_id";
			if( !$result = $db->sql_query($sql) )
			{
				weblog_message_die(GENERAL_ERROR, "Couldn't update weblog entries information.", "", __LINE__, __FILE__, $sql);
			}

			// Set a cookie for this entry
			$tracking_entries = ( !empty($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) : array();
			$tracking_weblogs = ( !empty($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) : array();

			if ( count($tracking_entries) + count($tracking_weblogs) == 100 && empty($tracking_entries[$maximum]) )
			{
				asort($tracking_entries);
				unset($tracking_entries[key($tracking_entries)]);
			}

			$tracking_entries[$maximum] = time();

			setcookie($board_config['cookie_name'] . '_e', serialize($tracking_entries), 0, $board_config['cookie_path'], $board_config['cookie_domain'], $board_config['cookie_secure']);
			
			// Finish Up
			$template->assign_vars(array(
				'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$maximum") . '">')
			);

			weblog_message_die (GENERAL_MESSAGE, $lang['Entry_submitted'] . $tb_result . '<br /><br />' . sprintf($lang['Click_return_entry'], '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$maximum") . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_weblog'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']) . '">', '</a>', $weblog_data['weblog_name']));
		}
		else if ( $mode == 'editentry' )
		{
			if ( !empty($tb_urls) && !empty($tb_excerpt) )
			{
				include('includes/functions_trackback.php');

				$tb_result = do_trackback_pings ($tb_excerpt, $tb_urls, $weblog_data['weblog_name'], stripslashes($subject), $entry_data['entry_id']);
			}

			$time = mktime($hour, $minute, $second, $month, $day, $year);

			if ( $weblog_data['weblog_id'] != $userdata['user_weblog'] && $userdata['user_level'] != ADMIN && !$contributor )
			{
				weblog_message_die (GENERAL_ERROR, $lang['No_edit_entries']);
			}

			$sql = "UPDATE " . WEBLOG_ENTRIES_TABLE . " SET entry_access = $entry_access, entry_subject = '" . str_replace("\'", "''", $subject) . "', entry_text = '" . str_replace("\'", "''", $message) . "', bbcode_uid = '$bbcode_uid', entry_time = $target_date, entry_mood = $mood, entry_currently = $action, currently_text = '" . str_replace("\'", "''", $action_text) . "', category = '" . str_replace("\'", "''", $category) . "', enable_bbcode = $bbcode_on, enable_smilies = $smilies_on, enable_html = $html_on, memorable = $memorable, no_replies = $disable_replies WHERE entry_id = $entry_id";
			if ( !($result = $db->sql_query($sql)) )
			{
				weblog_message_die(GENERAL_ERROR, 'Could not update entry in database', '', __LINE__, __FILE__, $sql);
			}

			$template->assign_vars(array(
				'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '">')
			);

			weblog_message_die (GENERAL_MESSAGE, $lang['Entry_updated'] . $tb_result . '<br /><br />' . sprintf($lang['Click_return_entry'], '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_weblog'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']) . '">', '</a>', $weblog_data['weblog_name']));
		}
	}
	else if ( $mode == 'editreply' || $mode == 'reply' )
	{
		if ( $mode == 'editreply' )
		{
			// If the user isn't the original poster or a contributor or the weblog owner...
			if ( $reply_data['poster_id'] != $userdata['user_id'] && !$contributor && $weblog_data['weblog_id'] != $userdata['user_id'] && $userdata['session_logged_in'] )
			{
				weblog_message_die (GENERAL_ERROR, $lang['No_edit_replies']);
			}

			$sql = "UPDATE " . WEBLOG_REPLIES_TABLE . " SET post_subject = '" . str_replace("\'", "''", $subject) . "', reply_text = '" . str_replace("\'", "''", $message) . "', bbcode_uid = '$bbcode_uid', enable_bbcode = $bbcode_on, enable_smilies = $smilies_on, enable_html = $html_on, post_username = '" . str_replace("\'", "''", $username) . "' WHERE reply_id = $reply_id";
			if ( !($result = $db->sql_query($sql)) )
			{
				weblog_message_die(GENERAL_ERROR, 'Could not update reply in database', '', __LINE__, __FILE__, $sql);
			}

			$template->assign_vars(array(
				'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '">')
			);

			weblog_message_die (GENERAL_MESSAGE, $lang['Reply_updated'] . '<br /><br />' . sprintf($lang['Click_return_entry'], '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_weblog'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']) . '">', '</a>', $weblog_data['weblog_name']));
		}
		else if ( $mode == 'reply' )
		{
			if ( $weblog_data['replies_auth'] > $auth_level || $entry_data['no_replies'] )
			{
				weblog_message_die(GENERAL_ERROR, $lang['Reply_no_auth']);
			}
			// Get max reply id
			$sql = "SELECT MAX(reply_id) AS maximum FROM " . WEBLOG_REPLIES_TABLE;
			if ( !($result = $db->sql_query($sql)) )
			{
				weblog_message_die(GENERAL_ERROR, 'Could not query maximum reply id in database', '', __LINE__, __FILE__, $sql);
			}

			$maximum = 0;
			if ( $row = $db->sql_fetchrow($result) )
			{
				$maximum = $row['maximum'];
			}

			$maximum++;

			$sql = "INSERT INTO " . WEBLOG_REPLIES_TABLE . " (reply_id, entry_id, poster_id, post_time, post_username, enable_bbcode, enable_smilies, enable_html, enable_sig, reply_text, bbcode_uid)
					VALUES ($maximum, $entry_id, " . $userdata['user_id'] . ", " . time() . ", '" . str_replace("\'", "''", $username) . "', $bbcode_on, $smilies_on, $html_on, $attach_sig, '" . str_replace("\'", "''", $message) . "', '$bbcode_uid')";
			if ( !($result = $db->sql_query($sql)) )
			{
				weblog_message_die(GENERAL_ERROR, 'Could not insert reply into database', '', __LINE__, __FILE__, $sql);
			}

			// Also update the weblog entries' data
			$sql = "UPDATE " . WEBLOG_ENTRIES_TABLE . "
				SET entry_replies = entry_replies + 1, entry_last_post_id = $maximum, entry_last_post_userid = " . $userdata['user_id'] . "
				WHERE entry_id = $entry_id";
			if( !$result = $db->sql_query($sql) )
			{
				weblog_message_die(GENERAL_ERROR, "Couldn't update entry information.", "", __LINE__, __FILE__, $sql);
			}

			// Set a cookie for this reply
			$tracking_entries = ( !empty($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) : array();
			$tracking_weblogs = ( !empty($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) : array();

			if ( count($tracking_entries) + count($tracking_weblogs) == 100 && empty($tracking_entries[$entry_id]) )
			{
				asort($tracking_entries);
				unset($tracking_entries[key($tracking_entries)]);
			}

			$tracking_entries[$entry_id] = time();

			setcookie($board_config['cookie_name'] . '_e', serialize($tracking_entries), 0, $board_config['cookie_path'], $board_config['cookie_domain'], $board_config['cookie_secure']);

			if ( $popup )
			{
				//
				// Include page header
				//
				use_weblog_header ( $weblog_data, $template_dir );

				$template->assign_vars(array(
					'MESSAGE_TITLE' => $lang['Information'],
					'MESSAGE_TEXT' => $lang['Reply_submitted'] . '<br /><br /><a href="javascript:window.close();">' . $lang['Close_window'] . '</a>')
				);

				$template->set_filenames(array(
					'body' => '../../weblogs/templates/' . $template_dir . '/weblog_mini_box.htm')
				);

				$template->pparse('body');

				// Script will exit here
				use_weblog_footer ( $weblog_data, $template_dir );
			}

			$template->assign_vars(array(
				'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '">')
			);

			weblog_message_die (GENERAL_MESSAGE, $lang['Reply_submitted'] . '<br /><br />' . sprintf($lang['Click_return_entry'], '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=" . $entry_id) . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_weblog'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']) . '">', '</a>', $weblog_data['weblog_name']));
		}
	}

	weblog_message_die(GENERAL_ERROR, $lang['No_mode_specified']);
}
else if ( isset($HTTP_POST_VARS['upload_image']) )
{
	$message = ( isset($HTTP_POST_VARS['message']) ) ? $HTTP_POST_VARS['message'] : '';
	$message = stripslashes($message);

	if ( $mode != 'newentry' && $mode != 'editentry' )
	{
		weblog_message_die (GENERAL_ERROR, $lang['Picture_upload_entry_only']);
	}

	if ( $weblog_data['weblog_id'] != $userdata['user_weblog'] && !$contributor )
	{
		weblog_message_die (GENERAL_ERROR, $lang['Owner_contributor_upload_only']);
	}

	if ( !$weblog_config['pic_upload_enabled'] )
	{
		weblog_message_die (GENERAL_ERROR, $lang['No_upload_pictures']);
	}

	$ini_val = ( @phpversion() >= '4.0.0' ) ? 'ini_get' : 'get_cfg_var';

	$image_upload = ( !empty($HTTP_POST_VARS['image']) ) ? trim($HTTP_POST_VARS['image']) : ( ( $HTTP_POST_FILES['image']['tmp_name'] != 'none') ? $HTTP_POST_FILES['image']['tmp_name'] : '' );
	$image_name = ( !empty($HTTP_POST_FILES['image']['name']) ) ? $HTTP_POST_FILES['image']['name'] : '';
	$image_size = ( !empty($HTTP_POST_FILES['image']['size']) ) ? $HTTP_POST_FILES['image']['size'] : 0;
	$image_filetype = ( !empty($HTTP_POST_FILES['image']['type']) ) ? $HTTP_POST_FILES['image']['type'] : '';
	$image_filename = ( !empty($HTTP_POST_FILES['image']['tmp_name']) ) ? $HTTP_POST_FILES['image']['tmp_name'] : '';

	if ( preg_match('/\.(jpg|jpeg|gif|png)$/i', $image_name) )
	{
		if ( $image_size <= $weblog_config['max_pic_size'] && $image_size > 0 )
		{
			preg_match('#image\/[x\-]*([a-z]+)#', $image_filetype, $image_filetype);
			$image_filetype = $image_filetype[1];

			list($width, $height) = @getimagesize($image_filename);

			$imgtype = check_image_type($image_filetype);

			if ( !$imgtype )
			{
				$template->assign_block_vars('switch_preview', array());

				$template->assign_vars(array(
					'PREVIEW_MESSAGE' => $lang['Wrong_file_type'])
				);
			}
			else if ( $width <= $weblog_config['max_pic_width'] && $height <= $weblog_config['max_pic_height'] )
			{
				$new_filename = uniqid(rand()) . $imgtype;

				@chmod('./weblogs/upload/', 0755);

				if ( @$ini_val('open_basedir') != '' )
				{
					if ( @phpversion() < '4.0.3' )
					{
						weblog_message_die(GENERAL_ERROR, 'open_basedir is set and your PHP version does not allow move_uploaded_file', '', __LINE__, __FILE__);
					}

					$move_file = 'move_uploaded_file';
				}
				else
				{
					$move_file = 'copy';
				}

				if (!is_uploaded_file($image_filename))
				{
					message_die(GENERAL_ERROR, 'Unable to upload file', '', __LINE__, __FILE__);
				}

				if ( !file_exists($phpbb_root_path . 'weblogs/upload/' . $weblog_id . '/') )
				{
					@mkdir($phpbb_root_path . 'weblogs/upload/' . $weblog_id . '/', 0755);
				}

				$move_file($image_filename, "./weblogs/upload/$weblog_id/$new_filename");

				@chmod("./weblogs/upload/$weblog_id/$new_filename", 0755);

				if ( !empty($images) )
				{
					$images .= '|' . $new_filename;
				}
				else
				{
					$images = $new_filename;
				}

				$uploaded_images .= ( empty($uploaded_images) ) ? $new_filename : '|' . $new_filename;

				$template->assign_block_vars('switch_preview', array());

				$template->assign_vars(array(
					'PREVIEW_MESSAGE' => $lang['Image_uploaded'])
				);
			}
			else
			{
				$template->assign_block_vars('switch_preview', array());
	
				$template->assign_vars(array(
					'PREVIEW_MESSAGE' => $lang['Picture_too_big'])
				);
			}
		}
		else
		{
			$template->assign_block_vars('switch_preview', array());

			$template->assign_vars(array(
				'PREVIEW_MESSAGE' => $lang['Picture_too_big'])
			);
		}
	}
	else
	{
		$template->assign_block_vars('switch_preview', array());

		$template->assign_vars(array(
			'PREVIEW_MESSAGE' => $lang['Wrong_file_type'])
		);
	}
}


//
// Handle all other requests (e.g. deleting replies or entries, editing an entry/reply needs to replace variables)
//
if ( $mode == 'editentry' )
{
	if ( $weblog_data['weblog_id'] != $userdata['user_weblog'] && !$contributor )
	{
		weblog_message_die (GENERAL_ERROR, $lang['No_edit_entries']);
	}

	$message = $entry_data['entry_text'];

	$message = preg_replace('/\:(([a-z0-9]:)?)' . $entry_data['bbcode_uid'] . '/s', '', $message);
	$message = str_replace('<', '&lt;', $message);
	$message = str_replace('>', '&gt;', $message);
	$message = str_replace('<br />', "\n", $message);

	$subject = $entry_data['entry_subject'];
	$mood = $entry_data['entry_mood'];
	$action = $entry_data['entry_currently'];
	$action_text = $entry_data['currently_text'];
	
	$category = $entry_data['category'];
	
	$entry_access = $entry_data['entry_access'];
	$memorable = $entry_data['memorable'];
	$disable_replies = $entry_data['no_replies'];
	$html_on = $entry_data['enable_html'];
	$bbcode_on = $entry_data['enable_bbcode'];
	$smilies_on = $entry_data['enable_smilies'];
	$year = create_date("Y", $entry_data['entry_time'], $board_config['board_timezone']);
	$month = create_date("n", $entry_data['entry_time'], $board_config['board_timezone']);
	$day = create_date("j", $entry_data['entry_time'], $board_config['board_timezone']);
	$hour = create_date("G", $entry_data['entry_time'], $board_config['board_timezone']);
	$minute = create_date("i", $entry_data['entry_time'], $board_config['board_timezone']);
	$title = $lang['Edit_entry'];
	$template->assign_block_vars('switch_post_entry', array());
}
else if ( $mode == 'editreply' )
{
	if ( $weblog_data['replies_auth'] > $auth_level )
	{
		weblog_message_die(GENERAL_ERROR, $lang['Reply_no_auth']);
	}


	$message = $reply_data['reply_text'];
	$subject = $reply_data['post_subject'];
	$html_on = $reply_data['enable_html'];
	$bbcode_on = $reply_data['enable_bbcode'];
	$smilies_on = $reply_data['enable_smilies'];
	$attach_sig = $reply_data['enable_sig'];

	$message = preg_replace('/\:(([a-z0-9]:)?)' . $reply_data['bbcode_uid'] . '/s', '', $message);
	$message = str_replace('<', '&lt;', $message);
	$message = str_replace('>', '&gt;', $message);
	$message = str_replace('<br />', "\n", $message);

	// Everything else okay
	$template->assign_vars(array(
		'S_POST_ACTION' => ( $popup ) ? append_sid("weblog_posting.$phpEx?mode=newentry&amp;" . POST_WEBLOG_URL . "=$weblog_id&amp;popup=1") : append_sid("weblog_posting.$phpEx?mode=newentry&amp;" . POST_WEBLOG_URL . "=$weblog_id"))
	);

	$title = $lang['Edit_reply'];

	$template->assign_block_vars('switch_post_reply', array());
}
else if ( $mode == 'delete' )
{
	if ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $userdata['user_level'] == ADMIN )
	{
		if ( $confirm )
		{
			if ( $tb_id )
			{
				// Delete the trackback
				$sql = "DELETE FROM " . WEBLOG_TRACKBACKS_TABLE . " WHERE tb_id = $tb_id";
				if ( !($result = $db->sql_query($sql)) )
				{
					weblog_message_die(GENERAL_ERROR, 'Could not delete trackback.', '', __LINE__, __FILE__, $sql);
				}

				// Update the count
				$sql = "UPDATE " . WEBLOG_ENTRIES_TABLE . " SET entry_trackbacks = entry_trackbacks - 1 WHERE entry_id = " . $entry_data['entry_id'];
				if ( !($result = $db->sql_query($sql)) )
				{
					weblog_message_die(GENERAL_ERROR, 'Could not update entries table.', '', __LINE__, __FILE__, $sql);
				}

				$template->assign_vars(array(
					'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '">')
				);

				weblog_message_die (GENERAL_MESSAGE, $lang['Trackback_deleted'] . '<br /><br />' . sprintf($lang['Click_return_entry'], '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=" . $entry_data['entry_id']) . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_weblog'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']) . '">', '</a>', $weblog_data['weblog_name']));
			}
			else if ( $reply_id )
			{
				// Delete the reply
				$sql = "DELETE FROM " . WEBLOG_REPLIES_TABLE . " WHERE reply_id = $reply_id";
				if ( !($result = $db->sql_query($sql)) )
				{
					weblog_message_die(GENERAL_ERROR, 'Could not delete reply.', '', __LINE__, __FILE__, $sql);
				}

				// Also find and set the new last reply id
				$sql = "SELECT * FROM " . WEBLOG_REPLIES_TABLE . " WHERE entry_id = " . $entry_data['entry_id'] . " ORDER BY post_time DESC LIMIT 1";
				if( !$result = $db->sql_query($sql) )
				{
					weblog_message_die(GENERAL_ERROR, "Couldn't query entry replies information.", "", __LINE__, __FILE__, $sql);
				}

				if ( $row = $db->sql_fetchrow($result) )
				{
					$last_reply_id = $row['reply_id'];
				}
				else
				{
					$last_reply_id = 0;
				}

				// Successful, so decrement the replies count and set the new last reply id
				$sql = "UPDATE " . WEBLOG_ENTRIES_TABLE . "
					SET entry_replies = entry_replies - 1, entry_last_post_id = $last_reply_id
					WHERE entry_id = " . $entry_data['entry_id'];
				if( !$result = $db->sql_query($sql) )
				{
					weblog_message_die(GENERAL_ERROR, "Couldn't update weblog views information.", "", __LINE__, __FILE__, $sql);
				}

				$template->assign_vars(array(
					'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '">')
				);

				weblog_message_die (GENERAL_MESSAGE, $lang['Reply_deleted'] . '<br /><br />' . sprintf($lang['Click_return_entry'], '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=" . $entry_data['entry_id']) . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_weblog'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']) . '">', '</a>', $weblog_data['weblog_name']));
			}
			else if ( $entry_id )
			{
				// "Delete" the entry
				$sql = "UPDATE " . WEBLOG_ENTRIES_TABLE . "
					SET entry_deleted = 1
					WHERE entry_id = $entry_id";
				if ( !($result = $db->sql_query($sql)) )
				{
					weblog_message_die(GENERAL_ERROR, 'Could not delete entry.', '', __LINE__, __FILE__, $sql);
				}

				// Also find and set the new last reply id
				$sql = "SELECT * FROM " . WEBLOG_ENTRIES_TABLE . " WHERE weblog_id = " . $weblog_data['weblog_id'] . " AND entry_deleted <> " . TRUE . " ORDER BY entry_time DESC LIMIT 1";
				if( !$result = $db->sql_query($sql) )
				{
					weblog_message_die(GENERAL_ERROR, "Couldn't query entries information.", "", __LINE__, __FILE__, $sql);
				}

				$last_entry_id = 0;
				if ( $row = $db->sql_fetchrow($result) )
				{
					$last_entry_id = $row['entry_id'];
				}

				// Successful, so decrement the entries count
				$sql = "UPDATE " . WEBLOGS_TABLE . "
					SET weblog_entries = weblog_entries - 1
					WHERE weblog_id = " . $weblog_data['weblog_id'];
				if( !$result = $db->sql_query($sql) )
				{
					weblog_message_die(GENERAL_ERROR, "Couldn't update weblog views information.", "", __LINE__, __FILE__, $sql);
				}

				$template->assign_vars(array(
					'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">')
				);

				weblog_message_die (GENERAL_MESSAGE, $lang['Entry_deleted'] . '<br /><br />' . sprintf($lang['Click_return_weblog'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']) . '">', '</a>', $weblog_data['weblog_name']));
			}
			else
			{
				weblog_message_die(GENERAL_MESSAGE, $lang['Delete_not_specified']);
			}
		}
		else
		{
			$hidden_fields = '<input type="hidden" name="sid" value="' . $userdata['session_id'] . '" /><input type="hidden" name="mode" value="' . $mode . '" />';

			if ( $tb_id )
			{
				$hidden_fields .= '<input type="hidden" name="' . POST_TRACKBACK_URL . '" value="' . $tb_id . '" />';
				$lang_confirm_delete = $lang['Confirm_delete_tb'];
			}
			else if ( $reply_id )
			{
				$hidden_fields .= '<input type="hidden" name="' . POST_REPLY_URL . '" value="' . $reply_id . '" />';
				$lang_confirm_delete = $lang['Confirm_delete_reply'];
			}
			else if ( $entry_id )
			{
				$hidden_fields .= '<input type="hidden" name="' . POST_ENTRY_URL . '" value="' . $entry_id . '" />';
				$lang_confirm_delete = $lang['Confirm_delete_entry'];
			}

			//
			// Include page header
			//
			use_weblog_header ( $weblog_data, $template_dir );
			
			//
			// Set template files
			//
			$template->set_filenames(array(
				'body' => '../../weblogs/templates/' . $template_dir . '/weblog_confirm_body.htm')
			);

			$template->assign_vars(array(
				'MESSAGE_TITLE' => $lang['Confirm'],
				'MESSAGE_TEXT' => $lang_confirm_delete,

				'L_YES' => $lang['Yes'],
				'L_NO' => $lang['No'],

				'S_CONFIRM_ACTION' => append_sid("weblog_posting.$phpEx"),
				'S_HIDDEN_FIELDS' => $hidden_fields)
			);

			$template->pparse('body');

			$template->assign_vars(array(
				'L_POWERED_BY' => sprintf($lang['Weblog_powered_by'], WEBLOGS_MOD_VERSION))
			);

			use_weblog_footer ( $weblog_data, $template_dir );

		}
	}
	else
	{
		weblog_message_die (GENERAL_ERROR, $lang['Delete_not_authed']);
	}
}
else if ( $mode == 'newentry' )
{
	if ( $weblog_data['weblog_id'] != $userdata['user_weblog'] && !$contributor )
	{
		weblog_message_die (GENERAL_ERROR, $lang['Entry_add_not_authed']);
	}
	$title = $lang['New_entry'];
	$entry_access = $weblog_data['weblog_auth'];

	$template->assign_block_vars('switch_post_entry', array());
}
else if ( $mode == 'reply' )
{
	if ( $weblog_data['replies_auth'] > $auth_level || $entry_data['no_replies'] )
	{
		weblog_message_die(GENERAL_ERROR, $lang['Reply_no_auth']);
	}

	$title = $lang['Post_reply'];

	$template->assign_block_vars('switch_post_reply', array());
}
else if ( $mode == 'quote' )
{
	if ( $weblog_data['replies_auth'] > $auth_level || $entry_data['no_replies'] )
	{
		weblog_message_die(GENERAL_ERROR, $lang['Reply_no_auth']);
	}

	$title = $lang['Post_reply'];

	$message = $reply_data['reply_text'];

	$message = preg_replace('/\:(([a-z0-9]:)?)' . $reply_data['bbcode_uid'] . '/s', '', $message);
	$message = str_replace('<', '&lt;', $message);
	$message = str_replace('>', '&gt;', $message);
	$message = str_replace('<br />', "\n", $message);

	$sql = "SELECT username FROM " . USERS_TABLE . " WHERE user_id = " . $reply_data['poster_id'];
	if ( !($result = $db->sql_query($sql)) )
	{
		weblog_message_die(GENERAL_ERROR, "Could not obtain user information", '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$quote_user = $row['username'];
	}

	$message = '[quote="' . $quote_user . '"]' . $message . '[/quote]';

	$mode = 'reply';

	$template->assign_block_vars('switch_post_reply', array());

}
else
{
	weblog_message_die(GENERAL_ERROR, $lang['No_mode_specified']);
}

if ( isset($HTTP_POST_VARS['preview']) )
{
	$message = ( isset($HTTP_POST_VARS['message']) ) ? stripslashes($HTTP_POST_VARS['message']) : '';
	$preview_message = stripslashes(prepare_message(addslashes(unprepare_message($message)), $html_on, $bbcode_on, $smilies_on, $bbcode_uid));
	$post_subject = stripslashes($subject);

	//
	// Note! The order used for parsing the message _is_ important, moving things around could break any
	// output
	//

	//
	// If the board has HTML off but the post has HTML
	// on then we process it, else leave it alone
	//
	if ( !$board_config['allow_html'] )
	{
		if ( $html_on )
		{
			$preview_message = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $preview_message);
		}
	}

	//
	// Parse message and/or sig for BBCode if reqd
	//
	if ( $board_config['allow_bbcode'] )
	{
		if ( $bbcode_on )
		{
			$preview_message = bbencode_second_pass($preview_message, $bbcode_uid);
		}
	}

	$preview_message = make_clickable($preview_message);

	//
	// Parse smilies
	//
	if ( $board_config['allow_smilies'] )
	{
		if ( $smilies_on )
		{
			$preview_message = smilies_pass($preview_message);
		}
	}

	if ( $weblog_config['censor_weblog'] )
	{
		//
		// Replace naughty words
		//
		if (count($orig_word))
		{
			$post_subject = preg_replace($orig_word, $replacement_word, $post_subject);

			$preview_message = str_replace('\"', '"', substr(preg_replace('#(\>(((?>([^><]+|(?R)))*)\<))#se', "preg_replace(\$orig_word, \$replacement_word, '\\0')", '>' . $preview_message . '<'), 1, -1));
		}
	}


	//
	// Get the moods data
	//
	$sql = "SELECT *
		FROM " . WEBLOG_MOODS_TABLE . "
		WHERE mood_id = " . $mood;
	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
	}

	$row = '123';
	if ( $row = $db->sql_fetchrowset($result) )
	{
		$mood2 = $row[0];
	}

	//
	// Get the actions data
	//
	$sql = "SELECT *
		FROM " . WEBLOG_ACTIONS_TABLE . "
		WHERE action_id = " . $action;
	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't obtain action data from database", "", __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrowset($result) )
	{
		$currently = $row[0];
	}

	if ( $mood >= 0 )
	{ 
		$preview_mood = '<strong>[</strong>&nbsp;' . sprintf($lang['Mood:'], '<img src="images/weblogs/' . $mood2['mood_url'] . '" alt="' . $mood_data['mood_text'] . '" style="vertical-align: middle" border="0" />', $mood2['mood_text']) . '&nbsp;<strong>]</strong>';
	}
	else
	{
		$preview_mood = '';
	}

	if ( $currently > 0 )
	{
		$preview_action = '<strong>[</strong>&nbsp;' . sprintf($lang['Currently:'], '<img src="images/weblogs/' . $currently['action_url'] . '" alt="' . $currently['action_text'] . ' ' . $action_text . '" style="vertical-align: middle" border="0" />',  $currently['action_text'] . ' ' . $action_text) . '&nbsp;<strong>]</strong>';
	}
	else if ( $entry_data['currently_text'] && $currently == -2 )
	{
		$preview_action = '<strong>[</strong>' . sprintf($lang['Currently:'], '', $action_text) . '&nbsp;<strong>]</strong>';
	}
	else
	{
		$preview_action = '';
	}

	if ( $category !="" ) 
	{ 
	$preview_category = '<strong>[</strong>&nbsp;' . $lang['Category:'] . '<a href="' . append_sid("weblog.$phpEx?"  . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;category=$category") .'">' . $category . '</a>'  . '&nbsp;<strong>]</strong>'; 
	} 
	else 
	{ 
	$preview_category = ''; 
	}

	//
	// Replace newlines (we use this rather than nl2br because
	// till recently it wasn't XHTML compliant)
	//
	$preview_message = str_replace("\n", "\n<br />\n", $preview_message);

	$template->assign_block_vars('switch_preview', array());

	$template->assign_vars(array(
		'PREVIEW_MOOD' => $preview_mood,
		'PREVIEW_ACTION' => $preview_action,

		'PREVIEW_CATEGORY' => $preview_category, 

		'PREVIEW_SUBJECT' => $post_subject,
		'PREVIEW_MESSAGE' => $preview_message)
	);

	$subject = $post_subject;
}

//
// Get the moods data
//
$sql = "SELECT m.*, s.set_name
	FROM " . WEBLOG_MOODS_TABLE . " m, " . WEBLOG_MOOD_SETS_TABLE . " s
	WHERE m.mood_set = s.set_id
		AND s.set_id = " . $weblog_data['mood_set'] . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

//
// Get the actions data
//
$sql = "SELECT *
	FROM " . WEBLOG_ACTIONS_TABLE . "
	ORDER BY action_text";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't obtain action data from database", "", __LINE__, __FILE__, $sql);
}
$action_data = $db->sql_fetchrowset($result);

//ADDON Category 
//Get the category data 
$sql = "SELECT DISTINCT category FROM " . WEBLOG_ENTRIES_TABLE . " WHERE weblog_id = " . $weblog_id; 
if ( !($result = $db->sql_query($sql)) ) 
{ 
   weblog_message_die(GENERAL_ERROR, 'Error getting category information', '', __LINE__, __FILE__, $sql); 
} 
$category_data = array(); 

   while ( $row = $db->sql_fetchrow($result) ) 
   { 
      $category_data[] = $row['category']; 
   } 



//FIN Category ADDON

if ( $mode == 'reply' || $mode == 'editreply' )
{
	//
	// Get the entry's replies data
	//
	$sql = "SELECT r.*, u.* FROM " . WEBLOG_REPLIES_TABLE . " r, " . USERS_TABLE . " u
			WHERE entry_id = $entry_id
				$limit_posts_time
				AND u.user_id = r.poster_id
			ORDER BY r.post_time $post_time_order";
	if ( !($result = $db->sql_query($sql)) )
	{
		weblog_message_die(GENERAL_ERROR, "Could not obtain entry information", '', __LINE__, __FILE__, $sql);
	}

	$reply_data = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$reply_data[] = $row;
	}

	$entry_subject = $entry_data['entry_subject'];
	$entry_message = $entry_data['entry_text'];
	$entry_currently_text = $entry_data['currently_text'];

	if ( $weblog_config['censor_weblog'] )
	{
		//
		// Define censored word matches
		//
		$orig_word = array();
		$replacement_word = array();
		obtain_word_list($orig_word, $replacement_word);

		//
		// Censor entry subject, content, and currently text
		//
		if ( count($orig_word) )
		{
			$entry_subject = preg_replace($orig_word, $replacement_word, $entry_subject);
			$entry_text = preg_replace($orig_word, $replacement_word, $entry_text);
			$entry_currently_text = preg_replace($orig_word, $replacement_word, $entry_currently_text);
		}
	}

	//
	// If the board has HTML off but the post has HTML
	// on then we process it, else leave it alone
	//
	if ( !$board_config['allow_html'] )
	{
		if ( $entry_data['enable_html'] )
		{
			$entry_message = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $entry_message);
		}
	}

	//
	// Parse message and/or sig for BBCode if reqd
	//
	if ( $board_config['allow_bbcode'] )
	{
		if ( $entry_data['bbcode_uid'] != '' )
		{
			$entry_message = ( $board_config['allow_bbcode'] ) ? bbencode_second_pass($entry_message, $entry_data['bbcode_uid']) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $entry_message);
		}
	}

	$entry_message = make_clickable($entry_message);

	//
	// Parse smilies
	//
	if ( $board_config['allow_smilies'] )
	{
		if ( $entry_data['enable_smilies'] )
		{
			$entry_message = smilies_pass($entry_message);
		}
	}

	// Mood Icons
	$entry_mood = array();
	$entry_mood = find_mood($entry_data['entry_mood']);

	if ( $mood >= 0 )
	{ 
		$entry_mood = '<strong>[</strong>&nbsp;' . sprintf($lang['Mood:'], '<img src="images/weblogs/' . $entry_mood['mood_url'] . '" alt="' . $mood_data['mood_text'] . '" style="vertical-align: middle" border="0" />', $entry_mood['mood_text']) . '&nbsp;<strong>]</strong>';
	}
	else
	{
		$entry_mood = '';
	}

	// Currently Icons
	$entry_currently = array();
	$entry_currently = find_action($entry_data['entry_currently']);

	if ( $currently > 0 )
	{
		$entry_action = '<strong>[</strong>&nbsp;' . sprintf($lang['Currently:'], '<img src="images/weblogs/' . $entry_currently['action_url'] . '" alt="' . $entry_currently['action_text'] . ' ' . $entry_data['currently_text'] . '" style="vertical-align: middle" border="0" />',  $entry_currently['action_text'] . ' ' . $entry_data['currently_text']) . '&nbsp;<strong>]</strong>';
	}
	else if ( $entry_data['currently_text'] && $currently == -2 )
	{
		$entry_action = '<strong>[</strong>' . sprintf($lang['Currently:'], '', $entry_data['currently_text']) . '&nbsp;<strong>]</strong>';
	}
	else
	{
		$entry_action = '';
	}

	//
	// Replace newlines (we use this rather than nl2br because
	// till recently it wasn't XHTML compliant)
	//
	$entry_message = str_replace("\n", "\n<br />\n", $entry_message);

	for($i = 0; $i < count($reply_data); $i++)
	{
		$poster_id = $reply_data[$i]['user_id'];

		if ( empty($reply_data[$i]['post_username']) )
		{
			$reply_data[$i]['post_username'] = $lang['Guest'];
		}

		$poster = ( $poster_id == ANONYMOUS ) ? $reply_data[$i]['post_username'] : $reply_data[$i]['username'];

		$reply_message = $reply_data[$i]['reply_text'];
		$bbcode_uid = $reply_data[$i]['bbcode_uid'];

		//
		// Note! The order used for parsing the message _is_ important, moving things around could break any
		// output
		//

		//
		// If the board has HTML off but the post has HTML
		// on then we process it, else leave it alone
		//
		if ( !$board_config['allow_html'] )
		{
			if ( $user_sig != '' && $userdata['user_allowhtml'] )
			{
				$user_sig = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $user_sig);
			}

			if ( $reply_data[$i]['enable_html'] )
			{
				$reply_message = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $reply_message);
			}
		}

		//
		// Parse message and/or sig for BBCode if reqd
		//
		if ( $board_config['allow_bbcode'] )
		{
			if ( $bbcode_uid != '' )
			{
				$reply_message = ( $board_config['allow_bbcode'] ) ? bbencode_second_pass($reply_message, $bbcode_uid) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $reply_message);
			}
		}

		if ( $user_sig != '' )
		{
			$user_sig = make_clickable($user_sig);
		}
		$reply_message = make_clickable($reply_message);

		//
		// Parse smilies
		//
		if ( $board_config['allow_smilies'] )
		{
			if ( $reply_data[$i]['enable_smilies'] )
			{
				$reply_message = smilies_pass($reply_message);
			}
		}

		if ( $weblog_config['censor_weblog'] )
		{
			//
			// Replace naughty words
			//
			if (count($orig_word))
			{
				$post_subject = preg_replace($orig_word, $replacement_word, $post_subject);
	
				if ($user_sig != '')
				{
					$user_sig = str_replace('\"', '"', substr(preg_replace('#(\>(((?>([^><]+|(?R)))*)\<))#se', "preg_replace(\$orig_word, \$replacement_word, '\\0')", '>' . $user_sig . '<'), 1, -1));
				}
	
				$reply_message = str_replace('\"', '"', substr(preg_replace('#(\>(((?>([^><]+|(?R)))*)\<))#se', "preg_replace(\$orig_word, \$replacement_word, '\\0')", '>' . $reply_message . '<'), 1, -1));
			}
		}

		//
		// Replace newlines (we use this rather than nl2br because
		// till recently it wasn't XHTML compliant)
		//
		$reply_message = str_replace("\n", "\n<br />\n", $reply_message);
	
		//
		// Again this will be handled by the templating
		// code at some point
		//
		$row_class = ( !($i % 2) ) ? 'row1' : 'row2';

		if ( $mode == 'reply')
		{
			$template->assign_block_vars('switch_post_reply.postrow', array(
				'ROW_CLASS' => $row_class,
				'POSTER_NAME' => $poster,
				'MESSAGE' => $reply_message,

				'U_POST_ID' => $reply_data[$i]['post_id'])
			);
		}
	}

	if ( count ($reply_data) == 0 && ($mode == 'reply' || $mode == 'editreply') )
	{
		$template->assign_block_vars('switch_post_reply.switch_no_replies', array() );
	}

}

//
// Signature toggle selection
//
if( !empty($userdata['user_sig']) && $userdata['user_weblog'] == $weblog_data['weblog_id'] || $contributor )
{
	$template->assign_block_vars('switch_signature_checkbox', array());
}

//
// HTML toggle selection
//
if ( $board_config['allow_html'] )
{
	$html_status = $lang['HTML_is_ON'];
	$template->assign_block_vars('switch_html_checkbox', array());
}
else
{
	$html_status = $lang['HTML_is_OFF'];
}

//
// BBCode toggle selection
//
if ( $board_config['allow_bbcode'] )
{
	$bbcode_status = $lang['BBCode_is_ON'];
	$template->assign_block_vars('switch_bbcode_checkbox', array());
}
else
{
	$bbcode_status = $lang['BBCode_is_OFF'];
}

//
// Smilies toggle selection
//
if ( $board_config['allow_smilies'] )
{
	$smilies_status = $lang['Smilies_are_ON'];
	$template->assign_block_vars('switch_smilies_checkbox', array());
}
else
{
	$smilies_status = $lang['Smilies_are_OFF'];
}

if ( !$popup )
{
	$template->assign_block_vars('switch_not_popup', array());
}
else
{
	$template->assign_block_vars('switch_is_popup', array());
}

if( !$userdata['session_logged_in'] )
{
	$template->assign_block_vars('switch_username_select', array());
}

if ( $popup )
{
	$hidden_form_fields .= '<input type="hidden" name="popup" value="1" />';
}

$hidden_form_fields .= '<input type="hidden" name="mode" value="' . $mode . '" />';

if ( $mode == 'newentry' || $mode == 'editentry' )
{
	//
	// Handle pictures that were already uploaded
	//

	$script_name = preg_replace('/^\/?(.*?)\/?$/', '\1', trim($board_config['script_path']));
	$script_name = ( $script_name != '' ) ? $script_name . '/' : '';
	$server_name = trim($board_config['server_name']);
	$server_protocol = ( $board_config['cookie_secure'] ) ? 'https://' : 'http://';
	$server_port = ( $board_config['server_port'] <> 80 ) ? ':' . trim($board_config['server_port']) . '/' : '/';

	$server_url = $server_protocol . $server_name . $server_port . $script_name;

	if ( !empty($uploaded_images) )
	{
		$uploaded_images = explode ("|", $uploaded_images);

		$hidden_form_fields .= '<input type="hidden" name="uploaded_images" value="';

		for ( $i = 0; $i < count($uploaded_images); $i++)
		{
			$hidden_form_fields .= $uploaded_images[$i];
			if ( $i != (count($uploaded_images)-1) )
			{
				$hidden_form_fields .= '|';
			}

			$template->assign_block_vars('switch_post_entry.imagerow', array(
				'IMAGE' => 'weblogs/upload/' . $weblog_id . '/' . $uploaded_images[$i],
				'BBCODE' => '[img]' . $server_url . 'weblogs/upload/' . $weblog_id . '/' . $uploaded_images[$i] . '[/img]')
			);
		}

		$hidden_form_fields .= '" />';
	}
}

switch( $mode )
{
	case 'newentry':
		$page_title = $weblog_data['weblog_name'] . ' :: ' . $lang['New_entry'];
		$hidden_form_fields .= '<input type="hidden" name="' . POST_WEBLOG_URL . '" value="' . $weblog_id . '" />';
		break;

	case 'reply':
		$page_title = $weblog_data['weblog_name'] . ' :: ' . $lang['Post_reply'];
		$hidden_form_fields .= '<input type="hidden" name="' . POST_ENTRY_URL . '" value="' . $entry_id . '" />';
		break;

	case 'editentry':
		$page_title = $weblog_data['weblog_name'] . ' :: ' . $lang['Edit_entry'];
		$hidden_form_fields .= '<input type="hidden" name="' . POST_ENTRY_URL . '" value="' . $entry_id . '" />';
		break;

	case 'editreply':
		$page_title = $weblog_data['weblog_name'] . ' :: ' . $lang['Edit_reply'];
		$hidden_form_fields .= '<input type="hidden" name="' . POST_REPLY_URL . '" value="' . $reply_id . '" />';
		break;
}

// Generate smilies listing for page output
generate_smilies('inline', PAGE_POSTING);

//
// Include page header
//
use_weblog_header ( $weblog_data, $template_dir );

$template->set_filenames(array(
	'body' => '../../weblogs/templates/' . $template_dir . '/weblog_posting_body.htm')
);

$mood = find_mood ($mood);
$action = find_action ($action);

//
// Output the data to the template
//
$template->assign_vars(array(
	'ENTRY_SUBJECT' => $entry_subject,
	'ENTRY_TIME' => create_date($board_config['default_dateformat'], $entry_data['entry_time'], $board_config['board_timezone']),
	'MOOD' => $entry_mood,
	'ACTION' => $entry_action,

	'CATEGORY' => $category,

	'ENTRY' => $entry_message,

	'USERNAME' => $username,
	'SUBJECT' => $subject,
	'ACTION_TEXT' => $action_text,
	'MESSAGE' => $message,
	'ENTRY_AUTH_SELECT' => make_weblog_auth_select ( $entry_access, 'entry_access' ),
	'SELECT_MOOD' => make_mood_select( $mood['mood_id'], 'mood', $weblog_data['mood_set'], TRUE ),
	'ACTION_SELECT' => make_action_select( $action['action_id'], 'action', TRUE ),

	'CATEGORY_SELECT' => make_category_select ($category, 'category_select', $category_data),

	'MOOD_IMG' => ( $mood['mood_id'] > 0 ) ? $mood['mood_url'] : 'mood_none.gif',
	'ACTION_IMG' => ( $action['action_id'] > 0 ) ? $action['action_url'] : 'action_none.gif',

	'HTML_STATUS' => $html_status,
	'BBCODE_STATUS' => sprintf($bbcode_status, '<a href="' . append_sid("faq.$phpEx?mode=bbcode") . '" target="_phpbbcode">', '</a>'), 
	'SMILIES_STATUS' => $smilies_status, 

	'MODE' => $title,

	'MOD_VERSION' => $mod_version,

	'WEBLOG_NAME' => $weblog_data['weblog_name'],
	'DATE_SELECT' => make_date_select ( $year, $month, $day ),

	'MAX_PIC_SIZE' => $weblog_config['max_pic_size'],
	'MAX_PIC_WIDTH' => $weblog_config['max_pic_width'],
	'MAX_PIC_HEIGHT' => $weblog_config['max_pic_height'],
	'UPLOAD_DISABLED' => ( !$weblog_config['pic_upload_enabled'] ) ? 'disabled="disabled" ' : '',

	'CLOSE_WINDOW' => ( $popup ) ? ' onclick="window.close()"' : '',
	'U_WEBLOG' => append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']),
	'U_ENTRY' => append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id"),

	'L_UPLOAD_IMAGE' => $lang['Upload_image'],
	'L_FILENAME' => $lang['Filename'],
	'L_BBCODE' => $lang['BBCode'],
	'L_ENTRY_ADD_IMAGE' => $lang['Entry_add_image'],
	'L_ENTRY_ADD_IMAGE_EXPLAIN' => $lang['Entry_add_image_explain'],
	'L_MAX_PIC_SIZE' => $lang['Maximum_pic_size'],
	'L_MAX_PIC_WIDTH' => $lang['Maximum_pic_width'],
	'L_MAX_PIC_HEIGHT' => $lang['Maximum_pic_height'],
	'L_BYTES' => $lang['Bytes'],
	'L_PIXELS' => $lang['Pixels'],
	'L_TRACKBACK_EXPLAIN' => $lang['Trackback_form_explain'],
	'L_TRACKBACK' => $lang['Trackback'],
	'L_TRACKBACK_EXCERPT' => $lang['Excerpt'],
	'L_TRACKBACK_URLS' => $lang['URLs'],
	'L_ACTION' => $lang['Currently'],

	'L_CATEGORY' => $lang['Category'],

	'L_MOOD' => $lang['Mood'],
	'L_DISABLE_REPLIES' => $lang['Disable_replies'],
	'L_ENTRY_ACCESS' => $lang['Entry_auth'],
	'L_SUBJECT' => $lang['Subject'],
	'L_MESSAGE_BODY' => $lang['Message_body'],
	'L_OPTIONS' => $lang['Options'],
	'L_PREVIEW' => $lang['Preview'],
	'L_SPELLCHECK' => $lang['Spellcheck'],
	'L_SUBMIT' => $lang['Submit'],
	'L_CANCEL' => $lang['Cancel'],
	'L_DISABLE_HTML' => $lang['Disable_HTML_post'], 
	'L_DISABLE_BBCODE' => $lang['Disable_BBCode_post'], 
	'L_DISABLE_SMILIES' => $lang['Disable_Smilies_post'], 
	'L_ATTACH_SIGNATURE' => $lang['Attach_signature'], 
	'L_NOTIFY_ON_REPLY' => $lang['Notify'], 
	'L_MEMORABLE_ENTRY' => $lang['Memorable_entry'],

	'L_BBCODE_B_HELP' => $lang['bbcode_b_help'], 
	'L_BBCODE_I_HELP' => $lang['bbcode_i_help'], 
	'L_BBCODE_U_HELP' => $lang['bbcode_u_help'], 
	'L_BBCODE_Q_HELP' => $lang['bbcode_q_help'], 
	'L_BBCODE_C_HELP' => $lang['bbcode_c_help'], 
	'L_BBCODE_L_HELP' => $lang['bbcode_l_help'], 
	'L_BBCODE_O_HELP' => $lang['bbcode_o_help'], 
	'L_BBCODE_P_HELP' => $lang['bbcode_p_help'], 
	'L_BBCODE_W_HELP' => $lang['bbcode_w_help'], 
	'L_BBCODE_A_HELP' => $lang['bbcode_a_help'], 
	'L_BBCODE_S_HELP' => $lang['bbcode_s_help'], 
	'L_BBCODE_F_HELP' => $lang['bbcode_f_help'], 
	'L_EMPTY_MESSAGE' => $lang['Empty_message'],

	'L_ENTRY_NO_REPLIES' => $lang['Entry_no_replies'],
	'L_REPLIES_DISABLED' => $lang['Replies_disabled'],
	'L_GO' => $lang['Go'],
	'L_AUTHOR' => $lang['Author'],
	'L_MESSAGE' => $lang['Message'],

	'L_FONT_COLOR' => $lang['Font_color'], 
	'L_COLOR_DEFAULT' => $lang['color_default'], 
	'L_COLOR_DARK_RED' => $lang['color_dark_red'], 
	'L_COLOR_RED' => $lang['color_red'], 
	'L_COLOR_ORANGE' => $lang['color_orange'], 
	'L_COLOR_BROWN' => $lang['color_brown'], 
	'L_COLOR_YELLOW' => $lang['color_yellow'], 
	'L_COLOR_GREEN' => $lang['color_green'], 
	'L_COLOR_OLIVE' => $lang['color_olive'], 
	'L_COLOR_CYAN' => $lang['color_cyan'], 
	'L_COLOR_BLUE' => $lang['color_blue'], 
	'L_COLOR_DARK_BLUE' => $lang['color_dark_blue'], 
	'L_COLOR_INDIGO' => $lang['color_indigo'], 
	'L_COLOR_VIOLET' => $lang['color_violet'], 
	'L_COLOR_WHITE' => $lang['color_white'], 
	'L_COLOR_BLACK' => $lang['color_black'], 

	'L_FONT_SIZE' => $lang['Font_size'], 
	'L_FONT_TINY' => $lang['font_tiny'], 
	'L_FONT_SMALL' => $lang['font_small'], 
	'L_FONT_NORMAL' => $lang['font_normal'], 
	'L_FONT_LARGE' => $lang['font_large'], 
	'L_FONT_HUGE' => $lang['font_huge'], 

	'L_BBCODE_CLOSE_TAGS' => $lang['Close_Tags'], 
	'L_STYLES_TIP' => $lang['Styles_tip'], 

	'S_HTML_CHECKED' => ( !$html_on ) ? 'checked="checked"' : '',
	'S_BBCODE_CHECKED' => ( !$bbcode_on ) ? 'checked="checked"' : '',
	'S_SMILIES_CHECKED' => ( !$smilies_on ) ? 'checked="checked"' : '',
	'S_SIGNATURE_CHECKED' => ( $attach_sig ) ? 'checked="checked"' : '',

	'S_MEMORABLE_CHECKED' => ( $memorable ) ? 'checked="checked"' : '',
	'S_DISABLE_REPLIES_CHECKED' => ( $disable_replies ) ? 'checked="checked"' : '',

	'S_POST_ACTION' => append_sid("weblog_posting.$phpEx"),
	'S_HIDDEN_FORM_FIELDS' => $hidden_form_fields)
);

$template->pparse('body');

$template->assign_vars(array(
	'L_POWERED_BY' => sprintf($lang['Weblog_powered_by'], WEBLOGS_MOD_VERSION))
);

use_weblog_footer ( $weblog_data, $template_dir );

?>
