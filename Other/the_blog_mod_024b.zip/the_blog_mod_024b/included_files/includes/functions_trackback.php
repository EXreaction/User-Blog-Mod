<?php
/***************************************************************************
 *                         functions_trackback.php
 *                      -----------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   email                : vinng86@hotmail.com
 *
 *   $Id: functions_trackback.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

if (!defined('IN_PHPBB'))
{
	die('Hacking attempt');
}

function do_trackback_pings ($tb_excerpt, $tb_urls, $weblog_name, $subject, $entry_id)
{
	global $board_config, $phpEx;

	$tb_url = explode ("\n", $tb_urls);

	$server_protocol = ($board_config['cookie_secure']) ? 'https://' : 'http://';
	$server_name = preg_replace('#^\/?(.*?)\/?$#', '\1', trim($board_config['server_name']));
	$server_port = ($board_config['server_port'] <> 80) ? ':' . trim($board_config['server_port']) : '';
	$script_name = preg_replace('#^\/?(.*?)\/?$#', '\1', trim($board_config['script_path']));
	$script_name = ($script_name == '') ? $script_name : '/' . $script_name;
	$source_url  = $server_protocol . $server_name . $server_port . $script_name . '/weblog_entry.' . $phpEx . '?e=' . $entry_id;

	$result = '';
	$trackback = '';

	for ($i = 0; $i < count($tb_url); $i++)
	{
		$trackback = trackback_ping($tb_url[$i], $weblog_name, $subject, $tb_excerpt, $source_url);
		$result .= '<br />' . $trackback;
	}

	return $result;
}

function trackback_ping ($target_url, $weblog_name, $title, $excerpt, $url)
{
	global $lang;


	if (!preg_match('#^http[s]?:\/\/#i', $target_url))
	{
		$target_url = 'http://' . $target_url;
	}

	// Split up the target url so that we can manage it
	$target = @parse_url($target_url);

	// "?" is removed when the url is split up. This puts it back in.
	if ( isset($target['query']) && !empty($target['query']) )
	{
		$target['query'] = '?' . $target['query'];
	}
	else
	{
		$target['query'] = '';
	}

	if ( !isset($target['port']) || !is_numeric($target['port']) )
	{
		$target['port'] = 80;
	}

	$excerpt = reduce_length($excerpt);

	// Connect to the target
	$target_sock = @fsockopen($target['host'], $target['port']); 

	// If it can't connect....
	if (!is_resource($target_sock))
	{
		return sprintf($lang['Trackback_no_connect'], $target_url);
	}

	// Put together the things we want to send
	$target_send = 'url=' . rawurlencode($url) . '&title=' . rawurlencode($title) . '&blog_name=' . rawurlencode($weblog_name) . '&excerpt=' . rawurlencode($excerpt); 

	// Send the trackback
	fputs($target_sock, "POST " . $target['path'] . $target['query'] . " HTTP/1.1\r\n");
	fputs($target_sock, "Host: " . $target['host'] . "\r\n");
	fputs($target_sock, "Content-type: application/x-www-form-urlencoded\r\n");
	fputs($target_sock, "Content-length: " . strlen($target_send) . "\r\n");
	fputs($target_sock, "Connection: close\r\n\r\n");
	fputs($target_sock, $target_send); 

	// See what the server said
	while (!feof($target_sock))
	{
		$response .= fgets($target_sock, 128);
	}

	// Close the connection
	fclose($target_sock); 

	// send result
	return get_error_response($response, $target_url);
}

function get_error_response($response, $target_url)
{
	global $lang;

	if ( strpos($response, '<error>0</error>') )
	{
		return sprintf($lang['Trackback_successful'], $target_url);
	}

	$curr_pos = strpos($response, '<message>', $curr_pos);
	$end_pos = strpos($response, '</message>', $curr_pos);

	$error_msg = substr($response, $curr_pos, $end_pos - $curr_pos);

	return $error_msg;
}

function trackback_response($success, $err_response, $encoding)
{ 
	// Start response to trackbacker...
	$return = '<?xml version="1.0" encoding="' . $encoding . '"?>';
	$return .= '<response>';

	// Send back response...
	if ($success)
	{
		// Trackback received successfully...
		$return .= '    <error>0</error>';
	}
	else
	{
		// Something went wrong...
		$return .= '    <error>1</error>';
		$return .= '    <message>' . htmlspecialchars($err_response) . '</message>';
	} 

	// End response to trackbacker...
	$return .= "</response>";

	return $return;
} 

function reduce_length($excerpt)
{
	$excerpt = trim ($excerpt);

	if (strlen($excerpt) > 255)
	{
		$excerpt = substr($excerpt, 0, 252) . '...';
	}

	return $excerpt;
}

?>