<?php
/***************************************************************************
 *                           functions_weblog.php
 *                        --------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *
 *   forum		  : http://www.TheBlogMod.com
 *   email		  : Managed by support [at] TheBlogMod.com
 *
 *
 *   $Id: functions_weblog.php,v 1.0.1 2004/09/05, 13:17:43 Hyperion Exp $
 *   $Id: functions_weblog.php,v 1.0.2 2006/03/03, 12:35:01 TheBlogMod.com
 * 
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

/*****
############################################################## 
## ADDON Title: Addon "Categories" For The Blog Mod (0.24) 
## ADDON Author: E. Queffelec 
## ADDON Description: Adds a Categories System to the Blog Mod 0.24. 
##          Included the changes for the Infinity Template, please update your other templates ! 
## ADDON Version: Alpha 
## 
############################################################## 
*****/

function use_weblog_header ( $weblog_data, $template_dir, $parse = TRUE )
{
	global $board_config, $template, $template_data, $phpEx, $phpbb_root_path, $lang, $page_title, $userdata, $db, $theme, $weblog_fonts;
	//
	// Start output of page
	//

	// include the weblog lang file
	$use_lang = ( !file_exists($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_weblog_main.'.$phpEx) ) ? 'english' : $board_config['default_lang'];
	include($phpbb_root_path . 'language/lang_' . $use_lang . '/lang_weblog_main.' . $phpEx);

	//
	// Copied from includes/page_header.php
	//
	define('HEADER_INC', TRUE);

	//
	// gzip_compression
	//
	$do_gzip_compress = FALSE;
	if ( $board_config['gzip_compress'] )
	{
		$phpver = phpversion();

		$useragent = (isset($HTTP_SERVER_VARS['HTTP_USER_AGENT'])) ? $HTTP_SERVER_VARS['HTTP_USER_AGENT'] : getenv('HTTP_USER_AGENT');

		if ( $phpver >= '4.0.4pl1' && ( strstr($useragent,'compatible') || strstr($useragent,'Gecko') ) )
		{
			if ( extension_loaded('zlib') )
			{
				ob_start('ob_gzhandler');
			}
		}
		else if ( $phpver > '4.0' )
		{
			if ( strstr($HTTP_SERVER_VARS['HTTP_ACCEPT_ENCODING'], 'gzip') )
			{
				if ( extension_loaded('zlib') )
				{
					$do_gzip_compress = TRUE;
					ob_start();
					ob_implicit_flush(0);

					header('Content-Encoding: gzip');
				}
			}
		}
	}
	
	// Add no-cache control for cookies if they are set
	//$c_no_cache = (isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_sid']) || isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_data'])) ? 'no-cache="set-cookie", ' : '';

	// Work around for "current" Apache 2 + PHP module which seems to not
	// cope with private cache control setting
	if (!empty($HTTP_SERVER_VARS['SERVER_SOFTWARE']) && strstr($HTTP_SERVER_VARS['SERVER_SOFTWARE'], 'Apache/2'))
	{
		header ('Cache-Control: no-cache, pre-check=0, post-check=0');
	}
	else
	{
		header ('Cache-Control: private, pre-check=0, post-check=0, max-age=0');
	}
	header ('Expires: 0');
	header ('Pragma: no-cache');

	// Format Timezone. We are unable to use array_pop here, because of PHP3 compatibility
	$l_timezone = explode('.', $board_config['board_timezone']);
	$l_timezone = (count($l_timezone) > 1 && $l_timezone[count($l_timezone)-1] != 0) ? $lang[sprintf('%.1f', $board_config['board_timezone'])] : $lang[number_format($board_config['board_timezone'])];

	if ( !$userdata['session_logged_in'] )
	{
		$template->assign_block_vars('switch_user_logged_out', array());
	}
	else
	{
		$template->assign_block_vars('switch_user_logged_in', array());
	}

	//
	// End copy
	//

	if ( $parse )
	{
		$template->set_filenames(array(
			'header' => '../../weblogs/templates/' . $template_dir . '/weblog_header.htm')
		);
	}


	$user_weblog_sql = ( !empty($weblog_data['weblog_id']) ) ? "AND s.session_page = " . intval(10000 + $weblog_data['weblog_id']) : '';
	$sql = "SELECT u.username, u.user_id, u.user_allow_viewonline, u.user_level, s.session_logged_in, s.session_ip
		FROM ".USERS_TABLE." u, ".SESSIONS_TABLE." s
		WHERE u.user_id = s.session_user_id
			AND s.session_time >= ".( time() - 300 ) . "
			$user_weblog_sql
		ORDER BY u.username ASC, s.session_ip ASC";
	if( !($result = $db->sql_query($sql)) )
	{
		weblog_message_die(GENERAL_ERROR, 'Could not obtain user/online information', '', __LINE__, __FILE__, $sql);
	}

	$userlist_ary = array();
	$userlist_visible = array();

	$prev_user_id = 0;
	$prev_user_ip = $prev_session_ip = '';

	while( $row = $db->sql_fetchrow($result) )
	{
		// User is logged in and therefor not a guest
		if ( $row['session_logged_in'] )
		{
			// Skip multiple sessions for one user
			if ( $row['user_id'] != $prev_user_id )
			{
				$style_color = '';
				if ( $row['user_level'] == ADMIN )
				{
					$row['username'] = '<b>' . $row['username'] . '</b>';
					$style_color = 'style="color:#' . $theme['fontcolor3'] . '"';
				}
				else if ( $row['user_level'] == MOD )
				{
					$row['username'] = '<b>' . $row['username'] . '</b>';
					$style_color = 'style="color:#' . $theme['fontcolor2'] . '"';
				}

				if ( $row['user_allow_viewonline'] )
				{
					$user_online_link = '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $row['user_id']) . '"' . $style_color .'>' . $row['username'] . '</a>';
					$logged_visible_online++;
				}
				else
				{
					$user_online_link = '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $row['user_id']) . '"' . $style_color .'><i>' . $row['username'] . '</i></a>';
					$logged_hidden_online++;
				}

				if ( $row['user_allow_viewonline'] || $userdata['user_level'] == ADMIN )
				{
					$online_userlist .= ( $online_userlist != '' ) ? ', ' . $user_online_link : $user_online_link;
				}
			}

			$prev_user_id = $row['user_id'];
		}
		else
		{
			// Skip multiple sessions for one user
			if ( $row['session_ip'] != $prev_session_ip )
			{
				$guests_online++;
			}
		}

		$prev_session_ip = $row['session_ip'];
	}
	$db->sql_freeresult($result);

	if ( empty($online_userlist) )
	{
		$online_userlist = $lang['None'];
	}
	$online_userlist = $lang['Browsing_blog'] . ' ' . $online_userlist;

	if ( $weblog_data['font'] >= 0 && $weblog_data['font'] < NUM_WEBLOG_FONTS )
	{
		$font = $weblog_fonts[$weblog_data['font']];
	}
	else
	{
		$font = $weblog_fonts[0];
	}

	$template->assign_vars(array(
		'SITENAME' => $board_config['sitename'],
		'SITE_DESCRIPTION' => $board_config['site_desc'],
		'PAGE_TITLE' => $page_title,

		'WEBLOG_ID' => $weblog_data['weblog_id'],
		'WEBLOG_NAME' => $weblog_data['weblog_name'],
		'WEBLOG_DESCRIPTION' => $weblog_data['weblog_desc'],
		'BACKGROUND_COLOR' => $weblog_data['background_color'],
		'ENTRY_BG_COLOR' => $weblog_data['entry_bg_color'],
		'BORDER_COLOR' => $weblog_data['border_color'],
		'BACKGROUND_IMAGE' => $weblog_data['background_image'],
		'BACKGROUND_IMAGE_FIXED' => ( $weblog_data['background_image_fixed'] ) ? 'fixed' : 'scroll',
		'BACKGROUND_REPEAT' => $weblog_data['tile_bg'],
		'BACKGROUND_POSITION' => $weblog_data['bg_ypos'] . ' ' . $weblog_data['bg_xpos'],
		'SB_FACE_COLOR' => $weblog_data['sb_face_color'],
		'SB_HIGHLIGHT_COLOR' => $weblog_data['sb_highlight_color'],
		'SB_SHADOW_COLOR' => $weblog_data['sb_shadow_color'],
		'SB_3DLIGHT_COLOR' => $weblog_data['sb_3dlight_color'],
		'SB_ARROW_COLOR' => $weblog_data['sb_arrow_color'],
		'SB_TRACK_COLOR' => $weblog_data['sb_track_color'],
		'SB_DARKSHADOW_COLOR' => $weblog_data['sb_darkshadow_color'],
		'FONT' => $font,
		'FONT_COLOR' => $weblog_data['font_color'],
		'FONT_SIZE' => $weblog_data['font_size'],
		'NORMAL_LINK_COLOR' => $weblog_data['normal_link_color'],
		'NORMAL_LINK_UNDERLINED' => ( $weblog_data['normal_link_underline'] ) ? 'underline' : 'none',
		'ACTIVE_LINK_COLOR' => $weblog_data['active_link_color'],
		'ACTIVE_LINK_UNDERLINED' => ( $weblog_data['active_link_underline'] ) ? 'underline': 'none',
		'HOVER_LINK_COLOR' => $weblog_data['hover_link_color'],
		'HOVER_LINK_UNDERLINED' => ( $weblog_data['hover_link_underline'] ) ? 'underline': 'none',
		'VISITED_LINK_COLOR' => $weblog_data['visited_link_color'],
		'VISITED_LINK_UNDERLINED' => ( $weblog_data['visited_link_underline'] ) ? 'underline': 'none',
		'WEBLOG_TITLE_COLOR' => $weblog_data['weblog_title_color'],
		'WEBLOG_TITLE_FONT_SIZE' => $weblog_data['weblog_title_font_size'],
		'ENTRY_TITLE_COLOR' => $weblog_data['entry_title_color'],
		'ENTRY_TITLE_FONT_SIZE' => $weblog_data['entry_title_font_size'],
		'DATE_TIME_COLOR' => $weblog_data['date_time_color'],
		'DATE_TIME_FONT_SIZE' => $weblog_data['date_time_font_size'],
		'BLOCK_TITLE_COLOR' => $weblog_data['block_title_color'],
		'BLOCK_TITLE_FONT_SIZE' => $weblog_data['block_title_font_size'],
		'BLOCK_BG_COLOR' => $weblog_data['block_bg_color'],
		'BLOCK_BORDER_COLOR' => $weblog_data['block_border_color'],

		'LOGGED_IN_USER_LIST' => $online_userlist,

		'L_USERNAME' => $lang['Username'],
		'L_PASSWORD' => $lang['Password'],
		'L_LOGIN' => $lang['Login'],
		'L_LOG_ME_IN' => $lang['Log_me_in'],
		'L_AUTO_LOGIN' => $lang['Log_me_in'],
		'L_INDEX' => sprintf($lang['Forum_Index'], $board_config['sitename']),
		'L_REGISTER' => $lang['Register'],
		'L_PROFILE' => $lang['Profile'],
		'L_SEARCH' => $lang['Search'],
		'L_PRIVATEMSGS' => $lang['Private_Messages'],
		'L_WHO_IS_ONLINE' => $lang['Who_is_Online'],
		'L_MEMBERLIST' => $lang['Memberlist'],
		'L_FAQ' => $lang['FAQ'],
		'L_USERGROUPS' => $lang['Usergroups'],
		'L_SEARCH_NEW' => $lang['Search_new'],
		'L_SEARCH_UNANSWERED' => $lang['Search_unanswered'],
		'L_SEARCH_SELF' => $lang['Search_your_posts'],

		'L_LATEST_WEBLOGS' => $lang['Latest_weblogs_feed'],
		'L_WEBLOGS' => $lang['Weblogs'],
		'L_WEBLOG_CONFIG' => $lang['Weblog_CP'],
		'L_MYWEBLOGS' => $lang['Weblog_MyWeblogs'],

		'U_WEBLOGS' => append_sid("weblogs.$phpEx"),
		'U_MYWEBLOGS' => append_sid("myweblogs.$phpEx"),
		'U_WEBLOG_CONFIG' => append_sid("weblog_config.$phpEx"),
		'U_INDEX' => append_sid('index.'.$phpEx),
		'U_RSS' => append_sid("weblog_rss.$phpEx"),
		'S_CONTENT_DIRECTION' => $lang['DIRECTION'],
		'S_CONTENT_ENCODING' => $lang['ENCODING'],
		'S_CONTENT_DIR_LEFT' => $lang['LEFT'],
		'S_CONTENT_DIR_RIGHT' => $lang['RIGHT'],
		'S_TIMEZONE' => sprintf($lang['All_times'], $l_timezone),
		'S_LOGIN_ACTION' => append_sid('login.'.$phpEx))
	);

	if ( $parse )
	{
		//
		// Parse the header
		//
		$template->pparse('header');
	}

	return;
}

function use_weblog_footer ( $weblog_data, $template_dir, $parse = TRUE )
{
	global $do_gzip_compress, $template, $db;

	if ( $parse )
	{
		$template->set_filenames(array(
			'footer' => '../../weblogs/templates/' . $template_dir . '/weblog_footer.htm')
		);

		//
		// Output the footer
		//
		$template->pparse('footer');
	}

	//
	// Copied from includes/page_tail.php
	//
	//
	// Close our DB connection.
	//
	$db->sql_close();

	//
	// Compress buffered output if required and send to browser
	//
	if ( $do_gzip_compress )
	{
		//
		// Borrowed from php.net!
		//
		$gzip_contents = ob_get_contents();
		ob_end_clean();

		$gzip_size = strlen($gzip_contents);
		$gzip_crc = crc32($gzip_contents);

		$gzip_contents = gzcompress($gzip_contents, 9);
		$gzip_contents = substr($gzip_contents, 0, strlen($gzip_contents) - 4);

		echo "\x1f\x8b\x08\x00\x00\x00\x00\x00";
		echo $gzip_contents;
		echo pack('V', $gzip_crc);
		echo pack('V', $gzip_size);
	}

	exit;
	//
	// End copy
	//

}

function make_template_select ( $selected, $select_name, $weblog_exists, $hide_private = TRUE )
{
	global $template_data, $lang;

	$template_select = '<select id="' . $select_name . '" name="' . $select_name . '" onchange="update_preview(this.options[selectedIndex].id);">';
	$found = false;
	for ($i = 0; $i < count($template_data); $i++)
	{
		if ( ($template_data[$i]['template_private'] && $selected == $template_data[$i]['template_id']) || !$template_data[$i]['template_private'] )
		{
			$select = ( $selected == $template_data[$i]['template_id'] && $weblog_exists ) ? ' selected="selected"' : '';
			$template_select .= '<option value="' . $template_data[$i]['template_name'] . '" id="' . $template_data[$i]['template_dir'] . '"' . $select . '>' . (( $template_data[$i]['template_private'] && $hide_private ) ? $lang['Private'] : '') . ' ' . $template_data[$i]['template_name'] . '</option>';
			$found = ( $selected == $template_data[$i]['template_id'] ) ? true : $found;
		}
		$select = '';
	}

	if ( !$found && $weblog_exists )
	{
		$template_select .= '<option value="" name="" selected="selected">' . $lang['Unknown'] . '</option>';
	}

	$template_select .= '</select>';

	return $template_select;
}

function make_weblog_auth_select ( $selected, $select_name )
{
	global $lang;

	$weblog_auth_types = array($lang['Weblog_auth_all'], $lang['Weblog_auth_reg'], $lang['Weblog_auth_friends'], $lang['Weblog_auth_owner']);

	$weblog_auth_select = '<select id="' . $select_name . '" name="' . $select_name . '">';
	for ($i = 0; $i < count($weblog_auth_types); $i++)
	{
		$select = ( $selected == $i ) ? ' selected="selected"' : '';
		$weblog_auth_select .= '<option value="' . $i . '"' . $select . '>' . $weblog_auth_types[$i] . '</option>';
	}
	$weblog_auth_select .= '</select>';

	return $weblog_auth_select;
}

function make_mood_set_select ( $selected, $select_name )
{
	global $lang, $mood_set_data, $mood_data;

	$set_data = array();
	// Find the data that corresponds with the selected set
	for ( $i = 0; $i < count($mood_set_data); $i++ )
	{
		if ( $mood_set_data[$i]['set_id'] == $selected )
		{
			$set_data = $mood_set_data[$i];
		}
	}

	$set_select = '<select id="' . $select_name . '" name="' . $select_name . '" onchange="update_set_preview(this.options[selectedIndex].id);">';
	for ( $i = 0; $i < count ($mood_set_data); $i++ )
	{
		$preview = '';
		for ( $j = 0; $j < count($mood_data) ; $j++)
		{
			$temp = 0;
			$temp = rand(0, count($mood_data));
			if ( $mood_data[$j]['mood_set'] == $mood_set_data[$i]['set_id'] )
			{
				$preview = $mood_data[$j]['mood_url'];
				break;
			}
			else if ( $mood_data[$temp]['mood_set'] == $mood_set_data[$i]['set_id'] )
			{
				$preview = $mood_data[$temp]['mood_url'];
				break;
			}
		}
		if ( !$preview )
		{
			$preview = 'mood_none.gif';
		} 
		$select = ( $selected == $mood_set_data[$i]['set_id'] ) ? ' selected="selected"' : '';
		$set_select .= '<option value="' . $mood_set_data[$i]['set_id'] . '"' . $select . ' id="' . $preview . '">' . $mood_set_data[$i]['set_name'] . '</option>';
	}
	$set_select .= '</select>';

	return $set_select;
}

function make_mood_select ( $selected, $select_name, $set_id, $auto_change_img = FALSE )
{
	global $lang, $mood_data;

	$mood_select = '<select id="' . $select_name . '" name="' . $select_name . '"' . ( ( $auto_change_img ) ? ' onchange="update_mood(this.options[selectedIndex].id);"' : '') . ' tabindex="3">';
	$mood_select .= '<optgroup label="' . $mood_data[0]['set_name'] . '"><option value="-1" id="mood_none.gif"' . (( $selected == -1 ) ? " selected=\"selected\"" : "") . '>' . $lang['None'] . '</option>';

	for ($i = 0; $i < count($mood_data); $i++)
	{
		if ( $mood_data[$i]['mood_set'] == $set_id )
		{
			$select = ( $selected == $mood_data[$i]['mood_id'] ) ? ' selected="selected"' : '';
			$mood_select .= '<option value="' . $mood_data[$i]['mood_id'] . '" id="' . $mood_data[$i]['mood_url'] . '"' . $select . '>' . $mood_data[$i]['mood_text'] . '</option>';
		}
	}
	$mood_select .= '</optgroup></select>';

	return $mood_select;
}

function make_action_select ( $selected, $select_name, $auto_change_img = FALSE )
{
	global $lang, $action_data;

	$action_select = '<select id="' . $select_name . '" name="' . $select_name . '"' . ( ( $auto_change_img ) ? ' onchange="update_currently(this.options[selectedIndex].id);"' : '') . ' tabindex="4"><option value="-1" id="action_none.gif"' . (( $selected == -1 ) ? " selected=\"selected\"" : "") . '>' . $lang['None'] . '</option>';
	for ($i = 0; $i < count($action_data); $i++)
	{
		$select = ( $selected == $action_data[$i]['action_id'] ) ? ' selected="selected"' : '';
		$action_select .= '<option value="' . $action_data[$i]['action_id'] . '" id="' . $action_data[$i]['action_url'] . '"' . $select . '>' . $action_data[$i]['action_text'] . '</option>';
	}
	$action_select .= '<option value="-2" id="action_custom.gif"' . (( $selected == -2 ) ? " selected=\"selected\"" : "") . '>' . $lang['Custom'] . '</option></select>';

	return $action_select;
}

/********************************
* ADD ON for Category by willow *
*********************************/
function make_category_select ( $selected, $select_name, $category_data, $auto_change = TRUE)
{
	global $lang;

	$category_select = '<select id="' . $select_name . '" name="' . $select_name . '"'  . ' onchange="update_category(this.options[selectedIndex].id);" tabindex="6">';
	for ($i = 0; $i < count($category_data); $i++)
	{
		$select = ( $selected == $category_data[$i] ) ? ' selected="selected"' : '';
		$category_select .= '<option value="' . $i . '" id="' . $category_data[$i] . '">' . $category_data[$i] . '</option>';
	}
	$category_select .= '</select>';

	return $category_select;
}


function load_template ( $template_dir, $weblog_id )
{
	global $lang, $phpbb_root_path;

	@umask (0111);

	// Chmod so we'll have no problems
	@chmod($phpbb_root_path . 'weblogs/', 0755);

	// Read in that header
	$filename = $phpbb_root_path . 'weblogs/templates/' .$template_dir . '/weblog_header.htm';
	@chmod($filename, 0755);
	$fptr = @fopen($filename, 'r');

	if ( !$fptr )
	{
		$file_body = '\n' . sprintf($lang['Weblog_no_header'], $filename);
	}
	else
	{
		$file_body = @fread($fptr, filesize($filename));
		@fclose($fptr);
	}

	// Read in the body
	$filename = $phpbb_root_path . 'weblogs/templates/' .$template_dir . '/weblog_body.htm';
	@chmod($filename, 0755);
	$fptr = @fopen($filename, 'r');

	if ( !$fptr )
	{
		$file_body .= "\n" . sprintf($lang['Weblog_no_body'], $filename);
	}
	else
	{
		$file_body .= @fread($fptr, filesize($filename));
		@fclose($fptr);
	}

	// Read in that footer
	$filename = $phpbb_root_path . 'weblogs/templates/' .$template_dir . '/weblog_footer.htm';
	@chmod($filename, 0755);
	$fptr = @fopen($filename, 'r');

	if ( !$fptr )
	{
		$file_body .= '\n' . sprintf($lang['Weblog_no_footer'], $filename);
	}
	else
	{
		$file_body .= @fread($fptr, filesize($filename));
		@fclose($fptr);
	}

	// Read in that faceplate
	$filename = $phpbb_root_path . 'weblogs/templates/' .$template_dir . '/weblog_faceplate_body.htm';
	@chmod($filename, 0755);
	$fptr = @fopen($filename, 'r');

	if ( !$fptr )
	{
		$file_faceplate = sprintf($lang['Weblog_no_faceplate'], $filename);
	}
	else
	{
		$file_faceplate = @fread($fptr, filesize($filename));
		@fclose($fptr);
	}

	save_template ( $file_body, $file_faceplate, $weblog_id );
}

function save_template ( $weblog_body, $weblog_faceplate, $weblog_id )
{
	global $lang, $phpbb_root_path;

	// Assumes html has been prepared already

	@umask(0111);

	// Chmod so we'll have "no" problems
	@chmod($phpbb_root_path . 'weblogs/', 0755);


	$filename = $phpbb_root_path . 'weblogs/faceplate_' . $weblog_id . '.htm';
	@chmod($filename, 0755);
	$fptr = @fopen($filename, 'w');
	if ( !$fptr )
	{
		message_die (GENERAL_ERROR,  sprintf($lang['No_faceplate_file'], $filename));
	}
	else
	{
		@fwrite( $fptr, $weblog_faceplate );
		@fclose( $fptr );
	}

	$filename = $phpbb_root_path . 'weblogs/weblog_' . $weblog_id . '.htm';
	@chmod($filename, 0755);
	$fptr = @fopen($filename, 'w');
	if ( !$fptr )
	{
		message_die (GENERAL_ERROR,  sprintf($lang['No_weblog_file'], $filename));
	}
	else
	{
		@fwrite( $fptr, $weblog_body );
		@fclose( $fptr );
	}
}

function get_auth_level ( $weblog_data, $is_contributor = FALSE, $friends_data = array(), $blocked_data = array() )
{
	global $userdata, $db;

	$owner_id = $weblog_data['user_id'];

	if ( !count($friends_data) )
	{
		//
		// Friends
		//
		$sql = "SELECT * FROM " . WEBLOG_FRIENDS_TABLE . " WHERE friend_id = " . $userdata['user_id'];
		if ( !($result = $db->sql_query($sql)) )
		{
			weblog_message_die(GENERAL_ERROR, 'Error querying to find user weblog friends information', '', __LINE__, __FILE__, $sql);
		}

		$friends_data = array();
		while ( $row = $db->sql_fetchrow($result) )
		{
			$friends_data[] = $row;
		}
	}

	if ( !count($blocked_data) )
	{
		//
		// Blocked Users
		//
		$sql = "SELECT * FROM " . WEBLOG_BLOCKED_TABLE . " WHERE blocked_id = " . $userdata['user_id'];
		if ( !($result = $db->sql_query($sql)) )
		{
			weblog_message_die(GENERAL_ERROR, 'Error querying to find user weblog blocked information', '', __LINE__, __FILE__, $sql);
		}

		$blocked_data = array();
		while ( $row = $db->sql_fetchrow($result) )
		{
			$blocked_data[] = $row;
		}
	}

	//
	// Get the authorization level of this user versus this weblog
	//
	$weblog_id = $weblog_data['weblog_id'];

	$auth_level = 0;	// The user should at least belong to the 'all' category!

	if ( $userdata['session_logged_in'] )
	{
		$auth_level = 1;

		for ( $i = 0; $i < count($friends_data); $i++ )
		{
			if ( $friends_data[$i]['owner_id'] == $owner_id && $userdata['user_id'] == $friends_data[$i]['friend_id'] )
			{
				$auth_level = 2;
				break;
			}
		}

		for ( $i = 0; $i < count($blocked_data); $i++ )
		{
			if ( $blocked_data[$i]['owner_id'] == $owner_id && $userdata['user_id'] == $blocked_data[$i]['blocked_id'] )
			{
				$auth_level = -1;
				break;
			}
		}

		if ( $userdata['user_level'] == ADMIN || $is_contributor )
		{
			$auth_level = 2;
		}

		if ( $weblog_data['weblog_id'] == $userdata['user_weblog']  )
		{
			// Means full access. Can be any number higher than 2.
			$auth_level = 3;
		}
	}

	return $auth_level;
}

function get_weblog_faceplate ($weblog_id)
{
	global $lang;

	$filename = 'weblogs/faceplate_' . $weblog_id . '.htm';

	// CHMOD the template's files
	@chmod ($filename, 0755);
	if ( file_exists($filename) )
	{
		$faceplate = file($filename);
	}
	else
	{
		$faceplate[] = sprintf($lang['No_faceplate_file'], $filename);
	}

	$file_faceplate = '';
	for ( $i = 0; $i < count($faceplate); $i++) { $file_faceplate .= $faceplate[$i]; }

	return $file_faceplate;
}

function get_weblog_body ($weblog_id)
{
	global $lang;

	$filename = 'weblogs/weblog_' . $weblog_id . '.htm';

	// CHMOD the template's files
	@chmod ($filename, 0755);
	if ( file_exists($filename) )
	{
		$body = file($filename);
	}
	else
	{
		$body[] = sprintf($lang['Weblog_no_body'], $filename);
	}

	$file_body = '';
	for ( $i = 0; $i < count($body); $i++) { $file_body .= $body[$i]; }

	return $file_body;
}

function get_template_dir ( $template_id )
{
	global $template_data;	

	for ( $i = 0; $i < count ($template_data); $i++)
	{
		if ( $template_data[$i]['template_id'] == $template_id )
		{
			return $template_data[$i]['template_dir'];
		}
	}

	return -1;
}

function find_mood ( $mood_id )
{
	global $mood_data;

	for ( $i = 0; $i < count($mood_data); $i++ )
	{
		if ( $mood_data[$i]['mood_id'] == $mood_id )
		{
			return $mood_data[$i];
		}
	}

	return -1;
}

function find_action ( $action_id )
{
	global $action_data;

	if ( $action_id == -2 )
	{
		return -2;
	}

	for ( $i = 0; $i < count($action_data); $i++ )
	{
		if ( $action_data[$i]['action_id'] == $action_id )
		{
			return $action_data[$i];
		}
	}

	return -1;
}

function make_date_select ( $select_year, $select_month, $select_day )
{
	global $lang, $board_config;

	$months = array($lang['datetime']['January'],$lang['datetime']['February'],$lang['datetime']['March'],$lang['datetime']['April'],$lang['datetime']['May'],$lang['datetime']['June'], $lang['datetime']['July'], $lang['datetime']['August'], $lang['datetime']['September'], $lang['datetime']['October'], $lang['datetime']['November'], $lang['datetime']['December']);

	$date_select = '<select id="month" name="month">';
	$date_select .= '<option value="">---</option>';
	for ($i = 1; $i <= 12 ; $i++)
	{
		$select = ( $select_month == $i ) ? ' selected="selected"' : '';
		$date_select .= '<option value="' . $i . '"' . $select . '>' . $months[$i-1] . '</option>';
	}
	$date_select .= '</select>';


	$date_select .= '<select id="day" name="day">';
	$date_select .= '<option value="">---</option>';
	for ($i = 1; $i <= 31 ; $i++)
	{
		$select = ( $select_day == $i ) ? ' selected="selected"' : '';
		$date_select .= '<option value="' . $i . '"' . $select . '>' . $i . '</option>';
	}
	$date_select .= '</select>';


	$date_select .= '<select id="year" name="year">';
	for ($i = 1970; $i <= 2037; $i++)
	{
		$select = ( $select_year == $i ) ? ' selected="selected"' : '';
		$date_select .= '<option value="' . $i . '"' . $select . '>' . $i . '</option>';
	}
	$date_select .= '</select>';

	return $date_select;

}

function search_array ( $needle, $haystack )
{
	for ( $i = 0; $i < count($haystack); $i++)
	{
		if ( $haystack[$i]['weblog_id'] == $needle )
		{
			return true;
		}
	}

	return false;
}

function fetch_visible_weblogs ( $sort = 'entry_time', $order = 'DESC' )
{
	global $db, $userdata;

	//
	// Friends
	//
	$sql = "SELECT * FROM " . WEBLOG_FRIENDS_TABLE . " WHERE friend_id = " . $userdata['user_id'];
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error querying to find user weblog friends information', '', __LINE__, __FILE__, $sql);
	}

	$friends_data = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$friends_data[] = $row;
	}

	//
	// Blocked Users
	//
	$sql = "SELECT * FROM " . WEBLOG_BLOCKED_TABLE . " WHERE blocked_id = " . $userdata['user_id'];
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error querying to find user weblog blocked information', '', __LINE__, __FILE__, $sql);
	}

	$blocked_data = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$blocked_data[] = $row;
	}

	//
	// Fetch Contributor data
	//
	$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE user_id = " . $userdata['user_id'];
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
	}

	$contributor_data = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$contributor_data[] = $row;
	}

	//
	// Get Weblog Data from Weblogs with at least one valid entry
	//
	$sql = "SELECT w.*, u.*, e.entry_id, e.entry_subject, e.entry_access, e.entry_mood, e.entry_currently, e.entry_time, e.currently_text, e.bbcode_uid, e.entry_text
		FROM " . USERS_TABLE . " u, " . WEBLOGS_TABLE . " w
			LEFT JOIN " . WEBLOG_ENTRIES_TABLE . " e
				ON e.weblog_id = w.weblog_id
				AND e.entry_deleted = 0
				AND e.entry_time <= " . time() . "
			WHERE w.weblog_id = u.user_weblog
				AND w.deleted = 0
				
			ORDER BY $sort $order
			LIMIT 0,300";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not query weblogs information', '', __LINE__, __FILE__, $sql);
	}


	//
	// Build a new array, discarding weblogs with outdated entries or entries that cannot be viewed.
	//
	$weblog_data = array();
	while( $row = $db->sql_fetchrow($result) )
	{
		if ( !search_array( $row['weblog_id'], $weblog_data ) )
		{
			$contributor = FALSE;
			for ( $i = 0; $i < count($contributor_data); $i++)
			{
				if ( $contributor_data[$i]['weblog_id'] == $row['weblog_id'] )
				{
					$contributor = TRUE;
					break;
				}
			}
			$auth_level = get_auth_level( $row, $contributor, $friends_data, $blocked_data );

			if ( $auth_level >= $row['weblog_auth'] && $auth_level >= $row['entry_access'] )
			{
				$weblog_data[] = $row;
			}
		}
	}


	return $weblog_data;
}

// Very similar to phpBB's message_die function - just borrowed and modified
function weblog_message_die($msg_code, $msg_text = '', $msg_title = '', $err_line = '', $err_file = '', $sql = '')
{
	global $db, $template, $board_config, $theme, $lang, $phpEx, $phpbb_root_path, $nav_links, $gen_simple_header, $images, $template_dir, $weblog_data;
	global $userdata, $user_ip, $session_length;
	global $starttime;

	if(defined('HAS_DIED'))
	{
		die("message_die() was called multiple times. This isn't supposed to happen. Was message_die() used in page_tail.php?");
	}
	
	define(HAS_DIED, 1);
	

	$sql_store = $sql;
	
	//
	// Get SQL error if we are debugging. Do this as soon as possible to prevent 
	// subsequent queries from overwriting the status of sql_error()
	//
	if ( DEBUG && ( $msg_code == GENERAL_ERROR || $msg_code == CRITICAL_ERROR ) )
	{
		$sql_error = $db->sql_error();

		$debug_text = '';

		if ( $sql_error['message'] != '' )
		{
			$debug_text .= '<br /><br />SQL Error : ' . $sql_error['code'] . ' ' . $sql_error['message'];
		}

		if ( $sql_store != '' )
		{
			$debug_text .= "<br /><br />$sql_store";
		}

		if ( $err_line != '' && $err_file != '' )
		{
			$debug_text .= '</br /><br />Line : ' . $err_line . '<br />File : ' . $err_file;
		}
	}

	if( empty($userdata) && ( $msg_code == GENERAL_MESSAGE || $msg_code == GENERAL_ERROR ) )
	{
		$userdata = session_pagestart($user_ip, PAGE_INDEX);
		init_userprefs($userdata);
	}

	//
	// If the header hasn't been output then do it
	//
	if ( !defined('HEADER_INC') && $msg_code != CRITICAL_ERROR )
	{
		if ( empty($lang) )
		{
			if ( !empty($board_config['default_lang']) )
			{
				include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_main.'.$phpEx);
			}
			else
			{
				include($phpbb_root_path . 'language/lang_english/lang_main.'.$phpEx);
			}
		}

		// include the weblog lang file
		$use_lang = ( !file_exists($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_weblog_main.'.$phpEx) ) ? 'english' : $board_config['default_lang'];
		include($phpbb_root_path . 'language/lang_' . $use_lang . '/lang_weblog_main.' . $phpEx);

		if ( empty($template) )
		{
			$template = new Template($phpbb_root_path . 'templates/' . $board_config['board_template']);
		}
		if ( empty($theme) )
		{
			$theme = setup_style($board_config['default_style']);
		}

		//
		// Load the Page Header
		//
		use_weblog_header ( $weblog_data, $template_dir, TRUE );
	}

	switch($msg_code)
	{
		case GENERAL_MESSAGE:
			if ( $msg_title == '' )
			{
				$msg_title = $lang['Information'];
			}
			break;

		case CRITICAL_MESSAGE:
			if ( $msg_title == '' )
			{
				$msg_title = $lang['Critical_Information'];
			}
			break;

		case GENERAL_ERROR:
			if ( $msg_text == '' )
			{
				$msg_text = $lang['An_error_occured'];
			}

			if ( $msg_title == '' )
			{
				$msg_title = $lang['General_Error'];
			}
			break;

		case CRITICAL_ERROR:
			//
			// Critical errors mean we cannot rely on _ANY_ DB information being
			// available so we're going to dump out a simple echo'd statement
			//
			include($phpbb_root_path . 'language/lang_english/lang_main.'.$phpEx);

			if ( $msg_text == '' )
			{
				$msg_text = $lang['A_critical_error'];
			}

			if ( $msg_title == '' )
			{
				$msg_title = 'phpBB : <b>' . $lang['Critical_Error'] . '</b>';
			}
			break;
	}

	//
	// Add on DEBUG info if we've enabled debug mode and this is an error. This
	// prevents debug info being output for general messages should DEBUG be
	// set TRUE by accident (preventing confusion for the end user!)
	//
	if ( DEBUG && ( $msg_code == GENERAL_ERROR || $msg_code == CRITICAL_ERROR ) )
	{
		if ( $debug_text != '' )
		{
			$msg_text = $msg_text . '<br /><br /><b><u>DEBUG MODE</u></b>' . $debug_text;
		}
	}

	if ( $msg_code != CRITICAL_ERROR )
	{
		if ( !empty($lang[$msg_text]) )
		{
			$msg_text = $lang[$msg_text];
		}

		$template->set_filenames(array(
			'body' => '../../weblogs/templates/' . $template_dir . '/weblog_message_body.htm')
		);

		$template->assign_vars(array(
			'MESSAGE_TITLE' => $msg_title,
			'MESSAGE_TEXT' => $msg_text)
		);
		$template->pparse('body');

		use_weblog_footer ( $weblog_data, $template_dir, TRUE );
	}
	else
	{
		echo "<html>\n<body>\n" . $msg_title . "\n<br /><br />\n" . $msg_text . "</body>\n</html>";
	}

	exit;
}

function cut_message ( $message, $entry_id )
{
	global $lang, $phpEx;

	// Limit if [cut] is found
	$msg = '';
	if ( $pos = strpos($message, '[cut]') )
	{
		if ( $pos2 = strpos($message, '[/cut]') )
		{
			$msg = substr($message, $pos + 5, $pos2 - $pos - 5);
		}
		else
		{
			$msg = $lang['More'];
		}
		

		$message = substr($message, 0, $pos);
		$message .= "\n" . sprintf($lang['More_entry'], '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=" . $entry_id) . '">', substr($msg, 0, 20), '</a>'); 
	}

	return $message;
}

function hide_cuts ( $message )
{
	if ( ($pos = strpos($message, '[cut]')) && ($pos2 = strpos($message, '[/cut]')) )
	{
		$msg = substr($message, $pos, ($pos2 + 6)-$pos);

		$message = str_replace ($msg, '', $message);
	}
	return $message;
}

?>