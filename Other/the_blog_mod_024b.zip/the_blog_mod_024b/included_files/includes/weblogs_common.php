<?php
/***************************************************************************
 *                            weblogs_common.php
 *                         ------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *
 *   forum		  : http://www.blogpoint.com
 *   email		  : Managed by support [at] blogpoint.com
 *
 *   $Id: weblogs_common.php,v 1.0.1 2006/01/29, 23:00:01 support at blogpoiny.com (former Hyperion) Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

if ( !defined('IN_PHPBB') )
{
	die("Hacking attempt");
}

// The Blog Mod version 0.2.4
define('WEBLOGS_MOD_VERSION', '0.2.4');

// Weblog Constants (Constants used all over the place)
define('SORT_NEWEST_ENTRIES', 0);
define('SORT_WEBLOG_NAME', 1);
define('SORT_NUM_ENTRIES', 2);
define('SORT_WEBLOG_START_DATE', 3);
define('SORT_WEBLOG_VIEWS', 4);
define('SORT_WEBLOG_OWNER_NAME', 5);

define('ACTION_DO_NOTHING', 0);
define('ACTION_LOAD_TEMPLATE', 1);
define('ACTION_SWITCH_MODE', 2);

define('WEBLOG_AUTH_ALL', 0);
define('WEBLOG_AUTH_REGISTERED', 1);
define('WEBLOG_AUTH_FRIENDS', 2);
define('WEBLOG_AUTH_OWNER', 3);

define('NUM_WEBLOG_FONTS', 7);
// include the weblog language file
$use_lang = ( !file_exists($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_weblog_main.'.$phpEx) ) ? 'english' : $board_config['default_lang'];
include($phpbb_root_path . 'language/lang_' . $use_lang . '/lang_weblog_main.' . $phpEx);

//
// Preload all Weblog Config data
//
$sql = "SELECT *
	FROM " . WEBLOG_CONFIG_TABLE;
if( !($result = $db->sql_query($sql)) )
{
	message_die(CRITICAL_ERROR, "Could not query config information", "", __LINE__, __FILE__, $sql);
}

while ( $row = $db->sql_fetchrow($result) )
{
	$weblog_config[$row['config_name']] = $row['config_value'];
}

//
// Load the template data
//
// Get template data and check to see if there is at least one template installed.
$sql = "SELECT * FROM " . WEBLOG_TEMPLATES_TABLE . " ORDER BY template_name";
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$template_data = array();
while ( $row = $db->sql_fetchrow($result) )
{
	$template_data[] = $row;
}

$weblog_auth_types = array($lang['Weblog_auth_all'], $lang['Weblog_auth_reg'], $lang['Weblog_auth_friends'], $lang['Weblog_auth_owner']);
$weblog_fonts = array('Arial', 'Comic Sans MS', 'Courier New', 'Georgia', 'Verdana', 'Times New Roman', 'Trebuchet MS');
?>