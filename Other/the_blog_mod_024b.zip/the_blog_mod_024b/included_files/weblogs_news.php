<?php

/***************************************************************************
 *                               weblogs_news.php
 *                            ------------------------
 *			  : Unknow contributor
 *
 *   forum		  : http://www.TheBlogMod.com community
 *   email		  : Managed by support [at] TheBlogMod.com
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/


// standard hack prevent
define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/bbcode.'.$phpEx);

//
// Setup initial page vars
//

$start = ( isset($HTTP_GET_VARS['start']) ) ? intval($HTTP_GET_VARS['start']) : 0;

$pagination = '&';
$pagination_replies = '&';
$total_entry_items = 1;
$total_reply_items = 1;

if( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) || isset($HTTP_POST_VARS[POST_WEBLOG_URL]) )
{
	$weblog_id = ( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) ) ? intval($HTTP_GET_VARS[POST_WEBLOG_URL]) : intval($HTTP_POST_VARS[POST_WEBLOG_URL]);
	$username = '';
}
else if( isset($HTTP_GET_VARS[POST_USERS_URL]) || isset($HTTP_POST_VARS[POST_USERS_URL]) )
{
	$username = ( isset($HTTP_GET_VARS[POST_USERS_URL]) ) ? htmlspecialchars($HTTP_GET_VARS[POST_USERS_URL]) : intval($HTTP_POST_VARS[POST_USERS_URL]);
	$weblog_id = 0;
}
else
{
	$username = '';
	$weblog_id = 0;
}

//
// End Setup initial page vars
//

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

// Page title
$page_title = $lang['Weblogs_news'];

// Include Page header
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

// Assign template file
$template->set_filenames(array(
        'body' => 'weblogs_news.tpl')
);

//
// Get the moods data
//
$sql = "SELECT *
	FROM " . WEBLOG_MOODS_TABLE . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

//
// Get the actions data
//
$sql = "SELECT *
	FROM " . WEBLOG_ACTIONS_TABLE . "
	ORDER BY action_text";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain action data from database", "", __LINE__, __FILE__, $sql);
}
$action_data = $db->sql_fetchrowset($result);


//
// Get contributor data (copied from weblog.php)
//
$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE weblog_id = $weblog_id AND user_id = " . $userdata['user_id'];
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$contributor = FALSE;
if ( $row = $db->sql_fetchrow($result) || $userdata['user_level'] == ADMIN )
{
	$contributor = TRUE;
}

// Get the user's clearence levels
$auth_level = get_auth_level ( $weblog_data, $friends_data, $blocked_data, $weblog_data['user_id'], $contributor );

// See if user can see this weblog
if ( $weblog_data['weblog_auth'] > $auth_level )
{
	message_die(GENERAL_ERROR, $lang['Weblog_noaccess']);
}


//
// Latest Entries
//

if ( $weblog_config['show_latest_entries'] )
{
	$sql = "SELECT e.entry_id, e.entry_access, e.entry_subject, e.entry_time, e.entry_views, e.entry_poster_id, e.entry_text, e.bbcode_uid, e.entry_mood, e.entry_currently, e.currently_text, e.entry_replies, u.user_id, u.username
			FROM " . WEBLOG_ENTRIES_TABLE . " AS e, " . USERS_TABLE . " AS u
			WHERE entry_access <= $auth_level
			AND e.entry_poster_id = u.user_id
			AND e.entry_deleted <> " . TRUE . "
			ORDER BY entry_id DESC
			LIMIT $start, " . $weblog_config['latest_entry_max'];
			if (!$result = $db->sql_query($sql))
			{
				message_die(GENERAL_ERROR, 'Could not query blog information', '', __LINE__, __FILE__, $sql);
			}

			$blogs = $db->sql_numrows($result);
			$blog_row = array();
			while ($row = $db->sql_fetchrow($result))
			{
				$blog_row[] = $row;
			}

			$template->assign_block_vars('switch_show_latest_entries', array());

			for ($i = 0; $i < $blogs; $i++)
			{
				if ( $blog_row[$i]['entry_text'] )
				{
					$last_entry_data = $blog_row[$i];

					// Mood
					$mood = array();
					$mood = find_mood($last_entry_data['entry_mood']);

					if ( $mood >= 0 )
					{
						$mood = sprintf($lang['Mood:'], '<img src="images/weblogs/' . $mood['mood_url'] . '" alt="' . $mood_data['mood_text'] . '" style="vertical-align: middle" border="0" />', $mood['mood_text']);
					}
					else
					{
						$mood = $lang['None'];
					}

					// Currently Icons
					$currently = array();
					$currently = find_action($last_entry_data['entry_currently']);

					if ( $currently > 0 )
					{
						$action = sprintf($lang['Currently:'], '<img src="images/weblogs/' . $currently['action_url'] . '" alt="' . $currently['action_text'] . ' ' . $last_entry_data['currently_text'] . '" style="vertical-align: middle" border="0" />',  $currently['action_text'] . ' ' . $last_entry_data['currently_text']);
					}
					else if ( $last_entry_data['currently_text'] && $currently == -2 )
					{
						$action = sprintf($lang['Currently:'], '', $last_entry_data['currently_text']);
					}
					else
					{
						$action = '';
					}
				}

				// Guest - show a hot folder image if number of replies exceeds hot level
				$replies = $blog_row[$i]['entry_replies'];
				if($replies >= $weblog_config['hot_level'])
				{
					$folder = $images['folder_hot'];
				}
				else
				{
					$folder = $images['folder'];
				}

				// User is logged in - check for new entries since last visit
				// and show a hot new folder image if new entry and number of replies exceeds hot level.
				// If just new entry then show the new folder image - else just show the folder image
				$newest_post_img = '';
				if( $userdata['session_logged_in'] )
				{
					if( $blog_row[$i]['entry_time'] > $userdata['user_lastvisit'] && $replies >= $weblog_config['hot_level'])
					{
						$folder = $images['folder_hot_new'];
						$newest_post_img = '<a href="' . append_sid("weblog_entry.$phpEx?" . 'e' . '=' . $blog_row[$i]['entry_id']) . '"><img src="' . $images['icon_newest_reply'] . '" border="0" /></a> ';
					}
					elseif( $blog_row[$i]['entry_time'] > $userdata['user_lastvisit'])
					{
						$folder = $images['folder_new'];
						$newest_post_img = '<a href="' . append_sid("weblog_entry.$phpEx?" . 'e' . '=' . $blog_row[$i]['entry_id']) . '"><img src="' . $images['icon_newest_reply'] . '" border="0" /></a> ';
					}
					elseif($replies >= $weblog_config['hot_level'])
					{
						$folder = $images['folder_hot'];
					}
					else
					{
						$folder = $images['folder'];
						$newest_post_img = '';
					}
				}

		$entry_poster = '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . "u" . "=" . $blog_row[$i]['user_id']) . '">' . $blog_row[$i]['username'] . '</a>';

		// Has admin enabled currently in the entry block? If yes, then adjust colspan
		if ( $weblog_config['show_action'] )
		{
			$colspan = 2;
		}
		else
		{
			$colspan = 1;
		}

		$row_color = ( !($i % 2) ) ? $theme['td_color1'] : $theme['td_color2'];
		$row_class = ( !($i % 2) ) ? $theme['td_class1'] : $theme['td_class2'];
		$template->assign_block_vars('switch_show_latest_entries.blog_row', array(
			'ENTRY_FOLDER_IMG' => $folder,
			'NEWEST_POST_IMG' => $newest_post_img,
			'ROW_COLOR' => $row_color,
			'ROW_CLASS' => $row_class,
			'LATEST_MOOD' => $mood,
			'U_LATEST_ENTRY' => append_sid("weblog_entry.$phpEx?" . 'e' . '=' . $blog_row[$i]['entry_id']),
			'L_LATEST_ENTRIES' => $blog_row[$i]['entry_subject'],
			'L_ENTRY_TEXT' => $blog_row[$i]['entry_text'],
			'L_ENTRY_REPLIES' => $blog_row[$i]['entry_replies'],
			'L_VIEWS' => $blog_row[$i]['entry_views'],
			'S_POSTER' => $entry_poster,
			'S_POSTTIME' => create_date($board_config['default_dateformat'], $blog_row[$i]['entry_time'], $board_config['board_timezone'])
			)
		);

		// Has admin enabled action in the entry block?
		if ( $weblog_config['show_action'] )
		{
			$template->assign_block_vars('switch_show_latest_entries.blog_row.switch_show_action', array(
			'LATEST_ACTION' => $action)
			);
		}
	}
}

//
// Latest Replies
//

// This one is really goofy - if Entry Block is on, disable pagination for replies.
if ( $weblog_config['show_latest_entries'] )
{
	$start_reply = '';
}
else
{
	$start_reply = "$start,";
}
//
$sql = "SELECT r.reply_id, r.entry_id, r.poster_id, r.post_time, r.post_username, r.reply_text, r.bbcode_uid, r.enable_bbcode, r.enable_smilies, u.user_id, u.username, u.user_weblog, e.entry_id, e.weblog_id, e.entry_subject, e.entry_access, e.entry_replies, w.weblog_id, w.weblog_name
		FROM " . WEBLOG_REPLIES_TABLE . " AS r, " . USERS_TABLE . " AS u, " . WEBLOG_ENTRIES_TABLE . " AS e, " . WEBLOGS_TABLE . " AS w
		WHERE entry_access  <= $auth_level
		AND r.poster_id = u.user_id
		AND e.entry_id = r.entry_id
		AND e.weblog_id = w.weblog_id
		AND entry_deleted <> " . TRUE . "
		ORDER BY reply_id DESC
		LIMIT $start_reply " . $weblog_config['latest_reply_max'];
		if (!$result = $db->sql_query($sql))
		{
			message_die(GENERAL_ERROR, 'Could not query blog information', '', __LINE__, __FILE__, $sql);
		}

		$replies = $db->sql_numrows($result);
		$replies_row = array();
		while ($row = $db->sql_fetchrow($result))
		{
			$replies_row[] = $row;
		}

if ( $weblog_config['show_latest_replies'] )
{
	$template->assign_block_vars('switch_show_latest_replies', array());

	for ($i = 0; $i < $replies; $i++)
	{
		// BBCode
		if ( $board_config['allow_bbcode'] )
		{
			if ( $replies_row[$i]['enable_bbcode'] )
			{
				$replies_row[$i]['reply_text'] = ( $replies_row[$i]['bbcode_uid'] ) ? bbencode_second_pass($replies_row[$i]['reply_text'], $replies_row[$i]['bbcode_uid']) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $replies_row[$i]['reply_text']);
			}
		}

		$replies_row[$i]['reply_text'] = make_clickable($replies_row[$i]['reply_text']);

		// Smilies
		if ( $board_config['allow_smilies'] )
		{
			if ( $replies_row[$i]['enable_smilies'] )
			{
				$replies_row[$i]['reply_text'] = smilies_pass($replies_row[$i]['reply_text']);
			}
		}

		// User is anonymous but enters a name
		if ( $replies_row[$i]['poster_id'] == '-1' && $replies_row[$i]['post_username'] != '' )
		{
			$poster = $replies_row[$i]['post_username'];
		}
		else
		{
			$poster = '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . "u" . "=" . $replies_row[$i]['user_id']) . '">' . $replies_row[$i]['username'] . '</a>';
		}

		// Hot or not
		$replies_replies = $replies_row[$i]['entry_replies'];

		if($replies_replies  >= $weblog_config['hot_level'])
		{
			$folder = $images['folder_hot'];
		}
		else
		{
			$folder = $images['folder'];
		}

		// User is logged in - check for new replies since last visit
		// and show a hot new folder image if new reply and number of replies exceeds hot level.
		// If just new reply then show the new folder image - else just show the folder image
		$newest_post_img = '';
		if( $userdata['session_logged_in'] )
		{
			if( $replies_row[$i]['post_time'] > $userdata['user_lastvisit'] && $replies_replies >= $weblog_config['hot_level'])
			{
				$folder = $images['folder_hot_new'];
				$newest_post_img = '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_REPLY_URL . '=' . $replies_row[$i]['reply_id'] . '#' . $replies_row[$i]['reply_id']) . '"><img src="' . $images['icon_newest_reply'] . '" border="0" /></a> ';
			}

			elseif( $replies_row[$i]['post_time'] > $userdata['user_lastvisit'])
			{
				$folder = $images['folder_new'];
				$newest_post_img = '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_REPLY_URL . '=' . $replies_row[$i]['reply_id'] . '#' . $replies_row[$i]['reply_id']) . '"><img src="' . $images['icon_newest_reply'] . '" border="0" /></a> ';
			}

			elseif($replies_replies >= $weblog_config['hot_level'])
			{
				$folder = $images['folder_hot'];
			}
			else
			{
				$folder = $images['folder'];
				$newest_post_img = '';
			}
		}

		// Alternating row colors
		$row_color = ( !($i % 2) ) ? $theme['td_color1'] : $theme['td_color2'];
		$row_class = ( !($i % 2) ) ? $theme['td_class1'] : $theme['td_class2'];

		// Send the loopdata to the template
		$template->assign_block_vars('switch_show_latest_replies.replies_row', array(
			'REPLY_FOLDER_IMG' => $folder,
			'NEWEST_POST_IMG' => $newest_post_img,
			'ROW_COLOR' => $row_color,
			'ROW_CLASS' => $row_class,
			'U_LATEST_REPLY' => append_sid("weblog_entry.$phpEx?" . POST_REPLY_URL . '=' . $replies_row[$i]['reply_id'] . '#' . $replies_row[$i]['reply_id']),
			'U_BLOG_NAME' => append_sid("weblog.$phpEx?" . 'w' . '=' . $replies_row[$i]['weblog_id']),
			'L_LATEST_REPLY' => $replies_row[$i]['entry_subject'],
			'L_BLOG_NAME' => $replies_row[$i]['weblog_name'],
			'S_POSTER' => $poster,
			'S_REPLYTIME' => create_date($board_config['default_dateformat'], $replies_row[$i]['post_time'], $board_config['board_timezone'])
			)
		);

		// Has admin enabled comments in the reply block?
		if ( $weblog_config['show_comments'] )
		{
			$template->assign_block_vars('switch_show_latest_replies.replies_row.switch_show_comments', array(
			'L_REPLY_TEXT' => $replies_row[$i]['reply_text'])
			);
		}
	}
}

// If Admin chooses not to show any blocks on the Weblog News page, show the un-suspecting user a nice message
if ( !$weblog_config['show_latest_entries'] && !$weblog_config['show_latest_replies'] )
{
	$template->assign_block_vars('switch_no_blocks', array());
}

// Pagination. Only run this if entries are on. Else, save a query
if ( $weblog_config['show_latest_entries'] )
{
	$sql = "SELECT count(*) AS total
			FROM " . WEBLOG_ENTRIES_TABLE . "
			WHERE entry_access <= $auth_level
			AND entry_deleted <> " . TRUE . "";

	if ( !($result = $db->sql_query($sql)) )
	{
	   message_die(GENERAL_ERROR, 'Error getting total entries', '', __LINE__, __FILE__, $sql);
	}

	if ( $total = $db->sql_fetchrow($result) )
	{
	   $total_entry_items = $total['total'];
	   $pagination = generate_pagination("weblogs_news.php?$mode=$mode&order=$sort_order", $total_entry_items, $weblog_config['latest_entry_max'], $start);
	}
	$template->assign_vars(array(
	'PAGINATION' => $pagination,
	'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $weblog_config['latest_entry_max'] ) + 1 ), ceil( $total_entry_items / $weblog_config['latest_entry_max'] ))
	)
);
}

// Pagination Replies. Only run this if entries are off. Else save a query
// and a lot of trouble. Assign alternate text to template. Think of a better way to do this.
if ( !$weblog_config['show_latest_entries'] )
{
	$sql = "SELECT count(*) AS total
			FROM " . WEBLOG_REPLIES_TABLE . "";

	if ( !($result = $db->sql_query($sql)) )
	{
	   message_die(GENERAL_ERROR, 'Error getting total replies', '', __LINE__, __FILE__, $sql);
	}

	if ( $total = $db->sql_fetchrow($result) )
	{
	   $total_reply_items = $total['total'];
	   $pagination_replies = generate_pagination("weblogs_news.php?$mode=$mode&order=$sort_order", $total_reply_items, $weblog_config['latest_reply_max'], $start);
	}

	$template->assign_vars(array(
		'PAGINATION_REPLIES' => $pagination_replies,
		'PAGE_NUMBER_REPLIES' => sprintf($lang['Page_of'], ( floor( $start / $weblog_config['latest_reply_max'] ) + 1 ), ceil( $total_reply_items / $weblog_config['latest_reply_max'] ))
		)
	);
}

make_jumpbox('viewforum.'.$phpEx);

// Send stuff to the template
$template->assign_vars(array(
	'L_NO_ACCESS' => $lang['Weblog_noaccess'],
	'L_LASTPOST' => $lang['Last_Post'],
	'L_LATEST_ENTRIES' => $lang['Latest_entries'],
	'L_WEBLOGS_PER_PAGE' => $lang['Weblogs_perpage'],
	'L_SORT' => $lang['Sort'],
	'L_GO' => $lang['Go'],
	'L_WEBLOGS_NEWS' => $lang['Weblogs_news'],
	'L_ENTRY' => $lang['Entry'],
	'L_REPLY' => $lang['Reply'],
	'L_WEBLOG' => $lang['Weblog'],
	'L_OWNER' => $lang['Weblog_Owner'],
	'L_AUTHOR' => $lang['Author'],
	'L_VIEWS'=> $lang['Views'],
	'L_REPLIES' => $lang['Replies'],
	'L_LAST_ENTRY' => $lang['Last_entry'],
	'L_LATEST_MOOD' => $lang['Latest_mood'],
	'L_MARK_ALL_ENTRIES' => $lang['Mark_all_entries'],
	'L_MARK_ALL_REPLIES' => $lang['Mark_all_replies'],
	'S_NEWS_COLSPAN' => $colspan,
	'S_NO_BLOCKS' => $weblog_config['no_blocks_text']
	)
);

$template->pparse('body');


// Include the page footer
include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>