<?php
/***************************************************************************
 *                               trackback.php
 *                            -------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *
 *   forum		  : http://www.blogpoint.com
 *   email		  : Managed by support [at] blogpoint.com
 *
 *   $Id: trackback.php,v 1.0.1 2006/01/29, 22:07:01 support at blogpoint.com (former Hyperion) Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_trackback.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

define('HEADER_INC', TRUE);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if ( isset($HTTP_GET_VARS[POST_ENTRY_URL]) || isset($HTTP_POST_VARS[POST_ENTRY_URL]) )
{
	$entry_id = (isset($HTTP_POST_VARS[POST_ENTRY_URL])) ? intval($HTTP_POST_VARS[POST_ENTRY_URL]) : intval($HTTP_GET_VARS[POST_ENTRY_URL]);
}
else
{
	// Someone tried to access page directly
	$page_title = $lang['Weblog_index'];
	include($phpbb_root_path . 'includes/page_header.'.$phpEx);
	message_die(GENERAL_MESSAGE, $lang['Entry_post_not_exist']);
}

// Do an sql query to determine if the entry is public, and thus eligible to have trackbacks
$sql = "SELECT e.entry_access, w.weblog_auth FROM " . WEBLOGS_TABLE . " w, " . WEBLOG_ENTRIES_TABLE . " e 
  WHERE e.entry_id = " . $entry_id . " 
   AND e.weblog_id = w.weblog_id 
   AND e.entry_access = " . WEBLOG_AUTH_ALL . " 
   AND w.weblog_auth = " . WEBLOG_AUTH_ALL;
if ( !($result = $db->sql_query($sql)) )
{
	echo trackback_response(false, 'Server Error, please contact the site\'s Administrator', $lang['ENCODING']);
	//message_die(GENERAL_ERROR, 'Server Error, please contact the site\'s Administrator', '', __LINE__, __FILE__, $sql);
	exit;
}

if ( !$db->sql_fetchrow($result) )
{
	echo trackback_response(false, $lang['Entry_post_not_exist'], $lang['ENCODING']);
	exit;
}

// Set page header to XML
header('Content-Type: text/xml');

//
// Get trackback information
//
$url = trim($_REQUEST['url']);
$weblog_name = trim($_REQUEST['blog_name']);
$title = trim($_REQUEST['title']);
$excerpt = trim($_REQUEST['excerpt']);

if ( empty($url) && empty($weblog_name) && empty($title) && empty($excerpt) )
{
	echo trackback_response(false, $lang['Fields_empty'], $lang['ENCODING']);
	exit;
}

// Find maximum trackback id
$sql = "SELECT MAX(tb_id) AS maximum FROM " . WEBLOG_TRACKBACKS_TABLE;
if ( !($result = $db->sql_query($sql)) )
{
	echo trackback_response(false, 'Server Error, please contact the site\'s Administrator', $lang['ENCODING']);
	//message_die(GENERAL_ERROR, 'Server Error, please contact the site\'s Administrator', '', __LINE__, __FILE__, $sql);
	exit;
}

$maximum = 0;
if ( $row = $db->sql_fetchrow($result) )
{
	$maximum = 0;
	$maximum = $row['maximum'];
}

$sql = "INSERT INTO " . WEBLOG_TRACKBACKS_TABLE . " (tb_id, tb_entry, tb_blog, tb_time, tb_excerpt, tb_url, tb_title) 
   VALUES (" . ($maximum + 1) . ", " . $entry_id . ", '" . $weblog_name . "', " . time() . ", '" . $excerpt . "', '" . $url . "', '" . $title . "')";
if ( !($result = $db->sql_query($sql)) )
{
	echo trackback_response(false, 'Could not log Trackback in database', $lang['ENCODING']);
	//message_die(GENERAL_ERROR, 'Could not log Trackback in database', '', __LINE__, __FILE__, $sql);
	exit;
}

//
// Increment the entry's trackback count
//
$sql = "UPDATE " . WEBLOG_ENTRIES_TABLE . "
	SET entry_trackbacks = entry_trackbacks + 1
	WHERE entry_id = $entry_id";
if( !$result = $db->sql_query($sql) )
{
	echo trackback_response(false, 'Trackback succesful but could not increase trackback counter in database', $lang['ENCODING']);
	//message_die(GENERAL_ERROR, "Couldn't update weblog entries information.", "", __LINE__, __FILE__, $sql);
}

echo trackback_response(true, '', $lang['ENCODING']);

exit;

?>