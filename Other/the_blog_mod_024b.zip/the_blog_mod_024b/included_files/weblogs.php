<?php
/***************************************************************************
 *                               weblogs.php
 *                            -----------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   email                : vinng86@hotmail.com
 *
 *   forum		  : http://www.TheBlogMod.com community
 *   email		  : Managed by support [at] TheBlogMod.com
 *
 *   $Id: weblogs.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

//
// Begin initial var setup
//
if ( isset($HTTP_GET_VARS['count']) || isset($HTTP_POST_VARS['count']) )
{
	$w_count = (isset($HTTP_POST_VARS['count'])) ? intval($HTTP_POST_VARS['count']) : intval($HTTP_GET_VARS['count']);
}
else
{
	$w_count = $weblog_config['main_blogsperpage'];
}

if ( $w_count < 1 )
{
	$w_count = 1;
}

if ( isset($HTTP_GET_VARS['start']) || isset($HTTP_POST_VARS['start']) )
{
	$start = (isset($HTTP_POST_VARS['start'])) ? intval($HTTP_POST_VARS['start']) : intval($HTTP_GET_VARS['start']);
	$start = abs($start);
}
else
{
	$start = 0;
}

if ( isset($HTTP_GET_VARS['sort']) || isset($HTTP_POST_VARS['sort']) )
{
	$sort = (isset($HTTP_POST_VARS['sort'])) ? intval($HTTP_POST_VARS['sort']) : intval($HTTP_GET_VARS['sort']);
}
else
{
	$sort = $weblog_config['main_sorttype'];
}

if ( isset($HTTP_GET_VARS['order']) || isset($HTTP_POST_VARS['order']) )
{
	$order = (isset($HTTP_POST_VARS['order'])) ? $HTTP_POST_VARS['order'] : $HTTP_GET_VARS['order'];
	$order = ( $order == 'asc' || $order == 'desc' ) ? $order : 'desc';
}
else
{
	$order = $weblog_config['main_sortorder'];
}

//
// End initial var setup
//

//
// Start page proper
//
$page_title = $lang['Weblog_index'];
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$tracking_entries = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . "_e"]) : array();
$tracking_weblogs = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . "_w"]) : array();

//
// Get the moods data
//
$sql = "SELECT *
	FROM " . WEBLOG_MOODS_TABLE . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

//
// Get the actions data
//
$sql = "SELECT *
	FROM " . WEBLOG_ACTIONS_TABLE . "
	ORDER BY action_text";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain action data from database", "", __LINE__, __FILE__, $sql);
}
$action_data = $db->sql_fetchrowset($result);

//
// Load the template data
//
// Get template data and check to see if there is at least one template installed.
$sql = "SELECT * FROM " . WEBLOG_TEMPLATES_TABLE . " ORDER BY template_name";
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$template_data = array();
while ( $row = $db->sql_fetchrow($result) )
{
	$template_data[] = $row;
}

if ( $userdata['session_logged_in'] )
{
	//
	// Fetch Weblog Information
	//
	$sql = "SELECT w.*, u.*
		FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
		WHERE w.weblog_id = u.user_weblog
			AND u.user_id = " . $userdata['user_id'];
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not query user weblog information', '', __LINE__, __FILE__, $sql);
	}

	$user_weblog_data = array();
	if ( $row = $db->sql_fetchrow($result) )
	{
		$user_weblog_data = $row;

		if ( $weblog_config['use_default_faceplates'] )
		{
			$template->set_filenames(array(
				'user' => 'weblog_faceplate_body.tpl')
			);
		}
		else
		{
			// See if the weblog owner's face file is available
			if ( $user_weblog_data['weblog_advanced'] )
			{
				if ( file_exists("weblogs/faceplate_" . $user_weblog_data['weblog_id'] . ".htm") )
				{
					$template->set_filenames(array(
						'user' => '../../weblogs/faceplate_' . $user_weblog_data['weblog_id'] . '.htm')
					);
				}
				else
				{
					// Otherwise show a default face image.
					$template->set_filenames(array(
						'user' => 'weblog_faceplate_body.tpl')
					);
				}
			}
			else
			{
				$template_dir = get_template_dir ($user_weblog_data['template_id']);

				$template->set_filenames(array(
					'user' => '../../weblogs/templates/' . $template_dir . '/weblog_faceplate_body.htm')
				);
			}
		}
	}
	else
	{
		$template->set_filenames(array(
			'user' => 'weblog_index_noweblog.tpl')
		);

		if ( !$userdata['session_logged_in'] )
		{
			$lang_create = $lang['No_weblog_guests'];
		}
		else if ( !$userdata['user_allowweblog'] )
		{
			$lang_create = $lang['Weblog_banned'];
		}
		else
		{
			$lang_create = $lang['No_weblog_create'];
		}

		$template->assign_vars(array(
			'L_NO_WEBLOG_CREATE' => sprintf($lang['No_weblog_create'], '<a href="' . append_sid("weblog_config.$phpEx") . '" class="mainmenu">', '</a>'))
		);
	}

	$weblog_id = $user_weblog_data['weblog_id'];

	$avatar_img = '';
	if ( $userdata['user_avatar_type'] && $userdata['user_allowavatar'] )
	{
		switch( $userdata['user_avatar_type'] )
		{
			case USER_AVATAR_UPLOAD:
				$avatar_img = ( $board_config['allow_avatar_upload'] ) ? '<img src="' . $board_config['avatar_path'] . '/' . $userdata['user_avatar'] . '" alt="" border="0" />' : '';
				break;
			case USER_AVATAR_REMOTE:
				$avatar_img = ( $board_config['allow_avatar_remote'] ) ? '<img src="' . $userdata['user_avatar'] . '" alt="" border="0" />' : '';
				break;
			case USER_AVATAR_GALLERY:
				$avatar_img = ( $board_config['allow_avatar_local'] ) ? '<img src="' . $board_config['avatar_gallery_path'] . '/' . $userdata['user_avatar'] . '" alt="" border="0" />' : '';
				break;
		}
	}

	// Viewer of own weblog presumed to have maximum authentication...
	$sql = "SELECT * FROM " . WEBLOG_ENTRIES_TABLE . "
		WHERE weblog_id = " . $userdata['user_weblog'] . " 
			AND entry_deleted <> " . TRUE . "
		ORDER BY entry_time DESC LIMIT 1";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not query user weblog information', '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$last_entry_data = $row;

		$mood = array();
		$mood = find_mood($last_entry_data['entry_mood']);

		if ( $mood >= 0 )
		{ 
			$mood = sprintf($lang['Mood:'], '<img src="images/weblogs/' . $mood['mood_url'] . '" alt="' . $mood_data['mood_text'] . '" style="vertical-align: middle" border="0" />', $mood['mood_text']);
		}
		else
		{
			$mood = $lang['None'];
		}

		// Currently Icons
		$currently = array();
		$currently = find_action($last_entry_data['entry_currently']);

		if ( $currently > 0 )
		{
			$action = sprintf($lang['Currently:'], '<img src="images/weblogs/' . $currently['action_url'] . '" alt="' . $currently['action_text'] . ' ' . $last_entry_data['currently_text'] . '" style="vertical-align: middle" border="0" />',  $currently['action_text'] . ' ' . $last_entry_data['currently_text']); 
		}
		else if ( $last_entry_data['currently_text'] && $currently == -2 )
		{
			$action = sprintf($lang['Currently:'], '', $last_entry_data['currently_text']);
		}
		else
		{
			$action = $lang['None'];
		}

		$entry_id = $last_entry_data['entry_id'];

		$last_entry_time = create_date($board_config['default_dateformat'], $last_entry_data['entry_time'], $board_config['board_timezone']);

		$last_entry_time .= '&nbsp;<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '"><img src="' . $images['icon_latest_reply'] . '" alt="' . $lang['View_newest_entry'] . '" title="' . $lang['View_newest_entry'] . '" border="0" /></a>';

		$last_entry = $last_entry_time;
	}
	else
	{
		$last_entry = $lang['No_entries'];
		$action = $lang['None'];
		$mood = $lang['None'];
	}

	if ( $user_weblog_data['font'] == '0' )
		$font = 'Arial';
	else if ( $user_weblog_data['font'] == '1' )
		$font = 'Comic Sans MS';
	else if ( $user_weblog_data['font'] == '2' )
		$font = 'Courier New';
	else if ( $user_weblog_data['font'] == '3' )
		$font = 'Georgia';
	else if ( $user_weblog_data['font'] == '4' )
		$font = 'Verdana';
	else if ( $user_weblog_data['font'] == '5' )
		$font = 'Times New Roman';
	else if ( $user_weblog_data['font'] == '6' )
		$font = 'Trebuchet';
	else
		$font = 'Verdana';

	$template->assign_vars(array(
		'ID' => 'user',
		'BACKGROUND_COLOR' => $user_weblog_data['background_color'],
		'ENTRY_BG_COLOR' => $user_weblog_data['entry_bg_color'],
		'BORDER_COLOR' => $user_weblog_data['border_color'],
		'BACKGROUND_IMAGE' => $user_weblog_data['background_image'],
		'BACKGROUND_IMAGE_FIXED' => ( $user_weblog_data['background_image_fixed'] ) ? 'fixed' : 'scroll',
		'BACKGROUND_REPEAT' => $user_weblog_data['tile_bg'],
		'BACKGROUND_POSITION' => $user_weblog_data['bg_ypos'] . ' ' . $user_weblog_data['bg_xpos'],
		'SB_FACE_COLOR' => $user_weblog_data['sb_face_color'],
		'SB_HIGHLIGHT_COLOR' => $user_weblog_data['sb_highlight_color'],
		'SB_SHADOW_COLOR' => $user_weblog_data['sb_shadow_color'],
		'SB_3DLIGHT_COLOR' => $user_weblog_data['sb_3dlight_color'],
		'SB_ARROW_COLOR' => $user_weblog_data['sb_arrow_color'],
		'SB_TRACK_COLOR' => $user_weblog_data['sb_track_color'],
		'SB_DARKSHADOW_COLOR' => $user_weblog_data['sb_darkshadow_color'],
		'FONT' => $font,
		'FONT_COLOR' => $user_weblog_data['font_color'],
		'FONT_SIZE' => $user_weblog_data['font_size'],
		'NORMAL_LINK_COLOR' => $user_weblog_data['normal_link_color'],
		'NORMAL_LINK_UNDERLINED' => ( $user_weblog_data['normal_link_underline'] ) ? 'underline' : 'none',
		'ACTIVE_LINK_COLOR' => $user_weblog_data['active_link_color'],
		'ACTIVE_LINK_UNDERLINED' => ( $user_weblog_data['active_link_underline'] ) ? 'underline': 'none',
		'HOVER_LINK_COLOR' => $user_weblog_data['hover_link_color'],
		'HOVER_LINK_UNDERLINED' => ( $user_weblog_data['hover_link_underline'] ) ? 'underline': 'none',
		'VISITED_LINK_COLOR' => $user_weblog_data['visited_link_color'],
		'VISITED_LINK_UNDERLINED' => ( $user_weblog_data['visited_link_underline'] ) ? 'underline': 'none',
		'WEBLOG_TITLE_COLOR' => $user_weblog_data['weblog_title_color'],
		'WEBLOG_TITLE_FONT_SIZE' => $user_weblog_data['weblog_title_font_size'],
		'ENTRY_TITLE_COLOR' => $user_weblog_data['entry_title_color'],
		'ENTRY_TITLE_FONT_SIZE' => $user_weblog_data['entry_title_font_size'],
		'DATE_TIME_COLOR' => $user_weblog_data['date_time_color'],
		'DATE_TIME_FONT_SIZE' => $user_weblog_data['date_time_font_size'],
		'BLOCK_TITLE_COLOR' => $user_weblog_data['block_title_color'],
		'BLOCK_TITLE_FONT_SIZE' => $user_weblog_data['block_title_font_size'],
		'BLOCK_BG_COLOR' => $user_weblog_data['block_bg_color'],
		'BLOCK_BORDER_COLOR' => $user_weblog_data['block_border_color'],

		'WEBLOG_NAME' => $lang['Your_weblog'],
		'AVATAR_IMG' => $avatar_img,
		'WEBLOG_OWNER' => $user_weblog_data['username'],
		'WEBLOG_DESCRIPTION' => $user_weblog_data['weblog_desc'],

		'U_VIEW_WEBLOG' => append_sid ("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $user_weblog_data['weblog_id']),
		'U_WEBLOG_RSS' => append_sid ("weblog_rss.$phpEx?" . POST_WEBLOG_URL . "=" . $user_weblog_data['weblog_id']),

		'LAST_ENTRY' => $last_entry,
		'LATEST_MOOD' => $mood,
		'LAST_SEEN' => $action)
	);
}
else
{
	$template->set_filenames(array(
		'user' => 'weblog_index_noweblog.tpl')
	);

	if ( !$userdata['session_logged_in'] )
	{
		$lang_create = $lang['No_weblog_guests'];
	}
	else if ( !$userdata['user_allowweblog'] )
	{
		$lang_create = $lang['Weblog_banned'];
	}
	else
	{
		$lang_create = $lang['No_weblog_create'];
	}

	$template->assign_vars(array(
		'L_NO_WEBLOG_CREATE' => sprintf($lang_create, '<a href="' . append_sid("weblog_config.$phpEx") . '" class="mainmenu">', '</a>'))
	);
}

//
// Weblog Listing Code
//
$num_weblogs = array(1, 2, 3, 4, 5, 10, 20, 30, 40, 50, 100);

$select_num_weblogs = '<select name="count">';
for($i = 0; $i < count($num_weblogs); $i++)
{
	$selected = ( $w_count == $num_weblogs[$i] ) ? ' selected="selected"' : '';
	$select_num_weblogs .= '<option value="' . $num_weblogs[$i] . '"' . $selected . '>' . $num_weblogs[$i] . '</option>';
}
$select_num_weblogs .= '</select>';

$sort_method = array(SORT_NEWEST_ENTRIES, SORT_WEBLOG_NAME, SORT_NUM_ENTRIES, SORT_WEBLOG_START_DATE, SORT_WEBLOG_VIEWS);
$sort_method_text = array($lang['Sort_newest_entries'], $lang['Sort_weblog_name'], $lang['Sort_num_entries'], $lang['Sort_weblog_start_date'], $lang['Sort_weblog_views']);

$select_sort = '<select name="sort">';
for($i = 0; $i < count($sort_method); $i++)
{
	$selected = ( $sort == $sort_method[$i] ) ? ' selected="selected"' : '';
	$select_sort .= '<option value="' . $sort_method[$i] . '"' . $selected . '>' . $sort_method_text[$i] . '</option>';
}
$select_sort .= '</select>';

$sort_order = array('desc', 'asc');
$sort_order_text = array($lang['Sort_Descending'], $lang['Sort_Ascending']);

$select_asc_desc = '<select name="order">';
for($i = 0; $i < count($sort_order); $i++)
{
	$selected = ( strtolower($order) == $sort_order[$i] ) ? ' selected="selected"' : '';
	$select_asc_desc .= '<option value="' . $sort_order[$i] . '"' . $selected . '>' . $sort_order_text[$i] . '</option>';
}
$select_asc_desc .= '</select>';

//
// BEGIN
//

switch ( $sort )
{
	case SORT_NEWEST_ENTRIES: 	$sort = 'e.entry_time'; break;
	case SORT_WEBLOG_NAME: 		$sort = 'w.weblog_name'; break;
	case SORT_NUM_ENTRIES: 		$sort = 'w.weblog_entries'; break;
	case SORT_WEBLOG_START_DATE:	$sort = 'w.weblog_create_date'; break;
	case SORT_WEBLOG_VIEWS:		$sort = 'w.weblog_views'; break;
	case SORT_WEBLOG_OWNER_NAME:	$sort = 'u.username'; break;
	default: 				$sort = 'e.entry_time'; break;
}

$weblog_data = fetch_visible_weblogs ($sort, $order);

$total_weblogs = count($weblog_data);

if ( $total_weblogs == 0 )
{
	message_die(GENERAL_MESSAGE, $lang['No_weblogs']);
}

if ( !$weblog_config['condense_index'] )
{
	$template->set_filenames(array(
		'top' => 'weblog_index_top.tpl')
	);
}
else
{
	$template->set_filenames(array(
		'top' => 'weblog_index_top_small.tpl')
	);
}

// Switch back to numeric values.
switch ( $sort )
{
	case 'e.entry_time':		$sort = SORT_NEWEST_ENTRIES; break;
	case 'w.weblog_name': 		$sort = SORT_WEBLOG_NAME; break;
	case 'w.weblog_entries':	$sort = SORT_NUM_ENTRIES; break;
	case 'w.weblog_create_date':	$sort = SORT_WEBLOG_START_DATE; break;
	case 'w.weblog_views':		$sort = SORT_WEBLOG_VIEWS; break;
	case 'u.username':		$sort = SORT_WEBLOG_OWNER_NAME; break;
	default: 				$sort = SORT_NEWEST_ENTRIES; break;
}



$template->assign_vars(array(
	'S_NUM_WEBLOGS' => $select_num_weblogs,
	'S_SORT_METHOD' => $select_sort,
	'S_SORT_ORDER' => $select_asc_desc,
	'S_SORT_ACTION' => append_sid("weblogs.$phpEx"),

	'L_NO_ACCESS' => $lang['Weblog_noaccess'],

	'L_WEBLOGS_PER_PAGE' => $lang['Weblogs_perpage'],
	'L_SORT' => $lang['Sort'],
	'L_GO' => $lang['Go'],

	'L_WEBLOG' => $lang['Weblog'],
	'L_OWNER' => $lang['Weblog_Owner'],
	'L_LAST_ENTRY' => $lang['Last_entry'],
	'L_RSS' => $lang['RSS'],

	'L_WEBLOG_DESCRIPTION' => $lang['Weblog_description'],
	'L_LAST_ENTRY' => $lang['Last_entry'],
	'L_LATEST_MOOD' => $lang['Latest_mood'],
	'L_LAST_SEEN' => $lang['Last_seen'],
	'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $w_count ) + 1 ), ceil( count($weblog_data) / $w_count )),
	'PAGINATION' => generate_pagination("weblogs.$phpEx?count=$w_count&amp;sort=$sort&amp;order=$order", count($weblog_data), $w_count, $start))
);

//
// Generate the weblog face for the viewing user
//
$template->assign_var_from_handle('YOUR_WEBLOG', 'user');

//
// Obtain a list of entry ids which contain
// posts made since user last visited
//
if ( $userdata['session_logged_in'] )
{
	$sql = "SELECT weblog_id, entry_id, entry_time 
		FROM " . WEBLOG_ENTRIES_TABLE . "
		WHERE entry_time > " . $userdata['user_lastvisit']; 
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not query new entry information', '', __LINE__, __FILE__, $sql);
	}
	
	while( $entry_data = $db->sql_fetchrow($result) )
	{
		$new_entry_data[$entry_data['weblog_id']][$entry_data['entry_id']] = $entry_data['entry_time'];
	}
	$db->sql_freeresult($result);
}

//
// Generate the last bit of the page
//
$template->pparse('top');

for ($i = $start; $i < count($weblog_data) && $i < $w_count + $start; $i++)
{
	$avatar_img = '';
	$last_entry = '';
	$mood = '';
	$action = '';
	$weblog_id = $weblog_data[$i]['weblog_id'];
	if ( $weblog_config['condense_index'] )
	{
		$template->set_filenames(array(
			$i => 'weblog_faceplate_small_body.tpl')
		);
	}
	else if ( $weblog_config['use_default_faceplates'] )
	{
		$template->set_filenames(array(
			$i => 'weblog_faceplate_body.tpl')
		);
	}
	else
	{
		if ( $weblog_data[$i]['weblog_advanced'] )
		{
			// See if the weblog owner's face file is available
			if ( @file_exists("weblogs/faceplate_$weblog_id.htm") )
			{
				$template->set_filenames(array(
					$i => "../../weblogs/faceplate_$weblog_id.htm")
				);
			}
			else
			{
				// Otherwise use a default faceplate.
				$template->set_filenames(array(
					$i => 'weblog_faceplate_body.tpl')
				);
			}
		}
		else
		{
			$template->set_filenames(array(
				$i => '../../weblogs/templates/' . get_template_dir($weblog_data[$i]['template_id']) . '/weblog_faceplate_body.htm')
			);
		}
	}

	if ( $weblog_data[$i]['user_avatar_type'] && $weblog_data[$i]['user_allowavatar'] && !$weblog_config['no_avatars_index'] )
	{
		switch( $weblog_data[$i]['user_avatar_type'] )
		{
			case USER_AVATAR_UPLOAD:
				$avatar_img = ( $board_config['allow_avatar_upload'] ) ? '<img src="' . $board_config['avatar_path'] . '/' . $weblog_data[$i]['user_avatar'] . '" alt="" border="0" />' : '';
				break;
			case USER_AVATAR_REMOTE:
				$avatar_img = ( $board_config['allow_avatar_remote'] ) ? '<img src="' . $weblog_data[$i]['user_avatar'] . '" alt="" border="0" />' : '';
				break;
			case USER_AVATAR_GALLERY:
				$avatar_img = ( $board_config['allow_avatar_local'] ) ? '<img src="' . $board_config['avatar_gallery_path'] . '/' . $weblog_data[$i]['user_avatar'] . '" alt="" border="0" />' : '';
				break;
		}
	}

	if ( $weblog_data[$i]['entry_text'] )
	{
		$last_entry_data = $weblog_data[$i];

		$mood = array();
		$mood = find_mood($last_entry_data['entry_mood']);

		if ( $mood >= 0 )
		{ 
			$mood = sprintf($lang['Mood:'], '<img src="images/weblogs/' . $mood['mood_url'] . '" alt="' . $mood_data['mood_text'] . '" style="vertical-align: middle" border="0" />', $mood['mood_text']);
		}
		else
		{
			$mood = $lang['None'];
		}

		// Currently Icons
		$currently = array();
		$currently = find_action($last_entry_data['entry_currently']);

		if ( $currently > 0 )
		{
			$action = sprintf($lang['Currently:'], '<img src="images/weblogs/' . $currently['action_url'] . '" alt="' . $currently['action_text'] . ' ' . $last_entry_data['currently_text'] . '" style="vertical-align: middle" border="0" />',  $currently['action_text'] . ' ' . $last_entry_data['currently_text']); 
		}
		else if ( $last_entry_data['currently_text'] && $currently == -2 )
		{
			$action = sprintf($lang['Currently:'], '', $last_entry_data['currently_text']);
		}
		else
		{
			$action = $lang['None'];
		}

		$unread_entries = false;
		if ( $userdata['session_logged_in'] )
		{
			if ( !empty($new_entry_data[$weblog_id]) )
			{
				$weblog_last_post_time = 0;
				
				while( list($check_entry_id, $check_post_time) = @each($new_entry_data[$weblog_id]) )
				{
					if ( empty($tracking_entries[$check_entry_id]) )
					{
						$unread_entries = true;
						$weblog_last_post_time = max($check_post_time, $weblog_last_post_time);
					}
					else
					{
						if ( $tracking_entries[$check_entry_id] < $check_post_time )
						{
							$unread_entries = true;
							$weblog_last_post_time = max($check_post_time, $weblog_last_post_time);
						}
					}
				}

				if ( !empty($tracking_weblogs[$weblog_id]) )
				{
					if ( $tracking_weblogs[$weblog_id] > $weblog_last_post_time )
					{
						$unread_entries = false;
					}
				}

				if ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w_all']) )
				{
					if ( $HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w_all'] > $weblog_last_post_time )
					{
						$unread_entries = false;
					}
				}
			}
		}

		$entry_id = $last_entry_data['entry_id'];

		$newest_post_img = '';
		if ( $unread_entries )
		{
			$newest_post_img = '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '"><img src="' . $images['icon_newest_reply'] . '" alt="' . $lang['View_newest_post'] . '" title="' . $lang['View_newest_post'] . '" border="0" /></a> ';
		}
		else
		{
			$newest_post_img = '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id") . '"><img src="' . $images['icon_latest_reply'] . '" alt="' . $lang['View_newest_post'] . '" title="' . $lang['View_newest_post'] . '" border="0" /></a> ';
		}
		

		$last_entry_time = create_date($board_config['default_dateformat'], $last_entry_data['entry_time'], $board_config['board_timezone']);

		$last_entry_time .= '&nbsp;' . $newest_post_img;

		$last_entry = $last_entry_time;
	}
	else
	{
		$mood = $lang['None'];
		$action = $lang['None'];
		$last_entry = $lang['No_entries'];
	}

	$row_class = ( date("Y m d", $last_entry_data['entry_time']) == date("Y m d", time()) ) ? $theme['td_class2'] : $theme['td_class1'];

	if ( $weblog_data[$i]['font'] == '0' )
		$font = 'Arial';
	else if ( $weblog_data[$i]['font'] == '1' )
		$font = 'Comic Sans MS';
	else if ( $weblog_data[$i]['font'] == '2' )
		$font = 'Courier New';
	else if ( $weblog_data[$i]['font'] == '3' )
		$font = 'Georgia';
	else if ( $weblog_data[$i]['font'] == '4' )
		$font = 'Verdana';
	else if ( $weblog_data[$i]['font'] == '5' )
		$font = 'Times New Roman';
	else if ( $weblog_data[$i]['font'] == '6' )
		$font = 'Trebuchet';
	else
		$font = 'Verdana';

	$row_class = ( !($i % 2) ) ? 'row1' : 'row2';

	$template->assign_vars(array(
		'ID' => 'weblog' . $i,
		'ROW_CLASS' => $row_class,
		'BACKGROUND_COLOR' => $weblog_data[$i]['background_color'],
		'ENTRY_BG_COLOR' => $weblog_data[$i]['entry_bg_color'],
		'BORDER_COLOR' => $weblog_data[$i]['border_color'],
		'BACKGROUND_IMAGE' => $weblog_data[$i]['background_image'],
		'BACKGROUND_IMAGE_FIXED' => ( $weblog_data[$i]['background_image_fixed'] ) ? 'fixed' : 'scroll',
		'BACKGROUND_REPEAT' => $weblog_data[$i]['tile_bg'],
		'BACKGROUND_POSITION' => $weblog_data[$i]['bg_ypos'] . ' ' . $weblog_data['bg_xpos'],
		'SB_FACE_COLOR' => $weblog_data[$i]['sb_face_color'],
		'SB_HIGHLIGHT_COLOR' => $weblog_data[$i]['sb_highlight_color'],
		'SB_SHADOW_COLOR' => $weblog_data[$i]['sb_shadow_color'],
		'SB_3DLIGHT_COLOR' => $weblog_data[$i]['sb_3dlight_color'],
		'SB_ARROW_COLOR' => $weblog_data[$i]['sb_arrow_color'],
		'SB_TRACK_COLOR' => $weblog_data[$i]['sb_track_color'],
		'SB_DARKSHADOW_COLOR' => $weblog_data[$i]['sb_darkshadow_color'],
		'FONT' => $font,
		'FONT_COLOR' => $weblog_data[$i]['font_color'],
		'FONT_SIZE' => $weblog_data[$i]['font_size'],
		'NORMAL_LINK_COLOR' => $weblog_data[$i]['normal_link_color'],
		'NORMAL_LINK_UNDERLINED' => ( $weblog_data[$i]['normal_link_underline'] ) ? 'underline' : 'none',
		'ACTIVE_LINK_COLOR' => $weblog_data[$i]['active_link_color'],
		'ACTIVE_LINK_UNDERLINED' => ( $weblog_data[$i]['active_link_underline'] ) ? 'underline': 'none',
		'HOVER_LINK_COLOR' => $weblog_data[$i]['hover_link_color'],
		'HOVER_LINK_UNDERLINED' => ( $weblog_data[$i]['hover_link_underline'] ) ? 'underline': 'none',
		'VISITED_LINK_COLOR' => $weblog_data[$i]['visited_link_color'],
		'VISITED_LINK_UNDERLINED' => ( $weblog_data[$i]['visited_link_underline'] ) ? 'underline': 'none',
		'WEBLOG_TITLE_COLOR' => $weblog_data[$i]['weblog_title_color'],
		'WEBLOG_TITLE_FONT_SIZE' => $weblog_data[$i]['weblog_title_font_size'],
		'ENTRY_TITLE_COLOR' => $weblog_data[$i]['entry_title_color'],
		'ENTRY_TITLE_FONT_SIZE' => $weblog_data[$i]['entry_title_font_size'],
		'DATE_TIME_COLOR' => $weblog_data[$i]['date_time_color'],
		'DATE_TIME_FONT_SIZE' => $weblog_data[$i]['date_time_font_size'],
		'BLOCK_TITLE_COLOR' => $weblog_data[$i]['block_title_color'],
		'BLOCK_TITLE_FONT_SIZE' => $weblog_data['block_title_font_size'],
		'BLOCK_BG_COLOR' => $weblog_data[$i]['block_bg_color'],
		'BLOCK_BORDER_COLOR' => $weblog_data[$i]['block_border_color'],
		'RECENT_POST_CLASS' => $row_class,
		'WEBLOG_NAME' => $weblog_data[$i]['weblog_name'],
		'AVATAR_IMG' => $avatar_img,
		'WEBLOG_OWNER' => $weblog_data[$i]['username'],
		'WEBLOG_DESCRIPTION' => $weblog_data[$i]['weblog_desc'],
		'USERNAME' => $weblog_data[$i]['username'],

		'U_VIEW_WEBLOG' => append_sid ("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data[$i]['weblog_id']),
		'U_WEBLOG_RSS' => append_sid ("weblog_rss.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data[$i]['weblog_id']),

		'LAST_ENTRY' => $last_entry,
		'LATEST_MOOD' => $mood,
		'LAST_SEEN' => $action)
	);

	//
	// Generate the weblog face
	//
	$template->pparse($i);
}

if ( !$weblog_config['condense_index'] )
{
	$template->set_filenames(array(
		'bottom' => 'weblog_index_bottom.tpl')
	);
}
else
{
	$template->set_filenames(array(
		'bottom' => 'weblog_index_bottom_small.tpl')
	);
}

$template->assign_vars(array(
	'L_POWERED_BY' => sprintf($lang['Weblog_powered_by'], WEBLOGS_MOD_VERSION))
);

//
// Generate the last bit of the page
//
$template->pparse('bottom');

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>