<?php
/***************************************************************************
 *                             weblog_entry.php
 *                          ----------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   
 *   Maintained by: TheBlogMod.com Community
 *   Support: Visit www.TheBlogMod.com
 *
 *   $Id: weblog_entry.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *   $Id: weblog_entry.php,v 1.0.1 2006/03/03, 12:33:01 TheBlogMod.com $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/bbcode.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

//
// Start initial var setup
//
$entry_id = $post_id = 0;
if ( isset($HTTP_GET_VARS[POST_ENTRY_URL]) )
{
	$entry_id = intval($HTTP_GET_VARS[POST_ENTRY_URL]);
}
else
{
	$entry_id = 0;
}

if ( isset($HTTP_GET_VARS[POST_REPLY_URL]))
{
	$reply_id = intval($HTTP_GET_VARS[POST_REPLY_URL]);
}
else
{
	$reply_id = 0;
}

if ( isset($HTTP_GET_VARS['tb']))
{
	$view_trackbacks = true;
}
else
{
	$view_trackbacks = false;
}

$start = ( isset($HTTP_GET_VARS['start']) ) ? intval($HTTP_GET_VARS['start']) : 0;

if ( !isset($entry_id) && !isset($post_id) )
{
	message_die(GENERAL_MESSAGE, $lang['Entry_post_not_exist']);
}

//
// This rather complex gaggle of code handles querying for topics but
// also allows for direct linking to a post (and the calculation of which
// page the post is on and the correct display of weblog_entry)
//
$join_sql_table = ( empty($reply_id) ) ? '' : ", " . WEBLOG_REPLIES_TABLE . " r, " . WEBLOG_REPLIES_TABLE . " r2 ";
$join_sql = ( empty($reply_id) ) ? "e.entry_id = $entry_id" : "r.reply_id = $reply_id AND e.entry_id = r.entry_id AND r2.entry_id = r.entry_id AND r2.reply_id <= $reply_id";
$count_sql = ( empty($reply_id) ) ? '' : ", COUNT(r2.reply_id) AS prev_posts";

$order_sql = ( empty($reply_id) ) ? '' : "GROUP BY r.reply_id, e.entry_id, e.entry_subject, e.entry_replies, e.entry_time, e.entry_last_post_id, e.no_replies, w.weblog_name, w.weblog_id, w.template_id, w.weblog_auth, w.replies_auth ORDER BY r.reply_id ASC";

$sql = "SELECT e.entry_id, e.entry_subject, e.entry_replies, e.entry_time, e.entry_last_post_id, e.entry_access, e.no_replies, u.user_id, w.*" . $count_sql . "
	FROM " . WEBLOG_ENTRIES_TABLE . " e, " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u" . $join_sql_table . "
	WHERE $join_sql
		AND w.weblog_id = e.weblog_id
		AND e.entry_deleted <> " . TRUE . "
		AND u.user_weblog = w.weblog_id
		$order_sql";
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, "Could not obtain entry information", '', __LINE__, __FILE__, $sql);
}

if ( !($weblog_entry_data = $db->sql_fetchrow($result)) )
{
	message_die(GENERAL_MESSAGE, $lang['Entry_post_not_exist']);
}


if ( $weblog_entry_data['deleted'] )
{
	message_die(GENERAL_ERROR, sprintf($lang['Weblog_deactivated'], $weblog_entry_data['weblog_name']));
}

$weblog_id = intval($weblog_entry_data['weblog_id']);

$weblog_name = $weblog_entry_data['weblog_name'];
$entry_subject = $weblog_entry_data['entry_subject'];
$entry_id = intval($weblog_entry_data['entry_id']);
$entry_time = $weblog_entry_data['entry_time'];

//
// Start session management
//
$userdata = session_pagestart($user_ip, 10000 + $weblog_id);
init_userprefs($userdata);
//
// End session management
//

if ( !empty($reply_id) )
{
	$start = floor(($weblog_entry_data['prev_posts'] - 1) / $weblog_entry_data['entries_perpage'] ) * $weblog_entry_data['entries_perpage'];
}

$template_dir = get_template_dir ($weblog_entry_data['template_id']);
$page_title = $weblog_entry_data['weblog_name'] . ' :: ' . $weblog_entry_data['entry_subject'];
//
// Load templates
//
$template->set_filenames(array(
	'body' => '../../weblogs/templates/' . $template_dir . '/weblog_entry_body.htm')
);

//
// Fetch Contributor data
//
$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE weblog_id = $weblog_id AND user_id = " . $userdata['user_id'];
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$contributor = FALSE;
if ( $row = $db->sql_fetchrow($result) || $userdata['user_level'] == ADMIN )
{
	$contributor = TRUE;
}


if ( $userdata['user_weblog'] == $weblog_entry_data['weblog_id'] )
{
	$template->assign_block_vars('switch_weblog_owner', array() );
	$template->assign_block_vars('switch_contributor_only', array());
}
else if ( $contributor )
{
	$template->assign_block_vars('switch_contributor_only', array());
}

//
// Generate a 'Show posts in previous x days' select box. If the postdays var is POSTed
// then get it's value, find the number of topics with dates newer than it (to properly
// handle pagination) and alter the main query
//
$previous_days = array(0, 1, 7, 14, 30, 90, 180, 364);
$previous_days_text = array($lang['All_Posts'], $lang['1_Day'], $lang['7_Days'], $lang['2_Weeks'], $lang['1_Month'], $lang['3_Months'], $lang['6_Months'], $lang['1_Year']);

if( !empty($HTTP_POST_VARS['postdays']) || !empty($HTTP_GET_VARS['postdays']) )
{
	$post_days = ( !empty($HTTP_POST_VARS['postdays']) ) ? $HTTP_POST_VARS['postdays'] : $HTTP_GET_VARS['postdays'];
	$min_post_time = time() - (intval($post_days) * 86400);

	$sql = "SELECT COUNT(r.reply_id) AS num_posts
		FROM " . WEBLOG_ENTRIES_TABLE . " e, " . WEBLOG_REPLIES_TABLE . " r
		WHERE e.entry_id = $entry_id
			AND r.entry_id = e.entry_id
			AND r.post_time >= $min_post_time";
	if ( !($result = $db->sql_query($sql)) )
	{
		weblog_message_die(GENERAL_ERROR, "Could not obtain limited topics count information", '', __LINE__, __FILE__, $sql);
	}

	$total_replies = ( $row = $db->sql_fetchrow($result) ) ? intval($row['num_posts']) : 0;

	$limit_posts_time = "AND r.post_time >= $min_post_time ";

	if ( !empty($HTTP_POST_VARS['postdays']))
	{
		$start = 0;
	}
}
else
{
	$total_replies = intval($weblog_entry_data['topic_replies']) + 1;

	$limit_posts_time = '';
	$post_days = 0;
}

$select_post_days = '<select name="postdays">';
for($i = 0; $i < count($previous_days); $i++)
{
	$selected = ($post_days == $previous_days[$i]) ? ' selected="selected"' : '';
	$select_post_days .= '<option value="' . $previous_days[$i] . '"' . $selected . '>' . $previous_days_text[$i] . '</option>';
}
$select_post_days .= '</select>';

//
// Decide how to order the post display
//
if ( !empty($HTTP_POST_VARS['postorder']) || !empty($HTTP_GET_VARS['postorder']) )
{
	$post_order = (!empty($HTTP_POST_VARS['postorder'])) ? $HTTP_POST_VARS['postorder'] : $HTTP_GET_VARS['postorder'];
	$post_time_order = ($post_order == "asc") ? "ASC" : "DESC";
}
else
{
	$post_order = 'asc';
	$post_time_order = 'ASC';
}

$select_post_order = '<select name="postorder">';
if ( $post_time_order == 'ASC' )
{
	$select_post_order .= '<option value="asc" selected="selected">' . $lang['Oldest_First'] . '</option><option value="desc">' . $lang['Newest_First'] . '</option>';
}
else
{
	$select_post_order .= '<option value="asc">' . $lang['Oldest_First'] . '</option><option value="desc" selected="selected">' . $lang['Newest_First'] . '</option>';
}
$select_post_order .= '</select>';


// Get user auth level
$auth_level = get_auth_level ($weblog_entry_data, $contributor);

if ( $weblog_entry_data['entry_access'] > $auth_level )
{
	weblog_message_die (GENERAL_ERROR, $lang['Entry_noaccess']);
}

if ( (($auth_level >= $weblog_entry_data['replies_auth']) || ($userdata['user_weblog'] == $weblog_entry_data['weblog_id'])) && !$weblog_entry_data['no_replies'] )
{
	$template->assign_block_vars('switch_reply_authed', array() );
}

//
// Get the original entry data
//
$sql = "SELECT * FROM " . WEBLOG_ENTRIES_TABLE . " WHERE entry_id = $entry_id";
if ( !($result = $db->sql_query($sql)) )
{
	weblog_message_die(GENERAL_ERROR, "Could not obtain entry information", '', __LINE__, __FILE__, $sql);
}

if ( !($entry_data = $db->sql_fetchrow($result)) )
{
	weblog_message_die(GENERAL_MESSAGE, $lang['Entry_not_exist']);
}

$reply_data = array();
$trackback_data = array();

//
// Get the entry's replies data
//
$sql = "SELECT r.*, u.* FROM " . WEBLOG_REPLIES_TABLE . " r, " . USERS_TABLE . " u
		WHERE r.entry_id = $entry_id
			$limit_posts_time
			AND u.user_id = r.poster_id
		ORDER BY r.post_time $post_time_order
	LIMIT $start, ".$weblog_entry_data['entries_perpage'];
if ( !($result = $db->sql_query($sql)) )
{
	weblog_message_die(GENERAL_ERROR, "Could not obtain entry information", '', __LINE__, __FILE__, $sql);
}

$reply_data = array();
while ( $row = $db->sql_fetchrow($result) )
{
	$reply_data[] = $row;
}

$sql = "SELECT *
	FROM " . RANKS_TABLE . "
	ORDER BY rank_special, rank_min";
if ( !($result = $db->sql_query($sql)) )
{
	weblog_message_die(GENERAL_ERROR, "Could not obtain ranks information.", '', __LINE__, __FILE__, $sql);
}

$ranksrow = array();
while ( $row = $db->sql_fetchrow($result) )
{
	$ranksrow[] = $row;
}
$db->sql_freeresult($result);

//
// Get the trackbacks
//

$sql = "SELECT * FROM " . WEBLOG_TRACKBACKS_TABLE . "
		WHERE tb_entry = $entry_id
		ORDER BY tb_time
	LIMIT $start, " . $weblog_entry_data['entries_perpage'];
if ( !($result = $db->sql_query($sql)) )
{
	weblog_message_die(GENERAL_ERROR, "Could not obtain trackback information", '', __LINE__, __FILE__, $sql);
}

$trackback_data = array();
while ( $row = $db->sql_fetchrow($result) )
{
	$trackback_data[] = $row;
}

if ( $weblog_config['censor_weblog'] )
{
	//
	// Define censored word matches
	//
	$orig_word = array();
	$replacement_word = array();
	obtain_word_list($orig_word, $replacement_word);

	//
	// Censor entry subject, content, and currently text
	//
	if ( count($orig_word) )
	{
		$entry_data['entry_subject'] = preg_replace($orig_word, $replacement_word, $entry_data['entry_subject']);
		$entry_data['entry_text'] = preg_replace($orig_word, $replacement_word, $entry_data['entry_text']);
		$entry_data['currently_text'] = preg_replace($orig_word, $replacement_word, $entry_data['currently_text']);
	}
}

// Remove [cut] if found found
$entry_data['entry_text'] = hide_cuts ($entry_data['entry_text']);


//
// Set a cookie for this topic
//
if ( $userdata['session_logged_in'] )
{
	$tracking_entries = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) : array();
	$tracking_weblogs = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) : array();

	if ( !empty($tracking_entries[$entry_id]) && !empty($tracking_weblogs[$weblog_id]) )
	{
		$entry_last_read = ( $tracking_entries[$entry_id] > $tracking_weblogs[$weblog_id] ) ? $tracking_entries[$entry_id] : $tracking_weblogs[$weblog_id];
	}
	else if ( !empty($tracking_entries[$entry_id]) || !empty($tracking_weblogs[$weblog_id]) )
	{
		$entry_last_read = ( !empty($tracking_entries[$entry_id]) ) ? $tracking_entries[$entry_id] : $tracking_weblogs[$weblog_id];
	}
	else
	{
		$entry_last_read = $userdata['user_lastvisit'];
	}

	if ( count($tracking_entries) >= 150 && empty($tracking_entries[$entry_id]) )
	{
		asort($tracking_entries);
		unset($tracking_entries[key($tracking_entries)]);
	}

	$tracking_entries[$entry_id] = time();

	setcookie($board_config['cookie_name'] . '_e', serialize($tracking_entries), 0, $board_config['cookie_path'], $board_config['cookie_domain'], $board_config['cookie_secure']);
}

//
// Deal with the entry
//
$message = $entry_data['entry_text'];

//
// If the board has HTML off but the post has HTML
// on then we process it, else leave it alone
//
if ( !$board_config['allow_html'] )
{
	if ( $entry_data['enable_html'] )
	{
		$message = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $message);
	}
}

//
// Parse message and/or sig for BBCode if reqd
//
if ( $board_config['allow_bbcode'] )
{
	if ( $entry_data['bbcode_uid'] != '' )
	{
		$message = ( $board_config['allow_bbcode'] ) ? bbencode_second_pass($message, $entry_data['bbcode_uid']) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $message);
	}
}

$message = make_clickable($message);

//
// Parse smilies
//
if ( $board_config['allow_smilies'] )
{
	if ( $entry_data['enable_smilies'] )
	{
		$message = smilies_pass($message);
	}
}


//
// Get the moods data
//
$sql = "SELECT *
	FROM " . WEBLOG_MOODS_TABLE . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

//
// Get the actions data
//
$sql = "SELECT *
	FROM " . WEBLOG_ACTIONS_TABLE . "
	ORDER BY action_text";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't obtain action data from database", "", __LINE__, __FILE__, $sql);
}
$action_data = $db->sql_fetchrowset($result);

// Mood Icons
$mood = array();
$mood = find_mood($entry_data['entry_mood']);

if ( $mood >= 0 )
{ 
	$mood = '<strong>[</strong>&nbsp;' . sprintf($lang['Mood:'], '<img src="images/weblogs/' . $mood['mood_url'] . '" alt="' . $mood_data['mood_text'] . '" style="vertical-align: middle" border="0" />', $mood['mood_text']) . '&nbsp;<strong>]</strong>';
}
else
{
	$mood = '';
}

// Currently Icons
$currently = array();
$currently = find_action($entry_data['entry_currently']);

if ( $currently > 0 )
{
	$action = '<strong>[</strong>&nbsp;' . sprintf($lang['Currently:'], '<img src="images/weblogs/' . $currently['action_url'] . '" alt="' . $currently['action_text'] . ' ' . $entry_data['currently_text'] . '" style="vertical-align: middle" border="0" />',  $currently['action_text'] . ' ' . $entry_data['currently_text']) . '&nbsp;<strong>]</strong>';
}
else if ( $entry_data['currently_text'] && $currently == -2 )
{
	$action = '<strong>[</strong>' . sprintf($lang['Currently:'], '', $entry_data['currently_text']) . '&nbsp;<strong>]</strong>';
}
else
{
	$action = '';
}

$server_name = preg_replace('#^\/?(.*?)\/?$#', '\1', trim($board_config['server_name']));
$server_port = ($board_config['server_port'] <> 80) ? ':' . trim($board_config['server_port']) : '';
$script_name = preg_replace('#^\/?(.*?)\/?$#', '\1', trim($board_config['script_path']));
$script_name = ($script_name == '') ? $script_name : '/' . $script_name;
$trackback_url  = 'http://' . $server_name . $server_port . $script_name . '/trackback.' . $phpEx . '?e=' . $entry_id;

//
// Replace newlines (we use this rather than nl2br because
// till recently it wasn't XHTML compliant)
//
$message = str_replace("\n", "\n<br />\n", $message);

//
// Output page header
//
use_weblog_header ( $weblog_entry_data, $template_dir );

$pagination = '';
$page_number = '';

//
// Handle Pagination
//
if ( $view_trackbacks )
{
	if ( $entry_data['entry_trackbacks'] >= 1 )
	{
		$pagination = generate_pagination("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id&amp;tb=1&amp;start=$start", $entry_data['entry_trackbacks'], $weblog_entry_data['entries_perpage'], $start);
		$page_number = sprintf($lang['Page_of'], ( floor( $start / intval($weblog_entry_data['entries_perpage']) ) + 1 ), ceil( $entry_data['entry_trackbacks'] / intval($weblog_entry_data['entries_perpage']) ));
	}
}
else if ( $weblog_entry_data['entry_replies'] >= 1 )
{
	$pagination = generate_pagination("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id&amp;postdays=$post_days&amp;postorder=$post_order", $weblog_entry_data['entry_replies'], $weblog_entry_data['entries_perpage'], $start);
	$page_number = sprintf($lang['Page_of'], ( floor( $start / intval($weblog_entry_data['entries_perpage']) ) + 1 ), ceil( $weblog_entry_data['entry_replies'] / intval($weblog_entry_data['entries_perpage']) ));
}

$entry_access = $entry_data['entry_access'];

// CategoryAddon courtesy by willow at TheBlogMod.com
$category = $entry_data['category'];

//
// Send general vars to template
//
$template->assign_vars(array(
	'WEBLOG_NAME' => $weblog_name,
	'POST_ENTRY_IMG' => 'weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/newentry.gif',
	'POST_REPLY_IMG' => 'weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/reply.gif',

	'ENTRY_SUBJECT' => $entry_subject,
	'ENTRY_TIME' => create_date($board_config['default_dateformat'], $entry_data['entry_time'], $board_config['board_timezone']),
	'ENTRY' => $message,
	'MOOD' => $mood,
	'ACTION' => $action,
	'ENTRY_LOCKED_ICON' => ( $entry_data['entry_access'] > WEBLOG_AUTH_ALL ) ? '<img src="weblogs/templates/' . $template_dir . '/images/lock.gif" border="0" alt="' . $lang['Restricted_access'] . '" title="' . $lang['Restricted_access'] . '" />&nbsp;' . $weblog_auth_types[$entry_access] : '',
	'EDIT_LINK' => ( $userdata['user_weblog'] == $weblog_entry_data['weblog_id'] || $userdata['user_level'] == ADMIN ) ? '<strong>[ <a href="' . append_sid ("weblog_posting.$phpEx?mode=editentry&amp;" . POST_ENTRY_URL . "=" . $entry_data['entry_id']) . '">' . $lang['Edit'] . '</a> ]</strong>' : '',
	'DELETE_LINK' => ( $userdata['user_weblog'] == $weblog_entry_data['weblog_id'] || $userdata['user_level'] == ADMIN ) ? '<strong>[ <a href="' . append_sid ("weblog_posting.$phpEx?mode=delete&amp;" . POST_ENTRY_URL . "=" . $entry_data['entry_id']) . '">X</a> ]</strong>' : '',
	'FORUM_ID' => $weblog_id,
	'FORUM_NAME' => $forum_name,
	'TOPIC_ID' => $entry_id,
	'TOPIC_TITLE' => $topic_title,
	'PAGINATION' =>  $pagination,
	'PAGE_NUMBER' => $page_number,

	'POST_IMG' => $post_img,
	'REPLY_IMG' => $reply_img,

	'L_INDEX' => sprintf($lang['Forum_Index'], $board_config['sitename']),

	'L_TRACKBACK_URL' => $lang['Trackback_url'],
	'TRACKBACK_URL' => $trackback_url,
	
	'CATEGORY_URL' => ( $category !='' ) ? '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_id . "&amp;category=$category") .'">' . $lang['More posts from this category:'] .$category . '</a>' : "",

	'U_INDEX' => append_sid('index.'.$phpEx),
	'U_WEBLOG' => append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id"),
	'U_WEBLOGS' => append_sid("weblogs.$phpEx"),
	'U_VIEW_ENTRY' => append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id"),
	'U_POST_NEW_ENTRY' => append_sid("weblog_posting.$phpEx?mode=newentry&amp;" . POST_WEBLOG_URL . "=$weblog_id"),
	'U_POST_NEW_REPLY' => append_sid("weblog_posting.$phpEx?mode=reply&amp;" . POST_ENTRY_URL . "=$entry_id"),
	'U_EDIT' => ( $userdata['user_weblog'] == $weblog_entry_data['weblog_id'] || $userdata['user_level'] == ADMIN ) ? append_sid ("weblog_posting.$phpEx?mode=editentry&amp;" . POST_ENTRY_URL . "=" . $entry_data['entry_id']) : '',
	'U_DELETE' => ( $userdata['user_weblog'] == $weblog_entry_data['weblog_id'] || $userdata['user_level'] == ADMIN ) ? append_sid ("weblog_posting.$phpEx?mode=delete&amp;" . POST_ENTRY_URL . "=" . $entry_data['entry_id']) : '',

	'EDIT_IMG' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $userdata['user_level'] == ADMIN ) ? '<img src="weblogs/templates/' . $template_dir . '/images/edit.gif" border="0" alt="' . $lang['Edit'] . '" title="' . $lang['Edit'] . '" style="vertical-align: middle;" />' : '',
	'DELETE_IMG' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $userdata['user_level'] == ADMIN ) ? '<img src="weblogs/templates/' . $template_dir . '/images/delete.gif" border="0" alt="' . $lang['Delete'] . '" title="' . $lang['Delete'] . '" style="vertical-align: middle;" />' : '',

	'L_ENTRY_NO_REPLIES' => $lang['Entry_no_replies'],
	'L_REPLIES_DISABLED' => $lang['Replies_disabled'],
	'L_GO' => $lang['Go'],
	'L_AUTHOR' => $lang['Author'],
	'L_MESSAGE' => $lang['Message'],
	'L_POSTED' => $lang['Posted'],
	'L_POST_SUBJECT' => $lang['Post_subject'],
	'L_POST_NEW_TOPIC' => $post_alt,
	'L_POST_REPLY_TOPIC' => $reply_alt,
	'L_BACK_TO_TOP' => $lang['Back_to_top'],
	'L_DISPLAY_POSTS' => $lang['Display_posts'],
	'L_GOTO_PAGE' => $lang['Goto_page'],
	'L_POST_REPLY' => $lang['Post_reply'],
	'L_POST_NEW_ENTRY' => $lang['Post_new_entry'],

	'L_WEBLOGS' => $lang['Weblogs'],
	'MOD_VERSION' => $mod_version,

	'S_TOPIC_LINK' => POST_ENTRY_URL,
	'S_SELECT_POST_DAYS' => $select_post_days,
	'S_SELECT_POST_ORDER' => $select_post_order,
	'S_POST_DAYS_ACTION' => append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . '=' . $entry_id . "&amp;start=$start"),
	'S_AUTH_LIST' => $s_auth_can,
	'S_TOPIC_ADMIN' => $topic_mod,
	'S_WATCH_TOPIC' => $s_watching_topic,
	'S_WATCH_TOPIC_IMG' => $s_watching_topic_img,

	'U_VIEW_TOPIC' => append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id&amp;start=$start&amp;postdays=$post_days&amp;postorder=$post_order&amp;highlight=$highlight"),
	'U_VIEW_FORUM' => $view_forum_url,
	'U_VIEW_OLDER_TOPIC' => $view_prev_topic_url,
	'U_VIEW_NEWER_TOPIC' => $view_next_topic_url,
	'U_POST_NEW_TOPIC' => $new_topic_url,
	'U_POST_REPLY_TOPIC' => $reply_topic_url)
);

//
// Update the topic view counter
//
$sql = "UPDATE " . WEBLOG_ENTRIES_TABLE . "
	SET entry_views = entry_views + 1
	WHERE entry_id = $entry_id";
if ( !$db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Could not update entry views.", '', __LINE__, __FILE__, $sql);
}


//
// Okay, let's do the loop, yeah come on baby let's do the loop
// and it goes like this ...
//
$i = 0; $j = 0;
for ($k = 0; $k < count($reply_data) + count($trackback_data); $k++)
{
	
	// Compare to see which one should be parsed first
	if ( (!empty($trackback_data[$j]) && !empty($reply_data[$i]) && $reply_data[$i]['post_time'] <= $trackback_data[$j]['tb_time']) || (!empty($reply_data[$i]) && empty($trackback_data[$j]) ) )
	{
		$poster_id = $reply_data[$i]['user_id'];

		$poster = ( $poster_id == ANONYMOUS ) ? $lang['Guest'] : $reply_data[$i]['username'];

		$post_date = create_date($board_config['default_dateformat'], $reply_data[$i]['post_time'], $board_config['board_timezone']);

		$poster_posts = ( $reply_data[$i]['user_id'] != ANONYMOUS ) ? $lang['Posts'] . ': ' . $reply_data[$i]['user_posts'] : '';

		$poster_from = ( $reply_data[$i]['user_from'] && $reply_data[$i]['user_id'] != ANONYMOUS ) ? $lang['Location'] . ': ' . $reply_data[$i]['user_from'] : '';

		$poster_joined = ( $reply_data[$i]['user_id'] != ANONYMOUS ) ? $lang['Joined'] . ': ' . create_date($lang['DATE_FORMAT'], $reply_data[$i]['user_regdate'], $board_config['board_timezone']) : '';

		$poster_avatar = '';
		if ( $reply_data[$i]['user_avatar_type'] && $poster_id != ANONYMOUS && $reply_data[$i]['user_allowavatar'] )
		{
			switch( $reply_data[$i]['user_avatar_type'] )
			{
				case USER_AVATAR_UPLOAD:
					$poster_avatar = ( $board_config['allow_avatar_upload'] ) ? '<img src="' . $board_config['avatar_path'] . '/' . $reply_data[$i]['user_avatar'] . '" alt="" border="0" />' : '';
					break;
				case USER_AVATAR_REMOTE:
					$poster_avatar = ( $board_config['allow_avatar_remote'] ) ? '<img src="' . $reply_data[$i]['user_avatar'] . '" alt="" border="0" />' : '';
					break;
				case USER_AVATAR_GALLERY:
					$poster_avatar = ( $board_config['allow_avatar_local'] ) ? '<img src="' . $board_config['avatar_gallery_path'] . '/' . $reply_data[$i]['user_avatar'] . '" alt="" border="0" />' : '';
					break;
			}
		}

		//
		// Define the little post icon
		//
		if ( $userdata['session_logged_in'] && $reply_data[$i]['post_time'] > $userdata['user_lastvisit'] && $reply_data[$i]['post_time'] > $entry_last_read )
		{
			$mini_post_img = $images['icon_minipost_new'];
			$mini_post_alt = $lang['New_post'];
		}
		else
		{
			$mini_post_img = $images['icon_minipost'];
			$mini_post_alt = $lang['Post'];
		}

		$mini_post_url = append_sid("weblog_entry.$phpEx?" . POST_REPLY_URL . '=' . $reply_data[$i]['reply_id']) . '#' . $reply_data[$i]['reply_id'];

		//
		// Generate ranks, set them to empty string initially.
		//
		$poster_rank = '';
		$rank_image = '';
		if ( $reply_data[$i]['user_id'] == ANONYMOUS )
		{
		}
		else if ( $reply_data[$i]['user_rank'] )
		{
			for($j2 = 0; $j2 < count($ranksrow); $j2++)
			{
				if ( $reply_data[$i]['user_rank'] == $ranksrow[$j2]['rank_id'] && $ranksrow[$j2]['rank_special'] )
				{
					$poster_rank = $ranksrow[$j2]['rank_title'];
					$rank_image = ( $ranksrow[$j2]['rank_image'] ) ? '<img src="' . $ranksrow[$j2]['rank_image'] . '" alt="' . $poster_rank . '" title="' . $poster_rank . '" border="0" /><br />' : '';
				}
			}
		}
		else
		{
			for($j2 = 0; $j2 < count($ranksrow); $j2++)
			{
				if ( $reply_data[$i]['user_posts'] >= $ranksrow[$j2]['rank_min'] && !$ranksrow[$j2]['rank_special'] )
				{
					$poster_rank = $ranksrow[$j2]['rank_title'];
					$rank_image = ( $ranksrow[$j2]['rank_image'] ) ? '<img src="' . $ranksrow[$j2]['rank_image'] . '" alt="' . $poster_rank . '" title="' . $poster_rank . '" border="0" /><br />' : '';
				}
			}
		}

		//
		// Handle anon users posting with usernames
		//
		if ( $poster_id == ANONYMOUS && $reply_data[$i]['post_username'] != '' )
		{
			$poster = $reply_data[$i]['post_username'];
			$poster_rank = $lang['Guest'];
			$poster_age = '';
		}

		$temp_url = '';

		if ( $poster_id != ANONYMOUS )
		{
			$temp_url = append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$poster_id");
			$profile_img = '<a href="' . $temp_url . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_profile.gif" alt="' . $lang['Read_profile'] . '" title="' . $lang['Read_profile'] . '" border="0" /></a>';
			$profile = '<a href="' . $temp_url . '">' . $lang['Read_profile'] . '</a>';

			$temp_url = append_sid("privmsg.$phpEx?mode=post&amp;" . POST_USERS_URL . "=$poster_id");
			$pm_img = '<a href="' . $temp_url . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_pm.gif" alt="' . $lang['Send_private_message'] . '" title="' . $lang['Send_private_message'] . '" border="0" /></a>';
			$pm = '<a href="' . $temp_url . '">' . $lang['Send_private_message'] . '</a>';

			if ( !empty($reply_data[$i]['user_viewemail']) || $userdata['user_level'] == ADMIN )
			{
				$email_uri = ( $board_config['board_email_form'] ) ? append_sid("profile.$phpEx?mode=email&amp;" . POST_USERS_URL .'=' . $poster_id) : 'mailto:' . $reply_data[$i]['user_email'];

				$email_img = '<a href="' . $email_uri . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_email.gif" alt="' . $lang['Send_email'] . '" title="' . $lang['Send_email'] . '" border="0" /></a>';
				$email = '<a href="' . $email_uri . '">' . $lang['Send_email'] . '</a>';
			}
			else
			{
				$email_img = '';
				$email = '';
			}

			$www_img = ( $reply_data[$i]['user_website'] ) ? '<a href="' . $reply_data[$i]['user_website'] . '" target="_userwww"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_www.gif" alt="' . $lang['Visit_website'] . '" title="' . $lang['Visit_website'] . '" border="0" /></a>' : '';
			$www = ( $reply_data[$i]['user_website'] ) ? '<a href="' . $reply_data[$i]['user_website'] . '" target="_userwww">' . $lang['Visit_website'] . '</a>' : '';

			if ( !empty( $reply_data[$i]['user_icq']) )
			{
				$icq_status_img = '<a href="http://wwp.icq.com/' . $reply_data[$i]['user_icq'] . '#pager"><img src="http://web.icq.com/whitepages/online?icq=' . $reply_data[$i]['user_icq'] . '&img=5" width="18" height="18" border="0" /></a>';
				$icq_img = '<a href="http://wwp.icq.com/scripts/search.dll?to=' . $reply_data[$i]['user_icq'] . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_icq_add.gif" alt="' . $lang['ICQ'] . '" title="' . $lang['ICQ'] . '" border="0" /></a>';
				$icq =  '<a href="http://wwp.icq.com/scripts/search.dll?to=' . $reply_data[$i]['user_icq'] . '">' . $lang['ICQ'] . '</a>';
			}
			else
			{
				$icq_status_img = '';
				$icq_img = '';
				$icq = '';
			}

			$aim_img = ( $reply_data[$i]['user_aim'] ) ? '<a href="aim:goim?screenname=' . $reply_data[$i]['user_aim'] . '&amp;message=Hello+Are+you+there?"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_aim.gif" alt="' . $lang['AIM'] . '" title="' . $lang['AIM'] . '" border="0" /></a>' : '';
			$aim = ( $reply_data[$i]['user_aim'] ) ? '<a href="aim:goim?screenname=' . $reply_data[$i]['user_aim'] . '&amp;message=Hello+Are+you+there?">' . $lang['AIM'] . '</a>' : '';

			$temp_url = append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$poster_id");
			$msn_img = ( $reply_data[$i]['user_msnm'] ) ? '<a href="' . $temp_url . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_msnm.gif" alt="' . $lang['MSNM'] . '" title="' . $lang['MSNM'] . '" border="0" /></a>' : '';
			$msn = ( $reply_data[$i]['user_msnm'] ) ? '<a href="' . $temp_url . '">' . $lang['MSNM'] . '</a>' : '';

			$yim_img = ( $reply_data[$i]['user_yim'] ) ? '<a href="http://edit.yahoo.com/config/send_webmesg?.target=' . $reply_data[$i]['user_yim'] . '&amp;.src=pg"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_yim.gif" alt="' . $lang['YIM'] . '" title="' . $lang['YIM'] . '" border="0" /></a>' : '';
			$yim = ( $reply_data[$i]['user_yim'] ) ? '<a href="http://edit.yahoo.com/config/send_webmesg?.target=' . $reply_data[$i]['user_yim'] . '&amp;.src=pg">' . $lang['YIM'] . '</a>' : '';

			$weblog_img = ( $reply_data[$i]['user_weblog'] ) ? '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $reply_data[$i]['user_weblog']) . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_weblog.gif" alt="' . $row['weblog_name'] . '" title="' . $lang['View_weblog'] . '" border="0" /></a>' : '';
			$weblog = ( $reply_data[$i]['user_weblog'] ) ? '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $reply_data[$i]['user_weblog']) . '">' . $lang['View_weblog'] . '</a>' : '';
		}
		else
		{
			$profile_img = '';
			$profile = '';
			$pm_img = '';
			$pm = '';
			$email_img = '';
			$email = '';
			$www_img = '';
			$www = '';
			$icq_status_img = '';
			$icq_img = '';
			$icq = '';
			$aim_img = '';
			$aim = '';
			$msn_img = '';
			$msn = '';
			$yim_img = '';
			$yim = '';
			$weblog_img = '';
			$weblog = '';
		}

		$temp_url = append_sid("weblog_posting.$phpEx?mode=quote&amp;" . POST_REPLY_URL . "=" . $reply_data[$i]['reply_id'] . "&amp;" . POST_WEBLOG_URL . "=" . $weblog_id);
		$quote_img = '<a href="' . $temp_url . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_quote.gif" alt="' . $lang['Reply_with_quote'] . '" title="' . $lang['Reply_with_quote'] . '" border="0" /></a>';
		$quote = '<a href="' . $temp_url . '">' . $lang['Reply_with_quote'] . '</a>';

		$temp_url = append_sid("search.$phpEx?search_author=" . urlencode($reply_data[$i]['username']) . "&amp;" . POST_WEBLOG_URL . "= " . $weblog_id . "&amp;" . POST_WEBLOG_URL . "=" . $weblog_id . "&amp;showresults=posts");
		$search_img = '<a href="' . $temp_url . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_search.gif" alt="' . $lang['Search_user_posts'] . '" title="' . $lang['Search_user_posts'] . '" border="0" /></a>';
		$search = '<a href="' . $temp_url . '">' . $lang['Search_user_posts'] . '</a>';

		if ( ($userdata['user_id'] == $poster_id || $userdata['user_weblog'] == $weblog_entry_data['weblog_id']) && $userdata['session_logged_in'] )
		{
			$temp_url = append_sid("weblog_posting.$phpEx?mode=editreply&amp;" . POST_REPLY_URL . "=" . $reply_data[$i]['reply_id']);
			$edit_img = '<a href="' . $temp_url . '"><img src="weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/icon_edit.gif" alt="' . $lang['Edit_delete_post'] . '" title="' . $lang['Edit_delete_post'] . '" border="0" /></a>';
			$edit = '<a href="' . $temp_url . '">' . $lang['Edit_delete_post'] . '</a>';
		}
		else
		{
			$edit_img = '';
			$edit = '';
		}

		if ( $userdata['user_weblog'] == $weblog_entry_data['weblog_id'] || $userdata['user_level'] == ADMIN )
		{
			$temp_url = "weblog_posting.$phpEx?mode=delete&amp;" . POST_REPLY_URL . "=" . $reply_data[$i]['reply_id'] . "&amp;sid=" . $userdata['session_id'];
			$delpost_img = '<a href="' . $temp_url . '"><img src="weblogs/templates/' . $template_dir . '/icon_delete.gif" alt="' . $lang['Delete_post'] . '" title="' . $lang['Delete_post'] . '" border="0" /></a>';
			$delpost = '<a href="' . $temp_url . '">' . $lang['Delete_post'] . '</a>';
		}
		else
		{
			$ip_img = '';
			$ip = '';

			$delpost_img = '';
			$delpost = '';
		}

		$post_subject = ( $reply_data[$i]['post_subject'] != '' ) ? $reply_data[$i]['post_subject'] : '';

		$message = $reply_data[$i]['reply_text'];
		$bbcode_uid = $reply_data[$i]['bbcode_uid'];

		$user_sig = ( $reply_data[$i]['enable_sig'] && $reply_data[$i]['user_sig'] != '' && $board_config['allow_sig'] ) ? $reply_data[$i]['user_sig'] : '';
		$user_sig_bbcode_uid = $reply_data[$i]['user_sig_bbcode_uid'];

		//
		// Note! The order used for parsing the message _is_ important, moving things around could break any
		// output
		//

		//
		// If the board has HTML off but the post has HTML
		// on then we process it, else leave it alone
		//
		if ( !$board_config['allow_html'] || !$userdata['user_allowhtml'])
		{
			if ( $user_sig != '' )
			{
				$user_sig = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $user_sig);
			}

			if ( $reply_data[$i]['enable_html'] )
			{
				$message = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $message);
			}
		}

		//
		// Parse message and/or sig for BBCode if reqd
		//
		if ( $board_config['allow_bbcode'] )
		{
			if ( $user_sig != '' && $user_sig_bbcode_uid != '' )
			{
				$user_sig = ( $board_config['allow_bbcode'] ) ? bbencode_second_pass($user_sig, $user_sig_bbcode_uid) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $user_sig);
			}

			if ( $bbcode_uid != '' )
			{
				$message = ( $board_config['allow_bbcode'] ) ? bbencode_second_pass($message, $bbcode_uid) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $message);
			}
		}

		if ( $user_sig != '' )
		{
			$user_sig = make_clickable($user_sig);
		}
		$message = make_clickable($message);

		//
		// Parse smilies
		//
		if ( $board_config['allow_smilies'] )
		{
			if ( $reply_data[$i]['user_allowsmile'] && $user_sig != '' )
			{
				$user_sig = smilies_pass($user_sig);
			}

			if ( $reply_data[$i]['enable_smilies'] )
			{
				$message = smilies_pass($message);
			}
		}

		if ( $weblog_config['censor_weblog'] )
		{
			//
			// Replace naughty words
			//
			if (count($orig_word))
			{
				$post_subject = preg_replace($orig_word, $replacement_word, $post_subject);
	
				if ($user_sig != '')
				{
					$user_sig = str_replace('\"', '"', substr(@preg_replace('#(\>(((?>([^><]+|(?R)))*)\<))#se', "@preg_replace(\$orig_word, \$replacement_word, '\\0')", '>' . $user_sig . '<'), 1, -1));
				}

				$message = str_replace('\"', '"', substr(@preg_replace('#(\>(((?>([^><]+|(?R)))*)\<))#se', "@preg_replace(\$orig_word, \$replacement_word, '\\0')", '>' . $message . '<'), 1, -1));
			}
		}

		if ( $user_sig != '' )
		{
			$user_sig = '<br />_________________<br />' . str_replace("\n", "\n<br />\n", $user_sig);
		}

		//
		// Replace newlines (we use this rather than nl2br because
		// till recently it wasn't XHTML compliant)
		//
		$message = str_replace("\n", "\n<br />\n", $message);

		//
		// Again this will be handled by the templating
		// code at some point
		//
		$row_class = ( !($k % 2) ) ? 'row1' : 'row2';

		$template->assign_block_vars('postrow', array(
			'ROW_CLASS' => $row_class,
			'POSTER_NAME' => $poster,
			'POSTER_RANK' => $poster_rank,
			'RANK_IMAGE' => $rank_image,
			'POSTER_JOINED' => $poster_joined,
			'POSTER_POSTS' => $poster_posts,
			'POSTER_FROM' => $poster_from,
			'POSTER_AVATAR' => $poster_avatar,
			'POST_DATE' => $post_date,
			'POST_SUBJECT' => $post_subject,
			'MESSAGE' => $message,
			'SIGNATURE' => $user_sig,

			'MINI_POST_IMG' => $mini_post_img,
			'PROFILE_IMG' => $profile_img,
			'PROFILE' => $profile,
			'SEARCH_IMG' => $search_img,
			'SEARCH' => $search,
			'PM_IMG' => $pm_img,
			'PM' => $pm,
			'EMAIL_IMG' => $email_img,
			'EMAIL' => $email,
			'WWW_IMG' => $www_img,
			'WWW' => $www,
			'ICQ_STATUS_IMG' => $icq_status_img,
			'ICQ_IMG' => $icq_img,
			'ICQ' => $icq,
			'AIM_IMG' => $aim_img,
			'AIM' => $aim,
			'MSN_IMG' => $msn_img,
			'MSN' => $msn,
			'YIM_IMG' => $yim_img,
			'YIM' => $yim,
			'EDIT_IMG' => $edit_img,
			'EDIT' => $edit,
			'QUOTE_IMG' => $quote_img,
			'QUOTE' => $quote,
			'IP_IMG' => $ip_img,
			'IP' => $ip,
			'DELETE_IMG' => $delpost_img,
			'DELETE' => $delpost,
			'U_REPLY_ID' => $reply_data[$i]['reply_id'],
			'ICON' => $icon,
			'WEBLOG_IMG' => $weblog_img,
			'WEBLOG' => $weblog,

			'L_MINI_POST_ALT' => $mini_post_alt,

			'U_MINI_POST' => $mini_post_url,
			'U_POST_ID' => $reply_data[$i]['reply_id'])
		);
		$i++;

	}
	else if ( (!empty($trackback_data[$j]) && !empty($reply_data[$i]) && $reply_data[$i]['post_time'] > $trackback_data[$j]['tb_time']) || (empty($reply_data[$i]) && !empty($trackback_data[$j])) )
	{
		//
		// Again this will be handled by the templating
		// code at some point
		//
		$row_class = ( !($k % 2) ) ? 'row1' : 'row2';

		if ( $userdata['user_weblog'] == $weblog_entry_data['weblog_id'] || $userdata['user_level'] == ADMIN )
		{
			$temp_url = "weblog_posting.$phpEx?mode=delete&amp;" . POST_TRACKBACK_URL . "=" . $trackback_data[$j]['tb_id'] . "&amp;sid=" . $userdata['session_id'];
			$delpost_img = '<a href="' . $temp_url . '"><img src="weblogs/templates/' . $template_dir . '/icon_delete.gif" alt="' . $lang['Delete_post'] . '" title="' . $lang['Delete_post'] . '" border="0" /></a>';
			$delpost = '<a href="' . $temp_url . '">' . $lang['Delete_post'] . '</a>';
		}
		else
		{
			$delpost_img = '';
			$delpost = '';
		}

		$template->assign_block_vars('postrow', array(
			'MINI_POST_IMG' => $images['icon_minipost'],
			'ROW_CLASS' => $row_class,
			'POSTER_RANK' => '<b>' . $lang['Trackback'] . '</b>',
			'L_MINI_POST_ALT' => $lang['Post'],
			'POST_DATE' => create_date($board_config['default_dateformat'], $trackback_data[$j]['tb_time'], $board_config['board_timezone']),
			'POST_SUBJECT' => $trackback_data[$j]['tb_title'],
			'TB_WEBLOG' => $trackback_data[$j]['tb_blog'],
			'MESSAGE' => $trackback_data[$j]['tb_excerpt'],
			'DELETE_IMG' => $delpost_img,
			'DELETE' => $delpost,
			'U_TB_WEBLOG' => $trackback_data[$j]['tb_url'])
		);

		$j++;
	}
}

if ( $weblog_entry_data['no_replies'] )
{
	$template->assign_block_vars('switch_replies_disabled', array() );
}
else if ( count ($reply_data) == 0 && count($trackback_data) == 0 )
{
	$template->assign_block_vars('switch_no_replies', array() );
}


$template->assign_vars(array(
	'L_POWERED_BY' => sprintf($lang['Weblog_powered_by'], WEBLOGS_MOD_VERSION))
);

if ( $weblog_entry_data['font'] == '0' )
	$font = 'Arial';
else if ( $weblog_entry_data['font'] == '1' )
	$font = 'Comic Sans MS';
else if ( $weblog_entry_data['font'] == '2' )
	$font = 'Courier New';
else if ( $weblog_entry_data['font'] == '3' )
	$font = 'Georgia';
else if ( $weblog_entry_data['font'] == '4' )
	$font = 'Verdana';
else if ( $weblog_entry_data['font'] == '5' )
	$font = 'Times New Roman';
else if ( $weblog_entry_data['font'] == '6' )
	$font = 'Trebuchet';
else
	$font = 'Verdana';

$template->assign_vars(array(
	'BACKGROUND_COLOR' => $weblog_entry_data['background_color'],
	'ENTRY_BG_COLOR' => $weblog_entry_data['entry_bg_color'],
	'BORDER_COLOR' => $weblog_entry_data['border_color'],
	'BACKGROUND_IMAGE' => $weblog_entry_data['background_image'],
	'BACKGROUND_IMAGE_FIXED' => ( $weblog_entry_data['background_image_fixed'] ) ? 'fixed' : 'scroll',
	'BACKGROUND_REPEAT' => $weblog_entry_data['tile_bg'],
	'BACKGROUND_POSITION' => $weblog_entry_data['bg_ypos'] . ' ' . $weblog_entry_data['bg_xpos'],
	'SB_FACE_COLOR' => $weblog_entry_data['sb_face_color'],
	'SB_HIGHLIGHT_COLOR' => $weblog_entry_data['sb_highlight_color'],
	'SB_SHADOW_COLOR' => $weblog_entry_data['sb_shadow_color'],
	'SB_3DLIGHT_COLOR' => $weblog_entry_data['sb_3dlight_color'],
	'SB_ARROW_COLOR' => $weblog_entry_data['sb_arrow_color'],
	'SB_TRACK_COLOR' => $weblog_entry_data['sb_track_color'],
	'SB_DARKSHADOW_COLOR' => $weblog_entry_data['sb_darkshadow_color'],
	'FONT' => $font,
	'FONT_COLOR' => $weblog_entry_data['font_color'],
	'FONT_SIZE' => $weblog_entry_data['font_size'],
	'NORMAL_LINK_COLOR' => $weblog_entry_data['normal_link_color'],
	'NORMAL_LINK_UNDERLINED' => ( $weblog_entry_data['normal_link_underline'] ) ? 'underline' : 'none',
	'ACTIVE_LINK_COLOR' => $weblog_entry_data['active_link_color'],
	'ACTIVE_LINK_UNDERLINED' => ( $weblog_entry_data['active_link_underline'] ) ? 'underline': 'none',
	'HOVER_LINK_COLOR' => $weblog_entry_data['hover_link_color'],
	'HOVER_LINK_UNDERLINED' => ( $weblog_entry_data['hover_link_underline'] ) ? 'underline': 'none',
	'VISITED_LINK_COLOR' => $weblog_entry_data['visited_link_color'],
	'VISITED_LINK_UNDERLINED' => ( $weblog_entry_data['visited_link_underline'] ) ? 'underline': 'none',
	'WEBLOG_TITLE_COLOR' => $weblog_entry_data['weblog_title_color'],
	'WEBLOG_TITLE_FONT_SIZE' => $weblog_entry_data['weblog_title_font_size'],
	'ENTRY_TITLE_COLOR' => $weblog_entry_data['entry_title_color'],
	'ENTRY_TITLE_FONT_SIZE' => $weblog_entry_data['entry_title_font_size'],
	'DATE_TIME_COLOR' => $weblog_entry_data['date_time_color'],
	'DATE_TIME_FONT_SIZE' => $weblog_entry_data['date_time_font_size'],
	'BLOCK_TITLE_COLOR' => $weblog_entry_data['block_title_color'],
	'BLOCK_TITLE_FONT_SIZE' => $weblog_entry_data['block_title_font_size'],
	'BLOCK_BG_COLOR' => $weblog_entry_data['block_bg_color'],
	'BLOCK_BORDER_COLOR' => $weblog_entry_data['block_border_color'])
);

//
// Parse the page and print
//
$template->pparse('body');

use_weblog_footer ( $weblog_entry_data, $template_dir );

?>
