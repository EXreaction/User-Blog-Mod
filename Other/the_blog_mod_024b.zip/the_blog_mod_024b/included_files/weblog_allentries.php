<?php
/***************************************************************************
 *                           weblog_allentries.php
 *                        ---------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   
 *   Maintained by: TheBlogMod.com Community
 *   Support: Visit www.TheBlogMod.com
 *
 *   $Id: weblog_allentries.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

//
// Start initial var setup
//
if( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) || isset($HTTP_POST_VARS[POST_WEBLOG_URL]) )
{
	$weblog_id = ( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) ) ? intval($HTTP_GET_VARS[POST_WEBLOG_URL]) : intval($HTTP_POST_VARS[POST_WEBLOG_URL]);
}
else
{
	$weblog_id = '';
}

if( isset($HTTP_GET_VARS['mode']) || isset($HTTP_POST_VARS['mode']) )
{
	$mode = ( isset($HTTP_GET_VARS['mode']) ) ? htmlspecialchars($HTTP_GET_VARS['mode']) : htmlspecialchars($HTTP_POST_VARS['mode']);
}
else
{
	$mode = '';
}


$start = ( isset($HTTP_GET_VARS['start']) ) ? intval($HTTP_GET_VARS['start']) : 0;

//
// End initial var setup
//

//
// Get the weblog
//
$sql = "SELECT *
	FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
	WHERE w.weblog_id = $weblog_id
		AND u.user_weblog = w.weblog_id";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain weblog information.", "", __LINE__, __FILE__, $sql);
}

$weblog_data = array();
if( !($weblog_data = $db->sql_fetchrow($result)) )
{
	message_die(GENERAL_MESSAGE, $lang['Weblog_not_exist']);
}

//
// Immediately check to see if this weblog is flagged for deletion
//
if ( $weblog_data['deleted'] )
{
	message_die(GENERAL_ERROR, sprintf($lang['Weblog_deactivated'], $weblog_data['weblog_name']));
}

//
// Start session management
//
$userdata = session_pagestart($user_ip, 10000 + $weblog_id);
init_userprefs($userdata);
//
// End session management
//

//
// Fetch Contributor data
//
$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE weblog_id = $weblog_id AND user_id = " . $userdata['user_id'];
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$contributor = FALSE;
if ( $row = $db->sql_fetchrow($result) || $userdata['user_level'] == ADMIN )
{
	$contributor = TRUE;
}

// Get user auth level
$auth_level = get_auth_level ($weblog_data, $contributor);

//
// Define censored word matches
//
$orig_word = array();
$replacement_word = array();
obtain_word_list($orig_word, $replacement_word);

$template_dir = get_template_dir ($weblog_data['template_id']);
$page_title = $weblog_data['weblog_name'] . ' :: ' . $lang['Entries'];
//
// Dump out the page header and load weblog template
//
use_weblog_header ($weblog_data, $template_dir);

//
// Prepare for the main query by figuring out what to adjust first. (Borrowed and Modified from phpBB code)
//
if( !empty($HTTP_POST_VARS['entrydays']) || !empty($HTTP_GET_VARS['entrydays']) )
{
	$entry_days = ( !empty($HTTP_POST_VARS['entrydays']) ) ? intval($HTTP_POST_VARS['entrydays']) : intval($HTTP_GET_VARS['entrydays']);
	$min_entry_time = time() - ($entry_days * 86400);

	$sql = "SELECT COUNT(e.entry_id) AS weblog_entries 
		FROM " . WEBLOG_ENTRIES_TABLE . " e, " . WEBLOG_REPLIES_TABLE . " r
		WHERE e.weblog_id = $weblog_id 
			AND r.reply_id = e.entry_last_post_id
			AND r.post_time >= $min_entry_time"; 

	if( !$result = $db->sql_query($sql) )
	{
		weblog_message_die(GENERAL_ERROR, "Couldn't obtain limited entries count information", "", __LINE__, __FILE__, $sql);
	}
	$row = $db->sql_fetchrow($result);

	$entry_count = $row['weblog_entries'];
	$limit_entries_time = "AND e.entry_time >= $min_entry_time";

	if( !empty($HTTP_POST_VARS['entrydays']) )
	{
		$start = 0;
	}
}
else
{
	$entry_count = $weblog_data['weblog_entries'];

	$limit_entries_time = '';
	$entry_days = 0;
}

//
// Generate a 'Show topics in previous x days' select box. If the topicsdays var is sent
// then get it's value, find the number of topics with dates newer than it (to properly
// handle pagination) and alter the main query (Borrowed and Modified from phpBB code)
//
$previous_days = array(0, 1, 7, 14, 30, 90, 180, 364);
$previous_days_text = array($lang['All_entries'], $lang['1_Day'], $lang['7_Days'], $lang['2_Weeks'], $lang['1_Month'], $lang['3_Months'], $lang['6_Months'], $lang['1_Year']);

$select_entry_days = '<select name="entrydays">';
for($i = 0; $i < count($previous_days); $i++)
{
	$selected = ($entry_days == $previous_days[$i]) ? ' selected="selected"' : '';
	$select_entry_days .= '<option value="' . $previous_days[$i] . '"' . $selected . '>' . $previous_days_text[$i] . '</option>';
}
$select_entry_days .= "</select>";

$template->set_filenames(array(
	'overall_header' => '../../weblogs/templates/' . $template_dir . '/weblog_header.htm',
	'body' => '../../weblogs/templates/' . $template_dir . '/weblog_allentries_body.htm',
	'overall_footer' => '../../weblogs/templates/' . $template_dir . '/weblog_footer.htm')
);


//
// Fetch Contributor data
//
$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE weblog_id = $weblog_id AND user_id = " . $userdata['user_id'];
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$contributor = FALSE;
if ( $row = $db->sql_fetchrow($result) || $userdata['user_level'] == ADMIN )
{
	$contributor = TRUE;
}

if ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor )
{
	$template->assign_block_vars('switch_weblog_owner', array() );
}

$template->assign_vars(array(

	'S_POST_DAYS_ACTION' => append_sid("weblog_allentries.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_id . "&amp;start=$start"),
	'S_SELECT_ENTRY_DAYS' => $select_entry_days,

	'U_WEBLOG' => append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id"),
	'U_WEBLOGS' => append_sid("weblogs.$phpEx"),
	'U_POST_NEW_ENTRY' => append_sid("weblog_posting.$phpEx?mode=newentry&amp;" . POST_WEBLOG_URL . "=$weblog_id"),
	'U_INDEX' => append_sid('index.'.$phpEx),
	'U_VIEW_MEMORABLE' => append_sid("weblog_allentries.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id&amp;mode=viewmemorable"),
	'U_VIEW_PRIVATE' => append_sid("weblog_allentries.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id&amp;mode=viewprivate"),
	'WEBLOG_NAME' => $weblog_data['weblog_name'],
	'OWNER' => $weblog_data['username'],
	'POST_ENTRY_IMG' => 'weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/newentry.gif',

	'L_WEBLOGS' => $lang['Weblogs'],
	'L_WEBLOG_OWNER' => $lang['Weblog_Owner'],
	'L_INDEX' => sprintf($lang['Forum_Index'], $board_config['sitename']),
	'L_POST_NEW_ENTRY' => $lang['Post_new_entry'],
	'L_ENTRIES' => $lang['Entries'],
	'L_REPLIES' => $lang['Replies'],
	'L_VIEWS' => $lang['Views'],
	'L_LASTREPLY' => $lang['Last_reply'],
	'L_NO_ENTRIES' => $lang['Sorry_no_entries'],
	'L_DISPLAY_ENTRIES' => $lang['Display_entries'],
	'L_GO' => $lang['Go'],
	'L_VIEW_PRIVATE' => $lang['View_private_entries'],
	'L_VIEW_MEMORABLE' => $lang['View_memorable_entries'],
	'MOD_VERSION' => WEBLOGS_MOD_VERSION)
);
//
// End header
//

$tracking_entries = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_e']) : '';
$tracking_weblogs = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w']) : '';

//
// Grab all dem entries
//

// Get all memorable entry data
$sql = "SELECT e.*, e.entry_id AS entry_id2, u.user_id, u.username, r.* FROM " . WEBLOG_ENTRIES_TABLE . " e
	LEFT OUTER JOIN " . WEBLOG_REPLIES_TABLE . " r
		ON e.entry_last_post_id = r.reply_id
	LEFT OUTER JOIN " . USERS_TABLE . " u
		ON r.poster_id = u.user_id
	WHERE e.weblog_id = " . $weblog_data['weblog_id'] . "
		AND e.entry_access " . (( $mode == 'viewprivate' ) ? '= ' . WEBLOG_AUTH_OWNER : '<= ' . $auth_level) . "
		AND e.memorable = 1
		AND e.entry_deleted <> " . TRUE . "
		$limit_entries_time
	ORDER BY entry_time DESC";
if(!($result = $db->sql_query($sql)))
{
	weblog_message_die(GENERAL_ERROR, 'Could not query weblog entry information', '', __LINE__, __FILE__, $sql);
}

$entry_data = array();
while ( $row = $db->sql_fetchrow($result) )
{
	$entry_data[] = $row;
}

if ( $mode != 'viewmemorable' )
{
	// Get all entry data
	$sql = "SELECT e.entry_id AS entry_id2, e.*, u.user_id, u.username, r.* FROM " . WEBLOG_ENTRIES_TABLE . " e
		LEFT OUTER JOIN " . WEBLOG_REPLIES_TABLE . " r
			ON e.entry_last_post_id = r.reply_id
		LEFT OUTER JOIN " . USERS_TABLE . " u
			ON r.poster_id = u.user_id
		WHERE e.weblog_id = " . $weblog_data['weblog_id'] . "
			AND e.entry_access " . (( $mode == 'viewprivate' ) ? '= ' . WEBLOG_AUTH_OWNER : '<= ' . $auth_level) . "
			AND e.memorable <> 1
			AND e.entry_deleted <> " . TRUE . "
			$limit_entries_time
		ORDER BY entry_time DESC
		LIMIT $start, " . $board_config['topics_per_page'];
	if(!($result = $db->sql_query($sql)))
	{
		weblog_message_die(GENERAL_ERROR, 'Could not query weblog entry information', '', __LINE__, __FILE__, $sql);
	}

	while ( $row = $db->sql_fetchrow($result) )
	{
		$entry_data[] = $row;
	}

	// Get all entry data
	$sql = "SELECT count(e.entry_id) AS total_entries FROM " . WEBLOG_ENTRIES_TABLE . " e
		WHERE e.weblog_id = " . $weblog_data['weblog_id'] . "
			AND e.entry_access " . (( $mode == 'viewprivate' ) ? '= ' . WEBLOG_AUTH_OWNER : '<= ' . $auth_level) . "
			AND e.memorable <> 1
			AND e.entry_deleted <> " . TRUE . "
			$limit_entries_time
		ORDER BY entry_time DESC";
	if(!($result = $db->sql_query($sql)))
	{
		weblog_message_die(GENERAL_ERROR, 'Could not query entry information', '', __LINE__, __FILE__, $sql);
	}

	$total_entries = 0;
	if ( $row = $db->sql_fetchrow($result) )
	{
		$total_entries = $row['total_entries'];
	}

}

//
// Get the moods data
//
$sql = "SELECT *
	FROM " . WEBLOG_MOODS_TABLE . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

//
// Get the actions data
//
$sql = "SELECT *
	FROM " . WEBLOG_ACTIONS_TABLE . "
	ORDER BY action_text";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't obtain action data from database", "", __LINE__, __FILE__, $sql);
}
$action_data = $db->sql_fetchrowset($result);

//
// Okay, lets dump out the page ...
//
if( count($entry_data) )
{
	for($i = 0; $i < count($entry_data); $i++)
	{
		$entry_id = $entry_data[$i]['entry_id2'];

		$entry_subject = ( count($orig_word) && $weblog_config['censor_weblog'] ) ? preg_replace($orig_word, $replacement_word, $entry_data[$i]['entry_subject']) : $entry_data[$i]['entry_subject'];

		$replies = $entry_data[$i]['entry_replies'];

		// Mood Icons
		$mood = array();
		$mood = find_mood($entry_data[$i]['entry_mood']);

		if ( $mood >= 0 )
		{ 
			$mood = '<img src="images/weblogs/' . $mood['mood_url'] . '" alt="' . $mood_data['mood_text'] . '" border="0" />';
		}
		else
		{
			$mood = '';
		}

		// Currently Icons
		$currently = array();
		$currently = find_action($entry_data[$i]['entry_currently']);

		if ( $currently > 0 )
		{
			$action = '<img src="images/weblogs/' . $currently['action_url'] . '" alt="' . $currently['action_text'] . ' ' . $entry_data[$i]['currently_text'] . '" border="0" />'; 
		}
		else
		{
			$action = '';
		}

		if( $entry_data[$i]['memorable'] && $entry_data[$i]['no_replies'] )
		{
			$entry = "weblogs/templates/$template_dir/entry_memorable_locked.gif";
			$entry_new = "weblogs/templates/$template_dir/entry_memorable_locked_new.gif";
		}
		else if( $entry_data[$i]['memorable'] )
		{
			$entry = "weblogs/templates/$template_dir/entry_memorable.gif";
			$entry_new = "weblogs/templates/$template_dir/entry_memorable_new.gif";
		}
		else if( $entry_data[$i]['no_replies'] )
		{
			$entry = "weblogs/templates/$template_dir/entry_locked.gif";
			$entry_new = "weblogs/templates/$template_dir/entry_locked_new.gif";
		}
		else
		{
			if( $replies >= $board_config['hot_threshold'] )
			{
				$entry = "weblogs/templates/$template_dir/entry_hot.gif";
				$entry_new = "weblogs/templates/$template_dir/entry_hot_new.gif";
			}
			else
			{
				$entry = "weblogs/templates/$template_dir/entry.gif";
				$entry_new = "weblogs/templates/$template_dir/entry_new.gif";
			}
		}

		$last_post_time = '';
		$last_post_url = '';
		$last_post_author = '';

		$newest_post_img = '';
		if( $userdata['session_logged_in'] )
		{
			if( $entry_data[$i]['entry_time'] > $userdata['user_lastvisit'] ) 
			{
				if( !empty($tracking_entries) || !empty($tracking_weblogs) || isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_w_all']) )
				{
					$unread_entries = true;

					if( !empty($tracking_entries[$entry_id]) )
					{
						if( $tracking_entries[$entry_id] >= $entry_data[$i]['post_time'] )
						{
							$unread_entries = false;
						}
					}

					if( !empty($tracking_weblogs[$weblog_id]) )
					{
						if( $tracking_weblogs[$weblog_id] >= $entry_data[$i]['post_time'] )
						{
							$unread_entries = false;
						}
					}

					if( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_f_all']) )
					{
						if( $HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_f_all'] >= $entry_data[$i]['post_time'] )
						{
							$unread_entries = false;
						}
					}

					if( $unread_entries )
					{
						$entry_image = $entry_new;
						$entry_alt = $lang['New_posts'];

						$newest_post_img = '<a href="' . append_sid("weblog_entry.$phpEx?"  . POST_ENTRY_URL . '=' . $entry_id) . '"><img src="weblogs/templates/' . $template_dir . '/icon_newest_reply.gif" alt="' . $lang['View_newest_post'] . '" title="' . $lang['View_newest_post'] . '" border="0" /></a> ';
					}
					else
					{
						$entry_image = $entry;
						$entry_alt = ( $entry_data[$i]['no_replies'] ) ? $lang['Entry_locked'] : $lang['No_new_posts'];

						$newest_post_img = '';
					}
				}
				else
				{
					$entry_image = $entry_new;
					$entry_alt = ( $entry_data[$i]['no_replies'] ) ? $lang['Entry_locked'] : $lang['No_new_posts'];

					$newest_post_img = '<a href="' . append_sid("weblog_entry.$phpEx?"  . POST_ENTRY_URL . '=' . $entry_id) . '"><img src="weblogs/templates/' . $template_dir . '/icon_newest_reply.gif" alt="' . $lang['View_newest_post'] . '" title="' . $lang['View_newest_post'] . '" border="0" /></a> ';
				}
			}
			else 
			{
				$entry_image = $entry;
				$entry_alt = ( $entry_data[$i]['no_replies'] ) ? $lang['Entry_locked'] : $lang['No_new_posts'];

				$newest_post_img = '';
			}
		}
		else
		{
			$entry_image = $entry;
			$entry_alt = ( $entry_data[$i]['no_replies'] ) ? $lang['Entry_locked'] : $lang['No_new_posts'];

			$newest_post_img = '';
		}


		if ( $entry_data[$i]['reply_id'] )
		{
			$last_post_time = create_date($board_config['default_dateformat'], $entry_data[$i]['post_time'], $board_config['board_timezone']);

			$last_post_author = ( $entry_data[$i]['poster_id'] == ANONYMOUS ) ? ( ($entry_data[$i]['post_username'] != '' ) ? $entry_data[$i]['post_username'] . ' ' : $lang['Guest'] . ' ' ) : '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . '='  . $entry_data[$i]['user_id']) . '">' . $entry_data[$i]['username'] . '</a>';
		
			if( !$entry_data[$i]['entry_last_post_id'] )
			{
				$last_post_url = $newest_post_img;
			}
			else
			{
				$last_post_url = '<a href="' . append_sid("weblog_entry.$phpEx?"  . POST_REPLY_URL . '=' . $entry_data[$i]['reply_id']) . '#' . $entry_data[$i]['reply_id'] . '"><img src="weblogs/templates/' . $template_dir . '/icon_latest_reply.gif" alt="' . $lang['View_latest_post'] . '" title="' . $lang['View_latest_post'] . '" border="0" /></a>';
			}
		}
		else
		{
			$last_post_time = $lang['No_replies_yet'];
			$last_post_url = '';
		}

		if( ( $replies + 1 ) > $board_config['posts_per_page'] )
		{
			$total_pages = ceil( ( $replies + 1 ) / $board_config['posts_per_page'] );
			$goto_page = ' [ <img src="weblogs/templates/' . $template_dir . '/icon_latest_reply.gif" alt="' . $lang['Goto_page'] . '" title="' . $lang['Goto_page'] . '" />' . $lang['Goto_page'] . ': ';

			$times = 1;
			for($j = 0; $j < $replies + 1; $j += $board_config['posts_per_page'])
			{
				$goto_page .= '<a href="' . append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=" . $entry_id . "&amp;start=$j") . '">' . $times . '</a>';
				if( $times == 1 && $total_pages > 4 )
				{
					$goto_page .= ' ... ';
					$times = $total_pages - 3;
					$j += ( $total_pages - 4 ) * $board_config['posts_per_page'];
				}
				else if ( $times < $total_pages )
				{
					$goto_page .= ', ';
				}
				$times++;
			}
			$goto_page .= ' ] ';
		}
		else
		{
			$goto_page = '';
		}
		
		$view_entry_url = append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=$entry_id");

		$first_post_time = create_date($board_config['default_dateformat'], $entry_data[$i]['entry_time'], $board_config['board_timezone']);

		$views = $entry_data[$i]['entry_views'];

		$row_class = ( !($i % 2) ) ? 'row1' : 'row2';

		$template->assign_block_vars('entryrow', array(
			'ROW_CLASS' => $row_class,
			'ENTRY_ICON' => $entry_image,
			'L_ENTRY_ICON_ALT' => $entry_alt,

			'MOOD' => $mood,
			'ACTION' => $action,
			'NEWEST_ENTRY_IMG' => $newest_post_img,
			'MEMORABLE' => ( $entry_data[$i]['memorable'] ) ? $lang['Entry_Memorable'] : '',
			'ENTRY_SUBJECT' => $entry_subject,
			'GOTO_PAGE' => $goto_page,
			'REPLIES' => $replies,
			'VIEWS' => $views,

			'LAST_POST_TIME' => $last_post_time, 
			'LAST_POST_AUTHOR' => $last_post_author, 
			'LAST_POST_IMG' => $last_post_url, 

			'U_VIEW_ENTRY' => $view_entry_url)
		);
	}

	$template->assign_vars(array(
		'PAGINATION' => generate_pagination("weblog_allentries.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id&amp;entrydays=$entry_days", $total_entries, $board_config['topics_per_page'], $start),
		'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $board_config['topics_per_page'] ) + 1 ), ceil( count($entry_data) / $board_config['topics_per_page'] )), 

		'L_GOTO_PAGE' => $lang['Goto_page'])
	);
}
else
{
	//
	// No topics
	//
	$template->assign_block_vars('switch_no_entries', array() );

}

$template->assign_vars(array(
	'L_POWERED_BY' => sprintf($lang['Weblog_powered_by'], WEBLOGS_MOD_VERSION))
);

if ( $weblog_data['font'] >= 0 && $weblog_data['font'] <= 6 )
{
	$font = $weblog_fonts[$weblog_data['font']];
}
else
{
	$font = $weblog_fonts[0];
}

$template->assign_vars(array(
	'BACKGROUND_COLOR' => $weblog_data['background_color'],
	'ENTRY_BG_COLOR' => $weblog_data['entry_bg_color'],
	'BORDER_COLOR' => $weblog_data['border_color'],
	'BACKGROUND_IMAGE' => $weblog_data['background_image'],
	'BACKGROUND_IMAGE_FIXED' => ( $weblog_data['background_image_fixed'] ) ? 'fixed' : 'scroll',
	'BACKGROUND_REPEAT' => $weblog_data['tile_bg'],
	'BACKGROUND_POSITION' => $weblog_data['bg_ypos'] . ' ' . $weblog_data['bg_xpos'],
	'SB_FACE_COLOR' => $weblog_data['sb_face_color'],
	'SB_HIGHLIGHT_COLOR' => $weblog_data['sb_highlight_color'],
	'SB_SHADOW_COLOR' => $weblog_data['sb_shadow_color'],
	'SB_3DLIGHT_COLOR' => $weblog_data['sb_3dlight_color'],
	'SB_ARROW_COLOR' => $weblog_data['sb_arrow_color'],
	'SB_TRACK_COLOR' => $weblog_data['sb_track_color'],
	'SB_DARKSHADOW_COLOR' => $weblog_data['sb_darkshadow_color'],
	'FONT' => $font,
	'FONT_COLOR' => $weblog_data['font_color'],
	'FONT_SIZE' => $weblog_data['font_size'],
	'NORMAL_LINK_COLOR' => $weblog_data['normal_link_color'],
	'NORMAL_LINK_UNDERLINED' => ( $weblog_data['normal_link_underline'] ) ? 'underline' : 'none',
	'ACTIVE_LINK_COLOR' => $weblog_data['active_link_color'],
	'ACTIVE_LINK_UNDERLINED' => ( $weblog_data['active_link_underline'] ) ? 'underline': 'none',
	'HOVER_LINK_COLOR' => $weblog_data['hover_link_color'],
	'HOVER_LINK_UNDERLINED' => ( $weblog_data['hover_link_underline'] ) ? 'underline': 'none',
	'VISITED_LINK_COLOR' => $weblog_data['visited_link_color'],
	'VISITED_LINK_UNDERLINED' => ( $weblog_data['visited_link_underline'] ) ? 'underline': 'none',
	'WEBLOG_TITLE_COLOR' => $weblog_data['weblog_title_color'],
	'WEBLOG_TITLE_FONT_SIZE' => $weblog_data['weblog_title_font_size'],
	'ENTRY_TITLE_COLOR' => $weblog_data['entry_title_color'],
	'ENTRY_TITLE_FONT_SIZE' => $weblog_data['entry_title_font_size'],
	'DATE_TIME_COLOR' => $weblog_data['date_time_color'],
	'DATE_TIME_FONT_SIZE' => $weblog_data['date_time_font_size'],
	'BLOCK_TITLE_COLOR' => $weblog_data['block_title_color'],
	'BLOCK_TITLE_FONT_SIZE' => $weblog_data['block_title_font_size'],
	'BLOCK_BG_COLOR' => $weblog_data['block_bg_color'],
	'BLOCK_BORDER_COLOR' => $weblog_data['block_border_color'])
);

//
// Parse the page and print
//
$template->pparse('body');

use_weblog_footer ( $weblog_data, $template_dir );

?>
