<?php
/***************************************************************************
 *                           admin_weblog_mood.php
 *                        ---------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   email                : vinng86@hotmail.com
 *
 *   $Id: admin_weblog_mood.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);


//
// First we do the setmodules stuff for the admin cp.
//
if( !empty($setmodules) )
{
	$filename = basename(__FILE__);
	$module['Blog_admin']['Mood_choices'] = $filename;

	return;
}

$phpbb_root_path = "./../";
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'language/lang_' . $use_lang . '/lang_weblog_admin.' . $phpEx);

//
// Get the moods data
//
$sql = "SELECT *
	FROM " . WEBLOG_MOODS_TABLE . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

$sql = "SELECT *
	FROM " . WEBLOG_MOOD_SETS_TABLE . "
	ORDER BY set_id";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain mood set data from database", "", __LINE__, __FILE__, $sql);
}
$mood_set_data = $db->sql_fetchrowset($result);

//
// Check to see what mode we should operate in.
//
if( isset($HTTP_POST_VARS['mode']) || isset($HTTP_GET_VARS['mode']) )
{
	$mode = ( isset($HTTP_POST_VARS['mode']) ) ? $HTTP_POST_VARS['mode'] : $HTTP_GET_VARS['mode'];
}
else
{
	$mode = "";
}

if (isset($HTTP_POST_VARS['import']))
{
	$mode = 'import';
}

if (isset($HTTP_POST_VARS['importsmilies']))
{
	$mode = 'importsmilies';
}

//
// Read a listing of uploaded mood icons for use in the add or edit smliey code...
//
$dir = @opendir($phpbb_root_path . 'images/weblogs/');

while($file = @readdir($dir))
{
	if( !@is_dir(phpbb_realpath($phpbb_root_path . 'images/weblogs/' . $file)) )
	{
		$img_size = @getimagesize($phpbb_root_path . 'images/weblogs/' . $file);

		if( $img_size[0] && $img_size[1] )
		{
			$mood_images[] = $file;
		}
	}
}

@closedir($dir);

if ( isset($HTTP_POST_VARS['id']) )
{
	$id = intval($HTTP_POST_VARS['id']);
}
else if ( isset($HTTP_GET_VARS['id']) )
{
	$id = intval($HTTP_GET_VARS['id']);
}

//
// Select main mode
//
switch( $mode )
{
	case 'import':
		//
		// Admin has selected to import phpBB2 smilies
		//
		$template->set_filenames(array(
			"body" => "admin/weblog_import_smile_body.tpl")
		);

		$filename_list = "";
		for( $i = 0; $i < count($mood_images); $i++ )
		{
			$filename_list .= '<option value="' . $mood_images[$i] . '">' . $mood_images[$i] . '</option>';
		}

		$s_hidden_fields = '<input type="hidden" name="mode" value="import" /><input type="hidden" name="id" value="' . $id . '" />';

		$sql = "SELECT *
			FROM " . SMILIES_TABLE . "
			GROUP BY emoticon";
		$result = $db->sql_query($sql);
		if( !$result )
		{
			message_die(GENERAL_ERROR, "Couldn't obtain smileys from database", "", __LINE__, __FILE__, $sql);
		}

		$smilies = $db->sql_fetchrowset($result);

		$select_mood_set = '<select name="mood_set">';
		for ( $i = 0; $i < count($mood_set_data); $i++ )
		{
			$select_mood_set .= '<option value="' . $mood_set_data[$i]['set_id'] . '">' . $mood_set_data[$i]['set_name'] . '</option>';
		}
		$select_mood_set .= '</select>';
		

		$template->assign_vars(array(
			"L_SMILEY_IMPORT_TITLE" => $lang['Smilie_import_utility'],
			"L_SMILEY_IMPORT_TEXT" => $lang['Smilie_import_utility_explain'],
			"L_EMOT" => $lang['Emotion'],
			"L_IMPORT_SMILIES" => $lang['Import_smilies'],
			"S_HIDDEN_FIELDS" => $s_hidden_fields, 
			"SELECT_MOOD_SET" => $select_mood_set,
			"S_SMILEY_IMPORT_ACTION" => append_sid("admin_weblog_mood.$phpEx"),
			"S_FILENAME_OPTIONS" => $filename_list)
		);

		for($i = 0; $i < count($smilies); $i++)
		{
			//
			// Replace htmlentites for < and > with actual character.
			//
			$row_color = ( !($i % 2) ) ? $theme['td_color1'] : $theme['td_color2'];
			$row_class = ( !($i % 2) ) ? $theme['td_class1'] : $theme['td_class2'];

			$template->assign_block_vars("smiles", array(
				"ROW_COLOR" => "#" . $row_color,
				"ROW_CLASS" => $row_class,

				"SMILEY_IMG" =>  $phpbb_root_path . $board_config['smilies_path'] . '/' . $smilies[$i]['smile_url'], 
				"EMOT" => $smilies[$i]['emoticon'],
				
				"CHECKBOX" => $smilies[$i]['smilies_id'])
			);
		}

		$template->pparse("body");

		break;
	case 'importsmilies':
		//
		// Admin has selected to import some smiles.
		//
		$mood_set = 0;
		if ( isset($HTTP_POST_VARS['mood_set']) )
		{
			$mood_set = intval($HTTP_POST_VARS['mood_set']);
		}
		

		$sql = "SELECT *
			FROM " . SMILIES_TABLE . "
			GROUP BY emoticon";
		$result = $db->sql_query($sql);
		if( !$result )
		{
			message_die(GENERAL_ERROR, "Couldn't obtain smileys from database", "", __LINE__, __FILE__, $sql);
		}
		$smilies = $db->sql_fetchrowset($result);

		//
		// Find Maximum Mood Id
		//
		$sql = "SELECT MAX(mood_id) AS max_id FROM " . WEBLOG_MOODS_TABLE;
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't find maximum mood id", "", __LINE__, __FILE__, $sql);
		}

		$max_mood_id = 0;

		if ( $row = $db->sql_fetchrowset($result) )
		{
			$max_mood_id = $row[0]['max_id'] + 1;
		}

		for($i = 0; $i < count($smilies); $i++)
		{
			if ( isset($HTTP_POST_VARS[$smilies[$i]['smilies_id']]))
			{
				@copy ('../images/smiles/' . $smilies[$i]['smile_url'], '../images/weblogs/' . $smilies[$i]['smile_url']);
				$sql = "INSERT INTO " . WEBLOG_MOODS_TABLE . " (mood_id, mood_text, mood_url, mood_set) VALUES ($max_mood_id, '" . addslashes($smilies[$i]['emoticon']) . "', '" . addslashes($smilies[$i]['smile_url']) . "', $mood_set) ";
				if( !$result = $db->sql_query($sql) )
				{
					message_die(GENERAL_ERROR, "Couldn't update the mood table", "", __LINE__, __FILE__, $sql);
				}
				$max_mood_id++;
			}
		}

		$message = $lang['Import_smilies_success'] . "<br /><br />" . sprintf($lang['Click_return_moodadmin'], "<a href=\"" . append_sid("admin_weblog_mood.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);

		break;
	case 'addmood':
		//
		// Admin has selected to add a mood.
		//

		$template->set_filenames(array(
			"body" => "admin/weblog_mood_edit_body.tpl")
		);

		$filename_list = "";
		for( $i = 0; $i < count($mood_images); $i++ )
		{
			$filename_list .= '<option value="' . $mood_images[$i] . '">' . $mood_images[$i] . '</option>';
		}

		$s_hidden_fields = '<input type="hidden" name="mode" value="savenewmood" /><input type="hidden" name="id" value="' . $id . '" />';

		$template->assign_vars(array(
			"L_MOOD_TITLE" => $lang['Weblog_mood_title'],
			"L_MOOD_CONFIG" => $lang['Weblog_mood_config'],
			"L_MOOD_EXPLAIN" => $lang['Weblog_mood_explain'],
			"L_MOOD_URL" => $lang['Weblog_mood_url'],
			"L_MOOD_MOOD" => $lang['Weblog_mood_mood'],
			"L_SUBMIT" => $lang['Submit'],
			"L_RESET" => $lang['Reset'],

			"MOOD_IMG" => $phpbb_root_path . 'images/weblogs/' . $mood_images[0], 

			"S_MOOD_ACTION" => append_sid("admin_weblog_mood.$phpEx"), 
			"S_HIDDEN_FIELDS" => $s_hidden_fields, 
			"S_FILENAME_OPTIONS" => $filename_list)
		);

		$template->pparse("body");

		break;

	case 'addset':
		//
		// Admin has selected to add a new set.
		//

		$template->set_filenames(array(
			"body" => "admin/weblog_mood_set_edit_body.tpl")
		);

		$s_hidden_fields = '<input type="hidden" name="mode" value="savenewset" />';

		$template->assign_vars(array(
			"L_MOOD_TITLE" => $lang['Weblog_mood_set_title'],
			"L_MOOD_CONFIG" => $lang['Weblog_mood_set_config'],
			"L_MOOD_EXPLAIN" => $lang['Weblog_mood_set_explain'],
			"L_MOOD_SET" => $lang['Mood_set'],
			"L_SUBMIT" => $lang['Submit'],
			"L_RESET" => $lang['Reset'],

			"MOOD_SET" => '',

			"S_MOOD_SET_ACTION" => append_sid("admin_weblog_mood.$phpEx"),
			"S_HIDDEN_FIELDS" => $s_hidden_fields)
		);

		$template->pparse("body");

		break;
	case 'deletemood':
		//
		// Admin has selected to delete a mood.
		//

		$mood_id = $id;

		$sql = "DELETE FROM " . WEBLOG_MOODS_TABLE . "
			WHERE mood_id = " . $mood_id . "";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't delete mood", "", __LINE__, __FILE__, $sql);
		}

		$message = $lang['Weblog_mood_del_success'] . "<br /><br />" . sprintf($lang['Click_return_moodadmin'], "<a href=\"" . append_sid("admin_weblog_mood.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);

		break;
	case 'deleteset':
		//
		// Admin has selected to delete an entire mood set.
		//
		$set_id = $id;

		// Find all moods under this set
		$sql = "DELETE FROM " . WEBLOG_MOODS_TABLE . "
			WHERE mood_set = $set_id";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't delete moods under this mood set", "", __LINE__, __FILE__, $sql);
		}

		$sql = "DELETE FROM " . WEBLOG_MOOD_SETS_TABLE . "
			WHERE set_id = $set_id";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't delete moods under this mood set", "", __LINE__, __FILE__, $sql);
		}

		$message = $lang['Weblog_mood_set_del_success'] . "<br /><br />" . sprintf($lang['Click_return_moodadmin'], "<a href=\"" . append_sid("admin_weblog_mood.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);

		break;

	case 'editmood':
		//
		// Admin has selected to edit a mood.
		//

		$mood_id = $id;

		$sql = "SELECT *
			FROM " . WEBLOG_MOODS_TABLE . "
			WHERE mood_id = " . $mood_id;
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, 'Could not obtain mood information', "", __LINE__, __FILE__, $sql);
		}
		$mood_data = $db->sql_fetchrow($result);

		$filename_list = "";
		for( $i = 0; $i < count($mood_images); $i++ )
		{
			if( $mood_images[$i] == $mood_data['mood_url'] )
			{
				$mood_selected = "selected=\"selected\"";
				$mood_edit_img = $mood_images[$i];
			}
			else
			{
				$mood_selected = "";
			}

			$filename_list .= '<option value="' . $mood_images[$i] . '"' . $mood_selected . '>' . $mood_images[$i] . '</option>';
		}

		$template->set_filenames(array(
			"body" => "admin/weblog_mood_edit_body.tpl")
		);

		$s_hidden_fields = '<input type="hidden" name="mode" value="savemood" /><input type="hidden" name="mood_id" value="' . $mood_data['mood_id'] . '" />';

		$template->assign_vars(array(
			"L_MOOD_TITLE" => $lang['Weblog_mood_title'],
			"L_MOOD_CONFIG" => $lang['Weblog_mood_config'],
			"L_MOOD_EXPLAIN" => $lang['Weblog_mood_explain'],
			"L_MOOD_URL" => $lang['Weblog_mood_url'],
			"L_MOOD_MOOD" => $lang['Weblog_mood_mood'],
			"L_SUBMIT" => $lang['Submit'],
			"L_RESET" => $lang['Reset'],

			"MOOD_IMG" => $phpbb_root_path . 'images/weblogs/' . $mood_edit_img, 
			"MOOD_MOOD" => $mood_data['mood_text'],

			"S_MOOD_ACTION" => append_sid("admin_weblog_mood.$phpEx"),
			"S_HIDDEN_FIELDS" => $s_hidden_fields, 
			"S_FILENAME_OPTIONS" => $filename_list)
		);

		$template->pparse("body");

		break;

	case 'editset':
		//
		// Admin has selected to edit a mood set.
		//
		$set_id = $id;

		$sql = "SELECT *
			FROM " . WEBLOG_MOOD_SETS_TABLE . "
			WHERE set_id = " . $set_id;
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, 'Could not obtain mood set information', "", __LINE__, __FILE__, $sql);
		}
		$mood_set_data = $db->sql_fetchrow($result);

		$template->set_filenames(array(
			"body" => "admin/weblog_mood_set_edit_body.tpl")
		);

		$s_hidden_fields = '<input type="hidden" name="mode" value="saveset" /><input type="hidden" name="id" value="' . $mood_set_data['set_id'] . '" />';

		$template->assign_vars(array(
			"L_MOOD_TITLE" => $lang['Weblog_mood_set_title'],
			"L_MOOD_CONFIG" => $lang['Weblog_mood_set_config'],
			"L_MOOD_EXPLAIN" => $lang['Weblog_mood_set_explain'],
			"L_MOOD_SET" => $lang['Mood_set'],
			"L_SUBMIT" => $lang['Submit'],
			"L_RESET" => $lang['Reset'],

			"MOOD_SET" => $mood_set_data['set_name'],

			"S_MOOD_SET_ACTION" => append_sid("admin_weblog_mood.$phpEx"),
			"S_HIDDEN_FIELDS" => $s_hidden_fields, 
			"S_FILENAME_OPTIONS" => $filename_list)
		);

		$template->pparse("body");

		break;

	case 'savemood':
		//
		// Admin has submitted changes while editing a mood.
		//

		//
		// Get the submitted data, being careful to ensure that we only
		// accept the data we are looking for.
		//
		$mood_url = ( isset($HTTP_POST_VARS['mood_url']) ) ? trim($HTTP_POST_VARS['mood_url']) : trim($HTTP_GET_VARS['mood_url']);
		$mood_mood = ( isset($HTTP_POST_VARS['mood_mood']) ) ? trim($HTTP_POST_VARS['mood_mood']) : trim($HTTP_GET_VARS['mood_mood']);
		$mood_id = ( isset($HTTP_POST_VARS['mood_id']) ) ? intval($HTTP_POST_VARS['mood_id']) : intval($HTTP_GET_VARS['mood_id']);

		// If no code was entered complain ...
		if ( $mood_url == '')
		{
			message_die(MESSAGE, $lang['Fields_empty']);
		}

		//
		// Proceed with updating the mood table.
		//
		$sql = "UPDATE " . WEBLOG_MOODS_TABLE . "
			SET mood_url = '" . str_replace("\'", "''", $mood_url) . "', mood_text = '" . str_replace("\'", "''", $mood_mood) . "'
			WHERE mood_id = $mood_id";
		if( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, "Couldn't update mood info", "", __LINE__, __FILE__, $sql);
		}

		$message = $lang['Weblog_mood_edit_success'] . "<br /><br />" . sprintf($lang['Click_return_moodadmin'], "<a href=\"" . append_sid("admin_weblog_mood.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);

		break;

	case 'saveset':
		//
		// Admin has submitted changes while editing a set.
		//

		//
		// Get the submitted data, being careful to ensure that we only
		// accept the data we are looking for.
		//
		$set_name = ( isset($HTTP_POST_VARS['set_name']) ) ? trim($HTTP_POST_VARS['set_name']) : trim($HTTP_GET_VARS['set_name']);
		$set_id = ( isset($HTTP_POST_VARS['set_id']) ) ? intval($HTTP_POST_VARS['set_id']) : intval($HTTP_GET_VARS['set_id']);

		// If no code was entered complain ...
		if ( $set_name == '')
		{
			message_die(MESSAGE, $lang['Fields_empty']);
		}

		//
		// Proceed with updating the mood sets table.
		//
		$sql = "UPDATE " . WEBLOG_MOOD_SETS_TABLE . "
			SET set_name = '" . str_replace("\'", "''", $set_name) . "'
			WHERE set_id = $set_id";
		if( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, "Couldn't update mood set info", "", __LINE__, __FILE__, $sql);
		}

		$message = $lang['Weblog_mood_edit_success'] . "<br /><br />" . sprintf($lang['Click_return_moodadmin'], "<a href=\"" . append_sid("admin_weblog_mood.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);

		break;
	case 'savenewmood':
		//
		// Admin has submitted changes while adding a new mood.
		//

		//
		// Get the submitted data being careful to ensure the the data
		// we recieve and process is only the data we are looking for.
		//
		$mood_url = ( isset($HTTP_POST_VARS['mood_url']) ) ? $HTTP_POST_VARS['mood_url'] : $HTTP_GET_VARS['mood_url'];
		$mood_mood = ( isset($HTTP_POST_VARS['mood_mood']) ) ? $HTTP_POST_VARS['mood_mood'] : $HTTP_GET_VARS['mood_mood'];

		// If no code was entered complain ...
		if ($mood_url == '')
		{
			message_die(MESSAGE, $lang['Fields_empty']);
		}

		//
		// Find Maximum Mood Id
		//
		$sql = "SELECT MAX(mood_id) AS max_id FROM " . WEBLOG_MOODS_TABLE;
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't find maximum mood id", "", __LINE__, __FILE__, $sql);
		}

		$max_mood_id = 0;
		if ( $row = $db->sql_fetchrowset($result) )
		{
			$max_mood_id = $row[0]['max_id'] + 1;
		}

		//
		// Save the data to the mood table.
		//
		$sql = "INSERT INTO " . WEBLOG_MOODS_TABLE . " (mood_id, mood_url, mood_text, mood_set)
			VALUES ($max_mood_id, '$mood_url', '$mood_mood', $id)";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't insert new mood", "", __LINE__, __FILE__, $sql);
		}

		$message = $lang['Weblog_mood_add_success'] . "<br /><br />" . sprintf($lang['Click_return_moodadmin'], "<a href=\"" . append_sid("admin_weblog_mood.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);

		break;

	case 'savenewset':
		//
		// Admin has submitted changes while adding a new set.
		//

		//
		// Get the submitted data being careful to ensure the the data
		// we recieve and process is only the data we are looking for.
		//
		$set_name = ( isset($HTTP_POST_VARS['set_name']) ) ? $HTTP_POST_VARS['set_name'] : $HTTP_GET_VARS['set_name'];

		// If no code was entered complain ...
		if ($set_name == '')
		{
			message_die(MESSAGE, $lang['Fields_empty']);
		}

		//
		// Find Maximum Mood Set Id
		//
		$sql = "SELECT MAX(set_id) AS max_id FROM " . WEBLOG_MOOD_SETS_TABLE;
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't find maximum mood set id", "", __LINE__, __FILE__, $sql);
		}

		$max_set_id = 0;
		if ( $row = $db->sql_fetchrowset($result) )
		{
			$max_set_id = $row[0]['max_id'] + 1;
		}

		//
		// Save the data to the mood table.
		//
		$sql = "INSERT INTO " . WEBLOG_MOOD_SETS_TABLE . " (set_id, set_name)
			VALUES ($max_set_id, '$set_name')";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't insert new mood set", "", __LINE__, __FILE__, $sql);
		}

		$message = $lang['Weblog_mood_set_add_success'] . "<br /><br />" . sprintf($lang['Click_return_moodadmin'], "<a href=\"" . append_sid("admin_weblog_mood.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);

		break;

	default:

		//
		// This is the main display of the page before the admin has selected
		// any options.
		//
	
		$template->set_filenames(array(
			"body" => "admin/weblog_mood_list_body.tpl")
		);

		$s_hidden_fields = '<input type="hidden" name="type" value="set" />';
	
		$template->assign_vars(array(
			"L_ACTION" => $lang['Action'],
			"L_MOOD_TITLE" => $lang['Weblog_mood_title'],
			"L_MOOD_TEXT" => $lang['Weblog_mood_explain'],
			"L_DELETE" => $lang['Delete'],
			"L_EDIT" => $lang['Edit'],
			"L_ADD_MOOD" => $lang['Add_mood'],
			"L_MOOD_ADD" => $lang['Weblog_mood_add'],
			"L_IMAGE" => $lang['Weblog_image'],
			"L_MOOD" => $lang['Weblog_mood'],
			"L_MOOD_SET_ADD" => $lang['Weblog_mood_set_add'],
			"L_IMPORT_SMILIES" => $lang['Import_phpbb_smilies'],
	
			"S_HIDDEN_FIELDS" => $s_hidden_fields,
			"S_MOOD_ACTION" => append_sid("admin_weblog_mood.$phpEx?mode=addset"))
		);
	
		// Organize Everything
		for ( $i = 0; $i < count($mood_set_data); $i++)
		{
			$row_color = ( !($i % 2) ) ? $theme['td_color1'] : $theme['td_color2'];
			$row_class = ( !($i % 2) ) ? $theme['td_class1'] : $theme['td_class2'];
	
			$template->assign_block_vars("mood_set", array(
				"ROW_COLOR" => "#" . $row_color,
				"ROW_CLASS" => $row_class,
	
				"SET_NAME" => $mood_set_data[$i]['set_name'],
	
				"U_SET_ADD" => append_sid("admin_weblog_mood.$phpEx?mode=addmood&amp;id=" . $mood_set_data[$i]['set_id']),
				"U_SET_EDIT" => append_sid("admin_weblog_mood.$phpEx?mode=editset&amp;id=" . $mood_set_data[$i]['set_id']), 
				"U_SET_DELETE" => append_sid("admin_weblog_mood.$phpEx?mode=deleteset&amp;id=" . $mood_set_data[$i]['set_id']))
			);
	
			for ($j = 0; $j < count($mood_data); $j++)
			{
				$row_color = ( !($j % 2) ) ? $theme['td_color1'] : $theme['td_color2'];
				$row_class = ( !($j % 2) ) ? $theme['td_class1'] : $theme['td_class2'];
	
				if ( $mood_data[$j]['mood_set'] == $mood_set_data[$i]['set_id'] )
				{
					$template->assign_block_vars("mood_set.mood", array(
						"ROW_COLOR" => "#" . $row_color,
						"ROW_CLASS" => $row_class,
				
						"MOOD_IMG" =>  $phpbb_root_path . 'images/weblogs/' . $mood_data[$j]['mood_url'], 
						"MOOD" => $mood_data[$j]['mood_text'],
				
						"U_MOOD_EDIT" => append_sid("admin_weblog_mood.$phpEx?mode=editmood&amp;id=" . $mood_data[$j]['mood_id']), 
						"U_MOOD_DELETE" => append_sid("admin_weblog_mood.$phpEx?mode=deletemood&amp;id=" . $mood_data[$j]['mood_id']))
					);
				}
			}
		}

		//
		// Spit out the page.
		//
		$template->pparse("body");
}

//
// Page Footer
//
include('./page_footer_admin.'.$phpEx);

?>
