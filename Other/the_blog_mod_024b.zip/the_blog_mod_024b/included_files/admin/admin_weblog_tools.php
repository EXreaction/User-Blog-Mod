<?php
/***************************************************************************
 *                           admin_weblog_tools.php
 *                        ----------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   
 *   Maintained by: TheBlogMod.com Community
 *   Support: Visit www.TheBlogMod.com
 *
 *   $Id: admin_weblog_tools.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
	$filename = basename(__FILE__);
	$module['Blog_admin']['Weblog_tools'] = $filename;

	return;
}

$phpbb_root_path = './../';
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);
include($phpbb_root_path . 'includes/functions_selects.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'language/lang_' . $use_lang . '/lang_weblog_admin.' . $phpEx);

$html_entities_match = array('#<#', '#>#');
$html_entities_replace = array('&lt;', '&gt;');

//
// Set mode
//
if( isset( $HTTP_POST_VARS['mode'] ) || isset( $HTTP_GET_VARS['mode'] ) )
{
	$mode = ( isset( $HTTP_POST_VARS['mode']) ) ? $HTTP_POST_VARS['mode'] : $HTTP_GET_VARS['mode'];
	$mode = htmlspecialchars($mode);
}
else
{
	$mode = '';
}

if ( isset($HTTP_POST_VARS['user_admin']) )
{
	//
	// Default user selection box
	//
	$template->set_filenames(array(
		'body' => 'admin/user_select_body.tpl')
	);

	$template->assign_vars(array(
		'L_USER_TITLE' => $lang['Weblog_user_admin'],
		'L_USER_EXPLAIN' => $lang['Weblog_user_admin_explain'],
		'L_USER_SELECT' => $lang['Select_a_User'],
		'L_LOOK_UP' => $lang['Look_up_user'],
		'L_FIND_USERNAME' => $lang['Find_username'],

		'U_SEARCH_USER' => append_sid("./../search.$phpEx?mode=searchuser"), 

		'S_USER_ACTION' => append_sid("admin_weblog_tools.$phpEx?mode=user_admin"),
		'S_USER_SELECT' => $select_list)
	);
}
else if ( isset($HTTP_POST_VARS['weblog_admin']) )
{
	//
	// Default user selection box
	//
	$template->set_filenames(array(
		'body' => 'admin/user_select_body.tpl')
	);

	$template->assign_vars(array(
		'L_USER_TITLE' => $lang['Weblog_admin'],
		'L_USER_EXPLAIN' => $lang['Weblog_admin_explain'],
		'L_USER_SELECT' => $lang['Select_a_weblog'],
		'L_LOOK_UP' => $lang['Look_up_weblog'],

		'S_USER_ACTION' => append_sid("admin_weblog_tools.$phpEx?mode=weblog_admin"),
		'S_USER_SELECT' => $select_list)
	);
}
else if ( isset($HTTP_POST_VARS['purge']) )
{
	//
	// Find the deleted weblogs and the deleted entries
	//
	$sql = "SELECT w.*, u.user_id, u.username FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
		WHERE u.user_weblog = w.weblog_id
			AND w.deleted = 1";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not retrieve deleted weblogs information', '', __LINE__, __FILE__, $sql);
	}

	while ( $row = $db->sql_fetchrow($result) )
	{
		$del_weblogs[] = $row;

	}

	$sql = "SELECT e.*, w.*, u.user_id, u.username FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u, " . WEBLOG_ENTRIES_TABLE . " e
		WHERE u.user_weblog = w.weblog_id
			AND e.weblog_id = w.weblog_id
			AND e.entry_deleted = 1";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not retrieve deleted entries information', '', __LINE__, __FILE__, $sql);
	}

	while ( $row = $db->sql_fetchrow($result) )
	{
		$del_entries[] = $row;
	}

	if ( isset($HTTP_POST_VARS['purge_weblogs']) )
	{
		//
		// Remove all weblogs with the "deleted" flag in the database
		//
		$sql = "DELETE FROM " . WEBLOGS_TABLE . " WHERE deleted = 1";
		if ( !($result = $db->sql_query($sql, BEGIN_TRANSACTION)) )
		{
			message_die(GENERAL_ERROR, 'Could not delete "deleted" weblogs information', '', __LINE__, __FILE__, $sql);
		}

		$sql = "UPDATE " . USERS_TABLE . " u, " . WEBLOGS_TABLE . " w SET u.user_weblog = 0 WHERE w.deleted = 1 AND u.user_weblog = w.weblog_id";
		if ( !($result = $db->sql_query($sql, END_TRANSACTION)) )
		{
			message_die(GENERAL_ERROR, 'Could not update user information', '', __LINE__, __FILE__, $sql);
		}

		// That's all, Folks!
		$message = $lang['Weblogs_purged'] . "<br /><br />" . sprintf($lang['Click_return_weblog_tools'], '<a href="' . append_sid("admin_weblog_tools.$phpEx") . '">', '</a>') . "<br /><br />" . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');

		message_die(GENERAL_MESSAGE, $message);
	}
	else if ( isset($HTTP_POST_VARS['purge_entries']) )
	{
		//
		// Remove all entries with the "deleted" flag in the database
		//
		$sql = "DELETE FROM " . WEBLOG_ENTRIES_TABLE . " WHERE entry_deleted = 1";
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not delete "deleted" entries', '', __LINE__, __FILE__, $sql);
		}

		// That's all, Folks!
		$message = $lang['Entries_purged'] . "<br /><br />" . sprintf($lang['Click_return_weblog_tools'], '<a href="' . append_sid("admin_weblog_tools.$phpEx") . '">', '</a>') . "<br /><br />" . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');

		message_die(GENERAL_MESSAGE, $message);
	}
	else if ( isset($HTTP_POST_VARS['weblogs_restore']) )
	{
		$sql = '';
		for ( $i = 0; $i < count($del_weblogs); $i++ )
		{
			$weblog_id = $del_weblogs[$i]['weblog_id'];
			if ( !empty($HTTP_POST_VARS[$weblog_id]) )
			{
				$sql .= ( $sql ) ? " OR weblog_id = $weblog_id" : "UPDATE " . WEBLOGS_TABLE . " SET deleted = 0 WHERE weblog_id = $weblog_id";
			}
		}

		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Error updating weblogs information', '', __LINE__, __FILE__, $sql);
		}

		$message = $lang['Weblogs_restored'] . "<br /><br />" . sprintf($lang['Click_return_weblog_tools'], '<a href="' . append_sid("admin_weblog_tools.$phpEx") . '">', '</a>') . "<br /><br />" . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');

		message_die(GENERAL_MESSAGE, $message);
	}
	else if ( isset($HTTP_POST_VARS['entries_restore']) )
	{
		$sql = '';
		for ( $i = 0; $i < count($del_entries); $i++ )
		{
			$entry_id = $del_entries[$i]['entry_id'];
			if ( !empty($HTTP_POST_VARS[$entry_id]) )
			{
				$sql .= ( $sql ) ? " OR entry_id = $entry_id" : "UPDATE " . WEBLOG_ENTRIES_TABLE . " SET entry_deleted = 0 WHERE entry_id = $entry_id";
			}
		}

		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Error updating entry information', '', __LINE__, __FILE__, $sql);
		}

		$message = $lang['Entries_restored'] . "<br /><br />" . sprintf($lang['Click_return_weblog_tools'], '<a href="' . append_sid("admin_weblog_tools.$phpEx") . '">', '</a>') . "<br /><br />" . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');

		message_die(GENERAL_MESSAGE, $message);
	}
	else if ( isset($HTTP_POST_VARS['weblogs_purge']) )
	{
		$sql = '';
		for ( $i = 0; $i < count($del_weblogs); $i++ )
		{
			$weblog_id = $del_weblogs[$i]['weblog_id'];
			if ( !empty($HTTP_POST_VARS[$weblog_id]) )
			{
				$sql .= ( $sql ) ? " OR user_weblog = $weblog_id" : "UPDATE " . USERS_TABLE . " SET user_weblog = 0 WHERE user_weblog = $weblog_id";
			}
		}

		if ( !($result = $db->sql_query($sql, BEGIN_TRANSACTION)) )
		{
         		message_die(GENERAL_ERROR, 'Error updating user information', '', __LINE__, __FILE__, $sql);
		}

		$sql_w = '';
		$sql_e = '';	// Handling deleted entries as a result from deleted weblogs
		$sql_r = '';

		for ( $i = 0; $i < count($del_weblogs); $i++ )
		{
			$weblog_id = $del_weblogs[$i]['weblog_id'];

			if ( !empty($HTTP_POST_VARS[$weblog_id]) )
			{
				$sql_w .= ( $sql_w ) ? " OR weblog_id = $weblog_id" : "DELETE FROM " . WEBLOGS_TABLE . " WHERE weblog_id = $weblog_id";
			}

			for ( $j = 0; $j < count($del_entries); $j++ )
			{
				$entry_id = $del_entries[$j]['entry_id'];

				if ( $del_entries[$j]['weblog_id'] == $weblog_id )
				{
					$sql_e .= ( $sql_e ) ? " OR weblog_id = $weblog_id" : "DELETE FROM " . WEBLOG_ENTRIES_TABLE . " WHERE weblog_id = $weblog_id";
					$sql_r .= ( $sql_r ) ? " OR entry_id = $entry_id" : "DELETE FROM " . WEBLOG_REPLIES_TABLE . " WHERE entry_id = $entry_id";
				}
			}
		}

		if ( !($result = $db->sql_query($sql_w)) )
		{
			message_die(GENERAL_ERROR, 'Error deleting weblog information', '', __LINE__, __FILE__, $sql_w);
		}

		if ( !empty($sql_e) && !($result = $db->sql_query($sql_e)) )
		{
			message_die(GENERAL_ERROR, 'Error deleting entry information', '', __LINE__, __FILE__, $sql_e);
		}

		if ( !empty($sql_r) && !($result = $db->sql_query($sql_r, END_TRANSACTION)) )
		{
			message_die(GENERAL_ERROR, 'Error deleting entry_replies information', '', __LINE__, __FILE__, $sql_r);
		}

		$message = $lang['Weblogs_purged'] . "<br /><br />" . sprintf($lang['Click_return_weblog_tools'], '<a href="' . append_sid("admin_weblog_tools.$phpEx") . '">', '</a>') . "<br /><br />" . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');

		message_die(GENERAL_MESSAGE, $message);
	}
	else if ( isset($HTTP_POST_VARS['entries_purge']) )
	{
		$sql_e = '';
		$sql_r = '';
		for ( $i = 0; $i < count($del_entries); $i++ )
		{
			$entry_id = $del_entries[$i]['entry_id'];
			if ( !empty($HTTP_POST_VARS[$entry_id]) )
			{
				$sql_e .= ( $sql_e ) ? " OR entry_id = $entry_id" : "DELETE FROM " . WEBLOG_ENTRIES_TABLE . " WHERE entry_id = $entry_id";

				// Delete replies belonging to this entry
				$sql_r .= ( $sql_r ) ? " OR entry_id = $entry_id" : "DELETE FROM " . WEBLOG_REPLIES_TABLE . " WHERE entry_id = $entry_id";
			}
		}


		if ( !($result = $db->sql_query($sql_e, BEGIN_TRANSACTION)) )
		{
			message_die(GENERAL_ERROR, 'Error deleting entry information', '', __LINE__, __FILE__, $sql_e);
		}

		if ( !($result = $db->sql_query($sql_r, END_TRANSACTION)) )
		{
			message_die(GENERAL_ERROR, 'Error deleting entry replies information', '', __LINE__, __FILE__, $sql_r);
		}

		$message = $lang['Entries_purged'] . "<br /><br />" . sprintf($lang['Click_return_weblog_tools'], '<a href="' . append_sid("admin_weblog_tools.$phpEx") . '">', '</a>') . "<br /><br />" . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');

		message_die(GENERAL_MESSAGE, $message);
	}

	for ( $i = 0; $i < count($del_weblogs); $i++ )
	{
		$row_class = ( !($i % 2) ) ? 'row1' : 'row2';

		$template->assign_block_vars('weblogrow', array(
			'ROW_CLASS' => $row_class,
			'WEBLOG' => $del_weblogs[$i]['weblog_name'],
			'U_PROFILE' => append_sid("../profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $del_weblogs[$i]['user_id']),
			'OWNER' => $del_weblogs[$i]['username'],
			'WEBLOG_DESC' => $del_weblogs[$i]['weblog_desc'],
			'STARTED_DATE' => create_date($board_config['default_dateformat'], $del_weblogs[$i]['weblog_create_date'], $board_config['board_timezone']),
			'INPUT_NAME' => $del_weblogs[$i]['weblog_id'])
		);
	}

	for ( $i = 0; $i < count($del_entries); $i++ )
	{
		$row_class = ( !($i % 2) ) ? 'row1' : 'row2';

		$template->assign_block_vars('entryrow', array(
			'ROW_CLASS' => $row_class,
			'ENTRY' => $del_entries[$i]['entry_subject'],
			'WEBLOG' => $del_entries[$i]['weblog_name'],
			'U_PROFILE' => append_sid("../profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $del_entries[$i]['user_id']),
			'U_WEBLOG' => append_sid("../weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $del_entries[$i]['weblog_id']),
			'OWNER' => $del_entries[$i]['username'],
			'WEBLOG_DESC' => $del_entries[$i]['weblog_desc'],
			'INPUT_NAME' => $del_entries[$i]['entry_id'])
		);
	}

	//
	// Default user selection box
	//
	$template->set_filenames(array(
		'body' => 'admin/weblog_purge_body.tpl')
	);

	$template->assign_vars(array(
		'L_USER_TITLE' => $lang['Weblog_user_admin'],
		'L_USER_EXPLAIN' => $lang['Weblog_user_admin_explain'],
		'L_USER_SELECT' => $lang['Select_a_User'],
		'L_LOOK_UP' => $lang['Look_up_user'],
		'L_FIND_USERNAME' => $lang['Find_username'],

		'U_SEARCH_USER' => append_sid("./../search.$phpEx?mode=searchuser"), 

		'S_PURGE_ACTION' => append_sid("admin_weblog_tools.$phpEx?mode=purge"),

		'S_USER_SELECT' => $select_list)
	);
}
else if ( $mode == 'edit' )
{
	if ( isset($HTTP_POST_VARS['submit']) )
	{
		if ( isset($HTTP_POST_VARS['ban_user']) )
		{
			$user_allowweblog = 0;
		}
		else
		{
			$user_allowweblog = 1;
		}

		$allow_adv_weblogs = ( isset($HTTP_POST_VARS['allow_adv_weblogs']) ) ? intval($HTTP_POST_VARS['allow_adv_weblogs']) : 0;
		$user_id = ( isset($HTTP_POST_VARS['user_id']) ) ? intval($HTTP_POST_VARS['user_id']) : 0;

		$sql = "UPDATE " . USERS_TABLE . " SET user_allowweblog = $user_allowweblog, user_allowadvweblog = $allow_adv_weblogs WHERE user_id = $user_id";
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Error updating user information', '', __LINE__, __FILE__, $sql);
		}

		message_die (GENERAL_MESSAGE, 'User updated Successfully');
	}

	$username = ( isset($HTTP_POST_VARS['username']) ) ? $HTTP_POST_VARS['username'] : '';
	
	$sql = "SELECT * FROM " . USERS_TABLE . " WHERE username = '" . str_replace("\'", "''", $username) . "'";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error querying to find weblog user information', '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$weblog_user_data = $row;
	}
	else
	{
		message_die(GENERAL_MESSAGE, $lang['User_not_exist']);
	}

	$template->set_filenames(array(
		'body' => 'admin/weblog_users_body.tpl')
	);

	$template->assign_vars(array(
		'L_CONFIGURATION_TITLE' => $lang['Weblog_user_admin'],
		'L_CONFIGURATION_EXPLAIN' => $lang['Weblog_user_admin_explain'],
		'L_BAN_THIS_USER_WEBLOG' => $lang['Ban_this_user_weblog'],
		'L_ALLOW_ADV_WEBLOG' => $lang['Allow_adv_weblog'],
		'L_ALLOW_ADV_WEBLOG_EXPLAIN' => $lang['Allow_adv_weblog_explain'],

		'S_BAN_USER_CHECKED' => ( !$weblog_user_data['user_allowweblog'] ) ? ' checked="checked"' : '',

		'S_ALLOW_ADV_WEBLOGS_YES' => ( $weblog_user_data['user_allowadvweblog'] ) ? ' checked="checked"' : '',
		'S_ALLOW_ADV_WEBLOGS_NO' => ( !$weblog_user_data['user_allowadvweblog'] ) ? ' checked="checked"' : '',

		'USERNAME' => $username,

		'S_HIDDEN_FIELDS' => '<input type="hidden" name="user_id" value="' . $weblog_user_data['user_id'] . '" />',
		'S_CONFIG_ACTION' => append_sid("admin_weblog_tools.$phpEx?mode=edit"))
	);
}
else
{
	//
	// Default user selection box
	//
	$template->set_filenames(array(
		'body' => 'admin/weblog_tools_body.tpl')
	);

	$template->assign_vars(array(
		'L_PICK_A_TOOL' => $lang['Pick_a_tool'],
		'L_WEBLOG_ADMIN' => $lang['Weblog_admin'],
		'L_WEBLOG_ADMIN_EXPLAIN' => $lang['Weblog_admin_explain'],
		'L_WEBLOG_USER_ADMIN' => $lang['Weblog_user_admin'],
		'L_WEBLOG_USER_ADMIN_EXPLAIN' => $lang['Weblog_user_admin_explain'],
		'L_CONFIGURATION_TITLE' => $lang['Weblog_tools'],
		'L_CONFIGURATION_EXPLAIN' => $lang['Weblog_tools_explain'],
		'L_WEBLOG_PURGING' => $lang['Weblog_purging'],
		'L_WEBLOG_PURGING_EXPLAIN' => $lang['Weblog_purging_explain']
		)
	);

	$template->assign_vars(array(
		'S_SELECT_ACTION' => append_sid("admin_weblog_tools.$phpEx"))
	);
}

$template->assign_vars(array(
	'L_SUBMIT' => $lang['Submit'],
	'L_RESET' => $lang['Reset'],
	'L_YES' => $lang['Yes'],
	'L_NO' => $lang['No'])
);

$template->pparse('body');

include('./page_footer_admin.'.$phpEx);

?>