<?php
/***************************************************************************
 *                         admin_weblog_templates.php
 *                      --------------------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   
 *   Maintained by: TheBlogMod.com Community
 *   Support: Visit www.TheBlogMod.com
 *
 *   $Id: admin_weblog_templates.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);

//
// First we do the setmodules stuff for the admin cp.
//
if( !empty($setmodules) )
{
	$filename = basename(__FILE__);
	$module['Blog_admin']['Templates'] = $filename;

	return;
}

$phpbb_root_path = "./../";
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'language/lang_' . $use_lang . '/lang_weblog_admin.' . $phpEx);

//
// Check to see what mode we should operate in.
//
if( isset($HTTP_POST_VARS['mode']) || isset($HTTP_GET_VARS['mode']) )
{
	$mode = ( isset($HTTP_POST_VARS['mode']) ) ? $HTTP_POST_VARS['mode'] : $HTTP_GET_VARS['mode'];
}
else
{
	$mode = "";
}

if ( !file_exists($phpbb_root_path . 'weblogs/templates/') )
{
	@mkdir($phpbb_root_path . 'weblogs/templates/', 0755);
}

@chmod ($phpbb_root_path . 'weblogs/templates/', 0755);
if( $dir = @opendir($phpbb_root_path . "weblogs/templates/") )
{
	$dir_select = '<select name="template_dir" onchange="update_preview(this.form.template_dir.options[this.form.template_dir.selectedIndex].value)">';
	$selected = ($template_data['template_dir'] == $sub_dir ) ? ' selected="selected"' : '';

	while( $sub_dir = @readdir($dir) )
	{
		if ( !is_file($phpbb_root_path. "weblogs/templates/" . $sub_dir) && $sub_dir != '.' && $sub_dir != '..' )
		{
			$dir_select .= '<option value="' . $sub_dir . '"' . $selected . '>' . $sub_dir . '</option>';	
		}
	}
	$dir_select .= '</select>';
}

//
// Select main mode
//
if( isset($HTTP_POST_VARS['add']) || isset($HTTP_GET_VARS['add']) )
{

	//
	// Admin has selected to add a template.
	//

	$template->set_filenames(array(
		"body" => "admin/weblog_template_edit_body.tpl")
	);

	$template->assign_vars(array(
		"L_TEMPLATE_TITLE" => $lang['Weblog_template_title'],
		"L_TEMPLATE_CONFIG" => $lang['Weblog_template_config'],
		"L_TEMPLATE_EXPLAIN" => $lang['Weblog_template_explain'],
		"L_TEMPLATE_NAME" => $lang['Weblog_template_name'],
		"L_TEMPLATE_DIR" => $lang['Weblog_template_dir'],
		"L_TEMPLATE_PRIVATE" => $lang['Template_private'],

		"L_YES" => $lang['Yes'],
		"L_NO" => $lang['No'],

		"L_TEMPLATE_PREVIEW" => $lang['Weblog_template_preview'],
		"TEMPLATE_DIR" => $dir_select,
		"PREVIEW_IMG" => ( $template_data['template_dir'] ) ? $phpbb_root_path . 'weblogs/templates/' . $template_data['template_dir'] . '/weblog_preview.gif' : $phpbb_root_path . 'images/spacer.gif',
		"TEMPLATE_PRIVATE_CHECKED" => '',
		"TEMPLATE_NOT_PRIVATE_CHECKED" => ' checked="checked"',

		"L_SUBMIT" => $lang['Submit'],
		"L_RESET" => $lang['Reset'],

		"S_TEMPLATE_ACTION" => append_sid("admin_weblog_templates.$phpEx?mode=savenew"), 
		"S_HIDDEN_FIELDS" => $s_hidden_fields, 
		"S_FILENAME_OPTIONS" => $filename_list)
	);

	$template->pparse("body");
}
else if ( $mode != "" )
{
	switch( $mode )
	{
		case 'delete':
			//
			// Admin has selected to delete a template.
			//

			$template_id = ( !empty($HTTP_POST_VARS['id']) ) ? intval($HTTP_POST_VARS['id']) : intval($HTTP_GET_VARS['id']);

			$sql = "DELETE FROM " . WEBLOG_TEMPLATES_TABLE . "
				WHERE template_id = " . $template_id;
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't delete template", "", __LINE__, __FILE__, $sql);
			}

			//
			// Let's move all the users using that deleted style to the very first style
			//

			$sql = "SELECT MIN(template_id) AS min_id FROM " . WEBLOG_TEMPLATES_TABLE;
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't get minimum template id", "", __LINE__, __FILE__, $sql);
			}

			if ( $row = $db->sql_fetchrow($result) )
			{
				$id = $row['min_id'];
			}

			$sql = "UPDATE " . WEBLOGS_TABLE . " SET template_id = $id WHERE template_id = $template_id";
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't set users to use another template", "", __LINE__, __FILE__, $sql);
			}

			$message = $lang['Weblog_template_del_success'] . "<br /><br />" . sprintf($lang['Click_return_templateadmin'], "<a href=\"" . append_sid("admin_weblog_templates.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

			message_die(GENERAL_MESSAGE, $message);

			break;

		case 'edit':
			//
			// Admin has selected to edit a template.
			//

			$template_id = ( !empty($HTTP_POST_VARS['id']) ) ? intval($HTTP_POST_VARS['id']) : intval($HTTP_GET_VARS['id']);

			$sql = "SELECT *
				FROM " . WEBLOG_TEMPLATES_TABLE . "
				WHERE template_id = " . $template_id;
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, 'Could not obtain template information', "", __LINE__, __FILE__, $sql);
			}

			$templates_data = array();
			if ( $row = $db->sql_fetchrow($result) )
			{
				$templates_data = $row;
			}

			$template->set_filenames(array(
				"body" => "admin/weblog_template_edit_body.tpl")
			);

			$s_hidden_fields = '<input type="hidden" name="mode" value="save" /><input type="hidden" name="template_id" value="' . $template_data['template_id'] . '" />';

			$template->assign_vars(array(
				"L_TEMPLATE_TITLE" => $lang['Weblog_template_title'],
				"L_TEMPLATE_CONFIG" => $lang['Weblog_template_config'],
				"L_TEMPLATE_EXPLAIN" => $lang['Weblog_template_explain'],
				"L_TEMPLATE_NAME" => $lang['Weblog_template_name'],
				"L_TEMPLATE_PREVIEW" => $lang['Weblog_template_preview'],
				"L_TEMPLATE_DIR" => $lang['Weblog_template_dir'],
				"L_TEMPLATE_PRIVATE" => $lang['Template_private'],

				"L_YES" => $lang['Yes'],
				"L_NO" => $lang['No'],
				"L_SUBMIT" => $lang['Submit'],
				"L_RESET" => $lang['Reset'],

				"TEMPLATE_NAME" => $templates_data['template_name'],
				"TEMPLATE_DIR" => $dir_select,
				"PREVIEW_IMG" => ( $templates_data['template_dir'] ) ? $phpbb_root_path . 'weblogs/templates/' . $templates_data['template_dir'] . '/preview_img.gif' : $phpbb_root_path . 'images/spacer.gif',
				"TEMPLATE_PRIVATE_CHECKED" => ( $templates_data['template_private'] ) ? ' checked="checked"' : '',
				"TEMPLATE_NOT_PRIVATE_CHECKED" => ( !$templates_data['template_private'] ) ? ' checked="checked"' : '',

				"S_TEMPLATE_ACTION" => append_sid("admin_weblog_templates.$phpEx?mode=edit&amp;id=$template_id"),
				"S_HIDDEN_FIELDS" => $s_hidden_fields, 
				"S_FILENAME_OPTIONS" => $filename_list)
			);

			$template->pparse("body");

			break;

		case "save":
			//
			// Admin has submitted changes while editing a template.
			//

			$template_id = ( !empty($HTTP_POST_VARS['id']) ) ? intval($HTTP_POST_VARS['id']) : intval($HTTP_GET_VARS['id']);

			//
			// Get the submitted data, being careful to ensure that we only
			// accept the data we are looking for.
			//
			$template_name = ( isset($HTTP_POST_VARS['template_name']) ) ? trim($HTTP_POST_VARS['template_name']) : trim($HTTP_GET_VARS['template_name']);
			$template_dir = ( isset($HTTP_POST_VARS['template_dir']) ) ? trim($HTTP_POST_VARS['template_dir']) : trim($HTTP_GET_VARS['template_dir']);
			$template_private = ( isset($HTTP_POST_VARS['private_template']) ) ? intval($HTTP_POST_VARS['private_template']) : intval($HTTP_GET_VARS['private_template']);


			// If no code was entered complain ...
			if ( $template_name == '' )
			{
				message_die(MESSAGE, $lang['Fields_empty']);
			}

			//
			// Proceed with updating the templates table.
			//
			$sql = "UPDATE " . WEBLOG_TEMPLATES_TABLE . "
				SET template_name = '" . str_replace("\'", "''", $template_name) . "', template_dir = '" . str_replace("\'", "''", $template_dir) . "', template_private = $template_private
				WHERE template_id = $template_id";
			if( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, "Couldn't update template info", "", __LINE__, __FILE__, $sql);
			}

			$message = $lang['Weblog_template_edit_success'] . "<br /><br />" . sprintf($lang['Click_return_templateadmin'], "<a href=\"" . append_sid("admin_weblog_templates.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

			message_die(GENERAL_MESSAGE, $message);

			break;

		case "savenew":
			//
			// Admin has submitted changes while adding a new template
			//

			//
			// Get the submitted data being careful to ensure the the data
			// we recieve and process is only the data we are looking for.
			//
			$template_name = ( isset($HTTP_POST_VARS['template_name']) ) ? trim($HTTP_POST_VARS['template_name']) : trim($HTTP_GET_VARS['template_name']);
			$template_dir = ( isset($HTTP_POST_VARS['template_dir']) ) ? trim($HTTP_POST_VARS['template_dir']) : trim($HTTP_GET_VARS['template_dir']);
			$template_private = ( isset($HTTP_POST_VARS['private_template']) ) ? intval($HTTP_POST_VARS['private_template']) : intval($HTTP_GET_VARS['private_template']);

			// If no code was entered complain ...
			if ( !$template_name )
			{
				message_die(GENERAL_ERROR, $lang['Fields_empty']);
			}

			//
			// Verify the template directory exists and can be read
			//

			// Chmod so we'll have no problems
			@chmod($phpbb_root_path . 'weblogs/templates/' . $template_dir, 0755);
			@chmod($phpbb_root_path . 'weblogs/templates/' . $template_dir . '/' . $template_dir . '.cfg', 0755);

			if ( !file_exists($phpbb_root_path . 'weblogs/templates/' . $template_dir . '/' . $template_dir . '.cfg') )
			{
				message_die(GENERAL_ERROR, $lang['Template_missing']);
			}

			//
			// Get max template id
			//
			$sql = "SELECT MAX(template_id) AS maximum FROM " . WEBLOG_TEMPLATES_TABLE;
			if( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, "Couldn't get maximum template id", "", __LINE__, __FILE__, $sql);
			}

			if ( $row = $db->sql_fetchrow($result) )
			{
				$next_id = $row['maximum'] + 1;
			}

			//
			// Save the data to the weblog templates table.
			//
			$sql = "INSERT INTO " . WEBLOG_TEMPLATES_TABLE . " (template_id, template_name, template_dir, template_private)
				VALUES ($next_id, '" . str_replace("\'", "''", $template_name) . "', '" . str_replace("\'", "''", $template_dir) . "', $template_private)";
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't insert new template", "", __LINE__, __FILE__, $sql);
			}

			$message = $lang['Weblog_template_add_success'] . "<br /><br />" . sprintf($lang['Click_return_templateadmin'], "<a href=\"" . append_sid("admin_weblog_templates.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

			message_die(GENERAL_MESSAGE, $message);

			break;
	}
}
else
{

	//
	// This is the main display of the page before the admin has selected
	// any options.
	//
	$template->set_filenames(array(
		"body" => "admin/weblog_template_list_body.tpl")
	);

	$template->assign_vars(array(
		"L_ACTION" => $lang['Action'],
		"L_TEMPLATE_TITLE" => $lang['Weblog_template_title'],
		"L_TEMPLATE_TEXT" => $lang['Weblog_template_explain'],
		"L_DELETE" => $lang['Delete'],
		"L_EDIT" => $lang['Edit'],
		"L_TEMPLATE_ADD" => $lang['Weblog_template_add'],
		"L_TEMPLATE_NAME" => $lang['Weblog_template'],
		"L_PREVIEW_IMAGE" => $lang['Preview_image'],
		"L_PRIVATE" => $lang['Template_private'],

		"S_HIDDEN_FIELDS" => $s_hidden_fields, 
		"S_TEMPLATE_ACTION" => append_sid("admin_weblog_templates.$phpEx"))
	);

	//
	// Loop throuh the rows of templates setting block vars for the template.
	//
	for($i = 0; $i < count($template_data); $i++)
	{
		$row_color = ( !($i % 2) ) ? $theme['td_color1'] : $theme['td_color2'];
		$row_class = ( !($i % 2) ) ? $theme['td_class1'] : $theme['td_class2'];

		$template->assign_block_vars('template_row', array(
			"ROW_COLOR" => "#" . $row_color,
			"ROW_CLASS" => $row_class,
			
			"TEMPLATE" => $template_data[$i]['template_name'],
			"TEMPLATE_IMAGE" => '<img src="' . $phpbb_root_path . 'weblogs/templates/' . $template_data[$i]['template_dir'] . '/preview_img.gif" border="0">',
			"TEMPLATE_PRIVATE" => ( $template_data[$i]['template_private'] ) ? $lang['Yes'] : $lang['No'],
			"U_TEMPLATE_EDIT" => append_sid("admin_weblog_templates.$phpEx?mode=edit&amp;id=" . $template_data[$i]['template_id']), 
			"U_TEMPLATE_DELETE" => append_sid("admin_weblog_templates.$phpEx?mode=delete&amp;id=" . $template_data[$i]['template_id']))
		);
	}

	//
	// Spit out the page.
	//
	$template->pparse("body");
}

//
// Page Footer
//
include('./page_footer_admin.'.$phpEx);

?>
