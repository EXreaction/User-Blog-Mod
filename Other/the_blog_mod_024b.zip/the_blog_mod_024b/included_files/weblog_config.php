<?php
/***************************************************************************
 *                            weblog_config.php
 *                         -----------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   
 *   Maintained by: TheBlogMod.com Community
 *   Support: Visit www.TheBlogMod.com
 *
 *   $Id: weblog_config.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_post.'.$phpEx);
include($phpbb_root_path . 'includes/bbcode.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

//
// Include the Header
//
$page_title = $lang['Weblog_CP'];
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

// Check to see if the user is allowed to have a weblog.
if ( !$userdata['session_logged_in'] )
{
	message_die (GENERAL_MESSAGE, $lang['No_weblog_guests']);
}

if ( !$userdata['user_allowweblog'] )
{
	message_die (GENERAL_MESSAGE, $lang['Weblog_banned']);
}

//
// Do not check if the user already has a weblog
//
if ( !$userdata['user_weblog'] && $weblog_config['require_auth'] )
{
	//
	// See if this user belongs in a group that allows weblogs
	//
	$sql = "SELECT g.* FROM " . GROUPS_TABLE . " g, " . USER_GROUP_TABLE . " ug
			WHERE ug.user_id = " . $userdata['user_id'] . "
				AND ug.group_id = g.group_id
				AND g.group_allow_weblogs = " . TRUE . "
				AND ug.user_pending <> " . TRUE;
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error querying to find user group information', '', __LINE__, __FILE__, $sql);
	}

	if ( !$row = $db->sql_fetchrow($result) )
	{
		message_die (GENERAL_MESSAGE, $lang['Weblog_require_auth']);
	}
}

if ( $userdata['user_allowadvweblog'] )
{
	$template->assign_block_vars('switch_approved', array());
}

//
// Fetch weblog data
//
$sql = "SELECT * FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u WHERE w.weblog_id = u.user_weblog AND u.user_id = " . $userdata['user_id'];
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

if ( $row = $db->sql_fetchrow($result) )
{
	$weblog_exists = TRUE;
	$weblog_data = $row;

	if ( $weblog_data['weblog_advanced'] )
	{
		$template->assign_block_vars('switch_edit_adv_weblog', array());
	}
	else
	{
		$template->assign_block_vars('switch_edit_easy_weblog', array());
	}

	$template->assign_block_vars('switch_edit_weblog', array());

	if ( $weblog_data['deleted'] )
	{
		$template->assign_block_vars('switch_marked_deletion', array());
	}
}
else if ( $weblog_id )
{
	message_die(GENERAL_MESSAGE, 'Weblog_not_exist');
}
else
{
	$template->assign_block_vars('switch_create_weblog', array());
}

if ( !($weblog_data['weblog_id'] == $userdata['user_weblog']) && $weblog_id )
{
	message_die(GENERAL_ERROR, $lang['Weblog_noaccess']);
}
//
// See if there is a template available for weblog users
//
$sql = "SELECT * FROM " . WEBLOG_TEMPLATES_TABLE . "
		WHERE template_private <> 1
			OR template_id = " . intval($weblog_data['template_id']);
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't get weblog template information.", "", __LINE__, __FILE__, $sql);
}
	
if ( !($row = $db->sql_fetchrow($result)) )
{
	message_die(GENERAL_ERROR, $lang['Weblog_no_templates']);
}


$template->set_filenames(array(
	"body" => "weblog_cp_body.tpl")
);

// Set initial vars
$weblog_id = $weblog_data['weblog_id'];
$weblog_advanced = $weblog_data['weblog_advanced'];


//
// Load the default look and feel
//
if ( !$weblog_exists )
{
	$template_dir = get_template_dir ( $template_data[0]['template_id'] );

	if ( @file_exists($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") )
	{
		include($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg");
	}
	else
	{
		message_die (GENERAL_ERROR, sprintf($lang['No_read_file'], $phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") );
	}
}
else
{
	$template_dir = get_template_dir ( $weblog_data['template_id'] );

	if ( @file_exists($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") )
	{
		include($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg");
	}
	else
	{
		message_die (GENERAL_ERROR, sprintf($lang['No_read_file'], $phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") );
	}

	if ( $customizable == 'yes' || $customizable == 'partly' )
	{
		$template->assign_block_vars('switch_customization', array());

		if ( $customizable == 'partly' )
		{
			$template->assign_vars(array(
				'CUSTOMIZABLE' => $lang['Partly_customizable_only'])
			);
		}
		else
		{
			$template->assign_vars(array(
				'CUSTOMIZABLE' => $lang['Fully_customizable'])
			);
		}
	}
	else
	{
		$template->assign_vars(array(
			'CUSTOMIZABLE' => $lang['Not_customizable'])
		);
	}

}

$sql = "SELECT *
	FROM " . WEBLOG_MOOD_SETS_TABLE . "
	ORDER BY set_id";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain mood set data from database", "", __LINE__, __FILE__, $sql);
}
$mood_set_data = $db->sql_fetchrowset($result);


//
// Deal with form submissions
//
if ( isset ($HTTP_POST_VARS['create']) || isset ($HTTP_POST_VARS['edit']) || isset ($HTTP_POST_VARS['delete']) || isset ($HTTP_POST_VARS['undelete']) )
{
	if ( isset($HTTP_POST_VARS['create']) || isset ($HTTP_POST_VARS['edit']) )
	{
		$weblog_name = 		( isset($HTTP_POST_VARS['weblog_name']) ) 		? trim(htmlspecialchars($HTTP_POST_VARS['weblog_name'])) 		: '';
		$weblog_desc = 		( isset($HTTP_POST_VARS['weblog_desc']) ) 		? trim(htmlspecialchars($HTTP_POST_VARS['weblog_desc'])) 		: $weblog_data['weblog_desc'];
		$replies_label = 		( isset($HTTP_POST_VARS['replies_label']) ) 		? trim(htmlspecialchars($HTTP_POST_VARS['replies_label'])) 		: $weblog_data['replies_text'];
		$post_reply_label = 	( isset($HTTP_POST_VARS['post_reply_label']) ) 		? trim(htmlspecialchars($HTTP_POST_VARS['post_reply_label']))	: $weblog_data['post_reply_text'];
		$weblog_template = 	( isset($HTTP_POST_VARS['template_select']) ) 		? trim(htmlspecialchars($HTTP_POST_VARS['template_select']))	: -1;
		$weblog_auth = 		( isset($HTTP_POST_VARS['weblog_auth_select']) ) 	? intval($HTTP_POST_VARS['weblog_auth_select']) : $weblog_config['default_auth'];
		$reply_auth = 		( isset($HTTP_POST_VARS['replies_auth_select']) ) 	? intval($HTTP_POST_VARS['replies_auth_select']): $weblog_config['default_reply_auth'];
		$num_entries = 		( isset($HTTP_POST_VARS['num_entries']) ) 		? intval($HTTP_POST_VARS['num_entries']) 		: $weblog_config['default_entries_perpage'];
		$show_profile_info =	( isset($HTTP_POST_VARS['show_profile_info']) )		? intval($HTTP_POST_VARS['show_profile_info']) 	: 1;
		$show_calendar = 		( isset($HTTP_POST_VARS['show_calendar']) ) 		? intval($HTTP_POST_VARS['show_calendar']) 	: 1;
		$show_contact_info =	( isset($HTTP_POST_VARS['show_contact_info']) )		? intval($HTTP_POST_VARS['show_contact_info']) 	: 1;
		$show_weblog_info = 	( isset($HTTP_POST_VARS['show_weblog_info']) ) 		? intval($HTTP_POST_VARS['show_weblog_info']) 	: 1;
		$show_shoutbox = 		( isset($HTTP_POST_VARS['show_shoutbox']) ) 		? intval($HTTP_POST_VARS['show_shoutbox']) 	: 1;
		$reply_in_popup = 	( isset($HTTP_POST_VARS['reply_in_popup']) ) 		? intval($HTTP_POST_VARS['reply_in_popup']) 	: 1;
		$shoutbox_desc = 		( isset($HTTP_POST_VARS['shoutbox_desc']) ) 		? intval($HTTP_POST_VARS['shoutbox_desc']) 	: 1;
		$weblog_mood_set = 	( isset($HTTP_POST_VARS['mood_set_select']) ) 		? intval($HTTP_POST_VARS['mood_set_select']) 	: $mood_set_data[0]['set_id'];
		$weblog_action =		( isset($HTTP_POST_VARS['weblog_action']) )		? intval($HTTP_POST_VARS['weblog_action'])	: ACTION_DO_NOTHING;
		$weblog_face = 		( isset($HTTP_POST_VARS['weblog_face']) 			&& $userdata['user_allowadvweblog'] ) 		? trim($HTTP_POST_VARS['weblog_face']) 		: '';
		$weblog_page = 		( isset($HTTP_POST_VARS['weblog_page']) 			&& $userdata['user_allowadvweblog'] ) 		? trim($HTTP_POST_VARS['weblog_page']) 		: '';
		$reset_counter = 		( isset($HTTP_POST_VARS['reset_counter']) && !empty($HTTP_POST_VARS['reset_counter']) ) ? 1 		: 0;

		// Look and Feel
		$background_color = ( isset($HTTP_POST_VARS['background_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['background_color'])) : $background_color;
		$entry_bg_color = ( isset($HTTP_POST_VARS['entry_bg_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['entry_bg_color'])) : $entry_bg_color;
		$border_color = ( isset($HTTP_POST_VARS['border_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['border_color'])) : $border_color;
		$background_image = ( isset($HTTP_POST_VARS['background_image']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['background_image'])) : substr($background_image, 4, (strlen($background_image) - 5));
		$background_image_fixed = ( isset($HTTP_POST_VARS['background_image']) ) ? ( (isset($HTTP_POST_VARS['background_image_fixed'])) ? '1' : '0') : (( $background_image_fixed == 'fixed' ) ? 1 : 0);
		$tile_bg = ( isset($HTTP_POST_VARS['tile_bg']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['tile_bg'])) : $tile_bg;
		$bg_ypos = ( isset($HTTP_POST_VARS['bg_ypos']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['bg_ypos'])) : $bg_ypos;
		$bg_xpos = ( isset($HTTP_POST_VARS['bg_xpos']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['bg_xpos'])) : $bg_xpos;
		$sb_face_color = ( isset($HTTP_POST_VARS['sb_face_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['sb_face_color'])) : $sb_face_color;
		$sb_highlight_color = ( isset($HTTP_POST_VARS['sb_highlight_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['sb_highlight_color'])) : $sb_highlight_color;
		$sb_shadow_color = ( isset($HTTP_POST_VARS['sb_shadow_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['sb_shadow_color'])) : $sb_shadow_color;
		$sb_3dlight_color = ( isset($HTTP_POST_VARS['sb_3dlight_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['sb_3dlight_color'])) : $sb_3dlight_color;
		$sb_arrow_color = ( isset($HTTP_POST_VARS['sb_arrow_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['sb_arrow_color'])) : $sb_arrow_color;
		$sb_track_color = ( isset($HTTP_POST_VARS['sb_track_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['sb_track_color'])) : $sb_track_color;
		$sb_darkshadow_color = ( isset($HTTP_POST_VARS['sb_darkshadow_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['sb_darkshadow_color'])) : $sb_darkshadow_color;
		$font = ( isset($HTTP_POST_VARS['font']) ) ? intval($HTTP_POST_VARS['font']) : trim(htmlspecialchars($font));
		$font_color = ( isset($HTTP_POST_VARS['font_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['font_color'])) : $font_color;
		$font_size = ( isset($HTTP_POST_VARS['font_size']) ) ? intval($HTTP_POST_VARS['font_size']) : $font_size;
		$normal_link_color = ( isset($HTTP_POST_VARS['normal_link_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['normal_link_color'])) : $normal_link_color;


		$normal_link_underline = ( isset($HTTP_POST_VARS['normal_link_color']) ) ? ( (isset($HTTP_POST_VARS['normal_link_underline'])) ? 1 : 0) : (( $normal_link_underline == 'underline' ) ? 1 : 0);
		$active_link_underline =	( isset($HTTP_POST_VARS['active_link_color']) )		? ( (isset($HTTP_POST_VARS['active_link_underline'])) ? 1 : 0) : (( $active_link_underline == 'underline' ) ? 1 : 0);
		$hover_link_underline =		( isset($HTTP_POST_VARS['hover_link_color']) )		? ( (isset($HTTP_POST_VARS['hover_link_underline'])) ? 1 : 0)	: (( $hover_link_underline == 'underline' ) ? 1 : 0);
		$visited_link_underline =	( isset($HTTP_POST_VARS['visited_link_color']) )	? ( (isset($HTTP_POST_VARS['visited_link_underline'])) ? 1 : 0) : (( $visited_link_underline == 'underline' ) ? 1 : 0);
		$active_link_color = ( isset($HTTP_POST_VARS['active_link_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['active_link_color'])) : $active_link_color;
		$hover_link_color = ( isset($HTTP_POST_VARS['hover_link_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['hover_link_color'])) : $hover_link_color;
		$visited_link_color = ( isset($HTTP_POST_VARS['visited_link_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['visited_link_color'])) : $visited_link_color;
		$weblog_title_color = ( isset($HTTP_POST_VARS['weblog_title_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['weblog_title_color'])) : $weblog_title_color;
		$weblog_title_font_size = ( isset($HTTP_POST_VARS['weblog_title_font_size']) ) ? intval($HTTP_POST_VARS['weblog_title_font_size']) : $weblog_title_font_size;
		$date_time_color = ( isset($HTTP_POST_VARS['date_time_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['date_time_color'])) : $date_time_color;
		$date_time_font_size = ( isset($HTTP_POST_VARS['date_time_font_size']) ) ? intval($HTTP_POST_VARS['date_time_font_size']) : $date_time_font_size;
		$entry_title_color = ( isset($HTTP_POST_VARS['entry_title_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['entry_title_color'])) : $entry_title_color;
		$entry_title_font_size = ( isset($HTTP_POST_VARS['entry_title_font_size']) ) ? intval($HTTP_POST_VARS['entry_title_font_size']) : $entry_title_font_size;
		$block_title_color = ( isset($HTTP_POST_VARS['block_title_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['block_title_color'])) : $block_title_color;
		$block_title_font_size = ( isset($HTTP_POST_VARS['block_title_font_size']) ) ? intval($HTTP_POST_VARS['block_title_font_size']) : $block_title_font_size;
		$block_bg_color = ( isset($HTTP_POST_VARS['block_bg_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['block_bg_color'])) : $block_bg_color;
		$block_border_color = ( isset($HTTP_POST_VARS['block_border_color']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['block_border_color'])) : $block_border_color;
		$custom_block_title = ( isset($HTTP_POST_VARS['custom_block_title']) ) ? trim(htmlspecialchars($HTTP_POST_VARS['custom_block_title'])) : $custom_block_title;
		$custom_block = ( isset($HTTP_POST_VARS['custom_block']) ) ? trim($HTTP_POST_VARS['custom_block']) : $custom_block;

		$template_dir = get_template_dir ( $weblog_template );

		//
		// Stripslashes the weblog page and the face plate (going straight to file and not to db so the automatic slashes must be removed)
		//
		$weblog_face = stripslashes ($weblog_face);
		$weblog_page = stripslashes ($weblog_page);

		if ( !empty($custom_block) )
		{
			$bbcode_uid = make_bbcode_uid();
			$custom_block = prepare_message(trim($custom_block), true, true, true, $bbcode_uid);
		}

		if ( isset($HTTP_POST_VARS['create']) )
		{
			if ( $weblog_exists )
			{
				message_die(GENERAL_ERROR, $lang['No_second_weblog']);
			}
		}

		if ( $background_image != '' )
		{
			rawurlencode($background_image);
			$background_image = "url($background_image)";
		}

		$error_msg = '';

		for ( $i = 0; $i < count($template_data); $i++)
		{
			if ( $template_data[$i]['template_name'] == $weblog_template )
			{
				$weblog_template = $template_data[$i]['template_id'];
				break;
			}
		}

		if ( empty($weblog_name) )
		{
			$error_msg = '<br /><br />' . $lang['No_weblog_name'];
		}

		if ( empty($weblog_desc) )
		{
			$error_msg .= '<br /><br />' . $lang['No_weblog_desc'];
		}

		if ( empty($replies_label) )
		{
			$error_msg .= '<br /><br />' . $lang['No_replies_label'];
		}

		if ( empty($post_reply_label) )
		{
			$error_msg .= '<br /><br />' . $lang['No_post_reply_label'];
		}

		if ( !$num_entries || $num_entries <= 0 )
		{
			$error_msg .= '<br /><br />' . $lang['Bad_num_entries'];
		}

		if ( !empty($error_msg) )
		{
			message_die (GENERAL_ERROR, $lang['Errors_occured'] . $error_msg);
		}

		$template_dir = get_template_dir ($weblog_template);

		if ( isset($HTTP_POST_VARS['create']) )
		{

			if ( @file_exists($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") )
			{
				include($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg");
			}
			else
			{
				message_die (GENERAL_ERROR, sprintf($lang['No_read_file'], $phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") );
			}

			// Check all fields
			$normal_link_underline = ( $normal_link_underline == 'underline' ) ? 1 : 0;
			$active_link_underline = ( $active_link_underline == 'underline' ) ? 1 : 0;
			$hover_link_underline = ( $hover_link_underline == 'underline' ) ? 1 : 0;
			$visited_link_underline = ( $visited_link_underline == 'underline' ) ? 1 : 0;
			$background_image_fixed = ( $background_image_fixed == 'fixed' ) ? 1 : 0;

			if ( !is_integer($font) )
			{
				$font = 0;
				for ( $i = 0; $i < NUM_WEBLOG_FONTS; $i++ )
				{
					if ( $weblog_fonts[$i] == $font )
					{
						$font = $i;
						break;
					}
				}
			}

			// Get the maximum weblog_id
			$sql = "SELECT MAX(weblog_id) AS max_id FROM " . WEBLOGS_TABLE;
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Error selecting max weblog id.', '', __LINE__, __FILE__, $sql);
			}

			$maximum = 0;
			if ( $row = $db->sql_fetchrow($result) )
			{
				$maximum = $row['max_id'];
			}

			// Everything else okay? Then create the weblog
			$sql = "INSERT INTO " . WEBLOGS_TABLE . " (
				weblog_id,
				template_id,
				weblog_name,
				weblog_desc,
				weblog_auth,
				replies_auth,
				entries_perpage,
				post_reply_text,
				replies_text,
				weblog_create_date,
				mood_set,
				background_color,
				entry_bg_color,
				border_color,
				background_image,
				background_image_fixed,
				tile_bg,
				bg_ypos,
				bg_xpos,
				sb_face_color,
				sb_highlight_color,
				sb_shadow_color,
				sb_3dlight_color,
				sb_arrow_color,
				sb_track_color,
				sb_darkshadow_color,
				font,
				font_color,
				font_size,
				normal_link_color,
				normal_link_underline,
				active_link_color,
				active_link_underline,
				hover_link_color,
				hover_link_underline,
				visited_link_color,
				visited_link_underline,
				weblog_title_color,
				weblog_title_font_size,
				entry_title_color,
				entry_title_font_size,
				date_time_color,
				date_time_font_size,
				block_title_color,
				block_title_font_size,
				block_bg_color,
				block_border_color,
				custom_block_title,
				custom_block,
				cblock_bbcode_uid,
				show_profile_info,
				show_calendar,
				show_contact_info,
				show_weblog_info,
				show_shoutbox,
				reply_in_popup,
				weblog_shoutbox_desc)

				VALUES (
				($maximum+1),
				$weblog_template,
				'" . str_replace("\'", "''", $weblog_name) . "',
				'" . str_replace("\'", "''", $weblog_desc) . "',
				$weblog_auth,
				$reply_auth,
				$num_entries,
				'" . str_replace("\'", "''", $post_reply_label) . "',
				'" . str_replace("\'", "''", $replies_label) . "',
				" . time() . ",
				$weblog_mood_set,
				'" . str_replace("\'", "''", $background_color) . "',
				'" . str_replace("\'", "''", $entry_bg_color) . "',
				'" . str_replace("\'", "''", $border_color) . "',
				'" . str_replace("\'", "''", $background_image) . "',
				$background_image_fixed,
				'" . str_replace("\'", "''", $tile_bg) . "',
				'" . str_replace("\'", "''", $bg_ypos) . "',
				'" . str_replace("\'", "''", $bg_xpos) . "',
				'" . str_replace("\'", "''", $sb_face_color) . "',
				'" . str_replace("\'", "''", $sb_highlight_color) . "',
				'" . str_replace("\'", "''", $sb_shadow_color) . "',
				'" . str_replace("\'", "''", $sb_3dlight_color) . "',
				'" . str_replace("\'", "''", $sb_arrow_color) . "',
				'" . str_replace("\'", "''", $sb_track_color) . "',
				'" . str_replace("\'", "''", $sb_darkshadow_color) . "',
				$font,
				'" . str_replace("\'", "''", $font_color) . "',
				$font_size,
				'" . str_replace("\'", "''", $normal_link_color) . "',
				$normal_link_underline,
				'" . str_replace("\'", "''", $active_link_color) . "',
				$active_link_underline,
				'" . str_replace("\'", "''", $hover_link_color) . "',
				$hover_link_underline,
				'" . str_replace("\'", "''", $visited_link_color) . "',
				$visited_link_underline,
				'" . str_replace("\'", "''", $weblog_title_color) . "',
				$weblog_title_font_size,
				'" . str_replace("\'", "''", $entry_title_color) . "',
				$entry_title_font_size,
				'" . str_replace("\'", "''", $date_time_color) . "',
				$date_time_font_size,
				'" . str_replace("\'", "''", $block_title_color) . "',
				$block_title_font_size,
				'" . str_replace("\'", "''", $block_bg_color) . "',
				'" . str_replace("\'", "''", $block_border_color) . "',
				'" . str_replace("\'", "''", $custom_block_title) . "',
				'" . str_replace("\'", "''", $custom_block) . "',
				'$bbcode_uid',
				$show_profile_info,
				$show_calendar,
				$show_contact_info,
				$show_weblog_info,
				$show_shoutbox,
				$reply_in_popup,
				$shoutbox_desc)";
			if ( !($result = $db->sql_query($sql, BEGIN_TRANSACTION)) )
			{
				message_die(GENERAL_ERROR, 'Error creating a weblog.', '', __LINE__, __FILE__, $sql);
			}

			// Update the user's data
			$sql = "UPDATE " . USERS_TABLE . " SET user_weblog = " . ($maximum+1) . " WHERE user_id = " . $userdata['user_id'];
			if ( !($result = $db->sql_query($sql, END_TRANSACTION)) )
			{
				message_die(GENERAL_ERROR, 'Error creating a weblog.', '', __LINE__, __FILE__, $sql);
			}

			$template->assign_vars(array(
				'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . ($maximum+1)) . '">')
			);

			$message = sprintf($lang['Weblog_created'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . ($maximum+1)) . '">', '</a>', '<a href="' . append_sid("weblog_config.$phpEx") . '">', '</a>');
		}
		else
		{
			if ( ($weblog_action == ACTION_LOAD_TEMPLATE && $weblog_data['weblog_advanced'] && $userdata['user_allowadvweblog']) || ( $weblog_action == ACTION_SWITCH_MODE && !$weblog_data['weblog_advanced'] && $userdata['user_allowadvweblog'] ) )
			{
				if ( @file_exists($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") )
				{
					include($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg");
				}
				else
				{
					message_die (GENERAL_ERROR, sprintf($lang['No_read_file'], $phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") );
				}

				$normal_link_underline = ( $normal_link_underline == 'underline' ) ? 1 : 0;
				$active_link_underline = ( $active_link_underline == 'underline' ) ? 1 : 0;
				$hover_link_underline = ( $hover_link_underline == 'underline' ) ? 1 : 0;
				$visited_link_underline = ( $visited_link_underline == 'underline' ) ? 1 : 0;
				$background_image_fixed = ( $background_image_fixed == 'fixed' ) ? 1 : 0;

				load_template ( $template_dir, $weblog_data['weblog_id'] );

				$weblog_advanced = 1;
			}
			else if ( $weblog_action == ACTION_DO_NOTHING && $weblog_data['weblog_advanced'] && $userdata['user_allowadvweblog'] )
			{
				save_template ( $weblog_page, $weblog_face, $weblog_data['weblog_id'] );

				$weblog_template = $weblog_data['template_id'];
				$weblog_advanced = 1;
			}
			else if ( $weblog_action == ACTION_DO_NOTHING && !$weblog_data['weblog_advanced'] )
			{
				$weblog_template = $weblog_data['template_id'];
				$weblog_advanced = 0;
			}
			else if ( ($weblog_action == ACTION_LOAD_TEMPLATE && !$weblog_data['weblog_advanced']) || ($weblog_action == ACTION_SWITCH_MODE && $weblog_data['weblog_advanced']) )
			{
				if ( @file_exists($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") )
				{
					include($phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg");
				}
				else
				{
					message_die (GENERAL_ERROR, sprintf($lang['No_read_file'], $phpbb_root_path . "weblogs/templates/$template_dir/$template_dir.cfg") );
				}

				$normal_link_underline = ( $normal_link_underline == 'underline' ) ? 1 : 0;
				$active_link_underline = ( $active_link_underline == 'underline' ) ? 1 : 0;
				$hover_link_underline = ( $hover_link_underline == 'underline' ) ? 1 : 0;
				$visited_link_underline = ( $visited_link_underline == 'underline' ) ? 1 : 0;
				$background_image_fixed = ( $background_image_fixed == 'fixed' ) ? 1 : 0;

				$weblog_advanced = 0;
			}
			else if ( $weblog_action == ACTION_SWITCH_MODE && !$weblog_data['weblog_advanced'] && !$userdata['user_allowadvweblog'] )
			{
				message_die (GENERAL_ERROR, $lang['Weblog_no_adv_weblog']);
			}


			// Check all fields
			if ( !is_integer($font) )
			{
				$font = 0;
				for ( $i = 0; $i < NUM_WEBLOG_FONTS; $i++ )
				{
					if ( $weblog_fonts[$i] == $font )
					{
						$font = $i;
						break;
					}
				}
			}

			if ( $reset_counter )
			{
				$reset_counter = 'weblog_views = 0,';
			}
			else
			{
				$reset_counter = '';
			}

			//
			// Update the existing weblog
			$sql = "UPDATE " . WEBLOGS_TABLE . " SET
					template_id = 			$weblog_template,
					weblog_name = 			'" . str_replace("\'", "''", $weblog_name) . "', 
					weblog_desc = 			'" . str_replace("\'", "''", $weblog_desc) . "',
					weblog_auth = 			$weblog_auth,
					replies_auth = 			$reply_auth,
					entries_perpage = 		$num_entries,
					post_reply_text = 		'" . str_replace("\'", "''", $post_reply_label) . "',
					replies_text = 			'" . str_replace("\'", "''", $replies_label) . "',
					weblog_advanced = 		$weblog_advanced,
					mood_set = 				$weblog_mood_set,
					$reset_counter
					background_color = 		'" . str_replace("\'", "''", $background_color) . "',
					entry_bg_color = 			'" . str_replace("\'", "''", $entry_bg_color) . "',
					border_color = 			'" . str_replace("\'", "''", $border_color) . "',
					background_image = 		'" . str_replace("\'", "''", $background_image) . "',
					background_image_fixed = 	$background_image_fixed,
					tile_bg = 				'" . str_replace("\'", "''", $tile_bg) . "',
					bg_ypos = 				'" . str_replace("\'", "''", $bg_ypos) . "',
					bg_xpos = 				'" . str_replace("\'", "''", $bg_xpos) . "',
					sb_face_color = 			'" . str_replace("\'", "''", $sb_face_color) . "',
					sb_highlight_color = 		'" . str_replace("\'", "''", $sb_highlight_color) . "',
					sb_shadow_color = 		'" . str_replace("\'", "''", $sb_shadow_color) . "',
					sb_3dlight_color = 		'" . str_replace("\'", "''", $sb_3dlight_color) . "',
					sb_arrow_color = 			'" . str_replace("\'", "''", $sb_arrow_color) . "',
					sb_track_color = 			'" . str_replace("\'", "''", $sb_track_color) . "',
					sb_darkshadow_color = 		'" . str_replace("\'", "''", $sb_darkshadow_color) . "',
					font = 				$font,
					font_color = 			'" . str_replace("\'", "''", $font_color) . "',
					font_size = 			$font_size,
					normal_link_color = 		'" . str_replace("\'", "''", $normal_link_color) . "',
					normal_link_underline = 	$normal_link_underline,
					active_link_color = 		'" . str_replace("\'", "''", $active_link_color) . "',
					active_link_underline = 	$active_link_underline,
					hover_link_color = 		'" . str_replace("\'", "''", $hover_link_color) . "',
					hover_link_underline = 		$hover_link_underline,
					visited_link_color = 		'" . str_replace("\'", "''", $visited_link_color) . "',
					visited_link_underline = 	$visited_link_underline,
					weblog_title_color = 		'" . str_replace("\'", "''", $weblog_title_color) . "',
					weblog_title_font_size = 	$weblog_title_font_size,
					entry_title_color = 		'" . str_replace("\'", "''", $entry_title_color) . "',
					entry_title_font_size = 	$entry_title_font_size,
					date_time_color = 		'" . str_replace("\'", "''", $date_time_color) . "',
					date_time_font_size = 		$date_time_font_size,
					block_title_color = 		'" . str_replace("\'", "''", $block_title_color) . "',
					block_title_font_size = 	$block_title_font_size,
					block_bg_color = 			'" . str_replace("\'", "''", $block_bg_color) . "',
					block_border_color = 		'" . str_replace("\'", "''", $block_border_color) . "',
					custom_block_title = 		'" . str_replace("\'", "''", $custom_block_title) . "',
					custom_block = 			'" . str_replace("\'", "''", $custom_block) . "',
					cblock_bbcode_uid = 		'$bbcode_uid',
					show_profile_info = 		$show_profile_info,
					show_calendar = 			$show_calendar,
					show_contact_info = 		$show_contact_info,
					show_weblog_info = 		$show_weblog_info,
					show_shoutbox = 			$show_shoutbox,
					reply_in_popup = 			$reply_in_popup,
					weblog_shoutbox_desc =		$shoutbox_desc
				WHERE weblog_id = $weblog_id";
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not update weblog.', '', __LINE__, __FILE__, $sql);
			}

			$template->assign_vars(array(
				'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog.$phpEx?" . POST_ENTRY_URL . "=$weblog_id") . '">')
			);

			$message = sprintf($lang['Weblog_edited'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>', '<a href="' . append_sid("weblog_config.$phpEx") . '">', '</a>');
		}
	}
	else if ( isset($HTTP_POST_VARS['delete']) )
	{
		$sql = "UPDATE " . WEBLOGS_TABLE . " SET deleted = 1 WHERE weblog_id = $weblog_id";
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not update weblog.', '', __LINE__, __FILE__, $sql);
		}

		$template->assign_vars(array(
			'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog.$phpEx") . '">')
		);

		$message = sprintf($lang['Weblog_deleted'], '<a href="' . append_sid("weblogs.$phpEx") . '">', '</a>');
	}
	else if ( isset($HTTP_POST_VARS['undelete']) )
	{
		$sql = "UPDATE " . WEBLOGS_TABLE . " SET deleted = 0 WHERE weblog_id = $weblog_id";
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not update weblog.', '', __LINE__, __FILE__, $sql);
		}

		$template->assign_vars(array(
			'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("weblog.$phpEx?" . POST_ENTRY_URL . "=$weblog_id") . '">')
		);

		$message = sprintf($lang['Weblog_undeleted'], '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id") . '">', '</a>', '<a href="' . append_sid("weblog_config.$phpEx") . '">', '</a>');
	}

	message_die(GENERAL_MESSAGE, $message);
}

$template_id = $weblog_data['template_id'];

//
// Preparations
//

if ( $weblog_advanced )
{
	$weblog_faceplate = get_weblog_faceplate ( $weblog_data['weblog_id'] );
	$weblog_body = get_weblog_body ( $weblog_data['weblog_id'] );
}

//
// HTML toggle selection
//
if ( $board_config['allow_html'] )
{
	$html_status = $lang['HTML_is_ON'];
}
else
{
	$html_status = $lang['HTML_is_OFF'];
}

//
// Smilies toggle selection
//
if ( $board_config['allow_smilies'] )
{
	$smilies_status = $lang['Smilies_are_ON'];
}
else
{
	$smilies_status = $lang['Smilies_are_OFF'];
}

$font = 0;
for ( $i = 0; $i < NUM_WEBLOG_FONTS; $i++ )
{
	if ( $weblog_fonts[$i] == $font )
	{
		$font = $i;
		break;
	}
}

$custom_block = $weblog_data['custom_block'];
$custom_block = preg_replace('/\:(([a-z0-9]:)?)' . $weblog_data['cblock_bbcode_uid'] . '/s', '', $custom_block);

if ( $weblog_exists )
{
	$mood_set = $weblog_data['mood_set'];
}
else
{
	$mood_set = $mood_set_data[0]['set_id'];
}

$sql = "SELECT *
	FROM " . WEBLOG_MOODS_TABLE . "
		WHERE mood_set = " . $mood_set . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

$i = mt_rand(0,count($mood_data)-1);
$preview_mood = $mood_data[$i]['mood_url'];

//
// Start Page if no form submissions
//
$template->assign_vars(array(
	'L_WEBLOG_CP' => $lang['Weblog_CP'],
	'L_WEBLOG_NAME' => $lang['Weblog_name'],
	'L_WEBLOG_DESC' => $lang['Weblog_desc'],
	'L_WEBLOG_AUTH' => $lang['Weblog_auth'],
	'L_WEBLOG_AUTH_EXPLAIN' => $lang['Weblog_auth_explain'],
	'L_REPLY_AUTH' => $lang['Reply_auth'],
	'L_REPLY_AUTH_EXPLAIN' => $lang['Reply_auth_explain'],
	'L_NUMBER_OF_ENTRIES' => $lang['Number_of_entries'],
	'L_REPLIES_LABEL' => $lang['Replies_label'],
	'L_REPLIES_LABEL_EXPLAIN' => $lang['Replies_label_explain'],
	'L_POST_REPLY_LABEL' => $lang['Post_reply_label'],
	'L_WEBLOG_TEMPLATE' => $lang['Weblog_template'],
	'L_WEBLOG_TEMPLATE_EXPLAIN' => $lang['Weblog_template_explain'],
	'L_WEBLOG_TEMPLATE_EASY_EXPLAIN' => $lang['Weblog_template_easy_explain'],
	'L_WEBLOG_TEMPLATE_ADVANCED_EXPLAIN' => $lang['Weblog_template_advanced_explain'],
	'L_SHOW_PROFILE_INFO' => $lang['Show_profile_info'],
	'L_SHOW_CALENDAR' => $lang['Show_calendar'],
	'L_SHOW_CONTACT_INFO' => $lang['Show_contact_info'],
	'L_SHOW_WEBLOG_INFO' => $lang['Show_blog_info'],
	'L_REPLY_IN_POPUP' => $lang['Reply_in_popup'],
	'L_WEBLOG_FACEPLATE' => $lang['Weblog_faceplate'],
	'L_WEBLOG_FACEPLATE_EXPLAIN' => $lang['Weblog_faceplate_explain'],
	'L_WEBLOG_BODY' => $lang['Weblog_body'],
	'L_WEBLOG_BODY_EXPLAIN' => $lang['Weblog_body_explain'],
	'L_WEBLOG_AUTH_ALL' => $lang['Weblog_auth_all'],
	'L_WEBLOG_AUTH_RED' => $lang['Weblog_auth_reg'],
	'L_WEBLOG_AUTH_FRIENDS' => $lang['Weblog_auth_friends'],
	'L_WEBLOG_AUTH_OWNER' => $lang['Weblog_auth_owner'],
	'L_CREATE_WEBLOG' => $lang['Weblog_create'],
	'L_EDIT_WEBLOG' => $lang['Weblog_edit'],
	'L_MARKED_FOR_DELETION' => $lang['Marked_for_deletion'],
	'L_SWITCH_TEMPLATE' => $lang['Switch_template'],
	'L_PREVIEW' => $lang['Preview'],
	'L_YES' => $lang['Yes'],
	'L_NO' => $lang['No'],
	'L_ADV_APPROVED' => ( $userdata['user_allowadvweblog'] ) ? $lang['Advanced_mode_approved'] : '',
	'L_DO_NOTHING' => $lang['Do_nothing'],
	'L_LOAD_TEMPLATE' => $lang['Load_template'],
	'L_SWITCH_MODE' => ( $userdata['user_allowadvweblog'] ) ? (( $weblog_data['weblog_advanced'] ) ? $lang['Switch_easy'] : $lang['Switch_advanced']) : '',
	'L_MOOD_SET' => $lang['Mood_set'],
	'L_LOOK_AND_FEEL' => $lang['Look_and_feel'],
	'L_GENERAL_PAGE_SETTINGS' => $lang['General_page_settings'],
	'L_BACKGROUND_COLOR' => $lang['Background_color'],
	'L_SEE_HEX_COLORS' => $lang['See_hex_colors'],
	'L_ENTRY_BG_COLOR' => $lang['Entry_bg_color'],
	'L_BORDER_COLOR' => $lang['Border_color'],
	'L_BACKGROUND_IMAGE' => $lang['Background_image'],
	'L_URL' => $lang['URL'],
	'L_FIXED_BG' => $lang['Fixed_bg'],
	'L_TILE_BG' => $lang['Tile_bg'],
	'L_TILE' => $lang['Tile'],
	'L_TILE_HORIZONTALLY' => $lang['Tile_horizontally'],
	'L_TILE_VERTICALLY' => $lang['Tile_vertically'],
	'L_NO_TILE_BG' => $lang['No_tile_bg'],
	'L_VERTICAL_POSITION' => $lang['Vertical_position'],
	'L_TOP' => $lang['Top'],
	'L_CENTER' => $lang['Center'],
	'L_BOTTOM' => $lang['Bottom'],
	'L_HORIZONTAL_POSITION' => $lang['Horizontal_position'],
	'L_LEFT' => $lang['Left'],
	'L_RIGHT' => $lang['Right'],
	'L_SB_SETTINGS' => $lang['SB_Settings'],
	'L_SB_FACE_COLOR' => $lang['SB_Face_color'],
	'L_SB_HIGHLIGHT_COLOR' => $lang['SB_Highlight_color'],
	'L_SB_SHADOW_COLOR' => $lang['SB_Shadow_color'],
	'L_SB_3DLIGHT_COLOR' => $lang['SB_3DLight_color'],
	'L_SB_ARROW_COLOR' => $lang['SB_Arrow_color'],
	'L_SB_TRACK_COLOR' => $lang['SB_Track_color'],
	'L_SB_DARKSHADOW_COLOR' => $lang['SB_Darkshadow_color'],
	'L_FONT_SETTINGS' => $lang['Font_settings'],
	'L_FONT' => $lang['Font'],
	'L_ARIAL' => $lang['Arial'],
	'L_COMIC_SANS' => $lang['Comic_sans'],
	'L_COURIER_NEW' => $lang['Courier_new'],
	'L_GEORGIA' => $lang['Georgia'],
	'L_VERDANA' => $lang['Verdana'],
	'L_TIMES_NEW_ROMAN' => $lang['Times_new_roman'],
	'L_TREBUCHET' => $lang['Trebuchet'],
	'L_FONT_COLOR' => $lang['Font_color'],
	'L_FONT_SIZE' => $lang['Font_size'],
	'L_NORMAL_LINK' => $lang['Normal_link'],
	'L_UNDERLINE' => $lang['Underline'],
	'L_ACTIVE_LINK' => $lang['Active_link'],
	'L_HOVER_LINK' => $lang['Hover_link'],
	'L_VISITED_LINK' => $lang['Visited_link'],
	'L_WEBLOG_TITLE' => $lang['Weblog_title'],
	'L_ENTRY_TITLE' => $lang['Entry_title'],
	'L_COLOR' => $lang['Color'],
	'L_DATE_AND_TIME' => $lang['Date_and_time'],
	'L_BLOCK_TITLE' => $lang['Block_title'],
	'L_BLOCK_SETTINGS' => $lang['Block_settings'],
	'L_BLOCK_BG_COLOR' => $lang['Block_bg_color'],
	'L_BLOCK_BORDER_COLOR' => $lang['Block_border_color'],
	'L_CUSTOM_BLOCK' => $lang['Custom_block'],
	'L_CUSTOM_BLOCK_EXPLAIN' => $lang['Custom_block_explain'],
	'L_TITLE' => $lang['Title'],
	'L_SHOW_ENABLE_SHOUTBOX' => $lang['Show_enable_shoutbox'],
	'L_SHOUTBOX_DESC' => $lang['Shoutbox_desc'],
	'L_ASCENDING' => $lang['Sort_Ascending'],
	'L_DESCENDING' => $lang['Sort_Descending'],
	'L_RESET_VISIT_COUNTER' => $lang['Reset_visit_counter'],
	'L_RESET_VISITS_EXPLAIN' => $lang['Reset_visits_explain'],
	'L_RESET' => $lang['Reset'], 

	'BACKGROUND_COLOR' => $weblog_data['background_color'],
	'ENTRY_BG_COLOR' => $weblog_data['entry_bg_color'],
	'BORDER_COLOR' => $weblog_data['border_color'],
	'BACKGROUND_IMAGE' => substr($weblog_data['background_image'], 4, (strlen($weblog_data['background_image']) - 5)),
	'BACKGROUND_IMAGE_FIXED' => ( $weblog_data['background_image_fixed'] ) ? ' checked="checked"' : '',
	'TILE_BG_ALL' => ( $weblog_data['tile_bg'] == 'repeat' ) ? ' checked="checked"' : '',
	'TILE_BG_HORIZONTALLY' => ( $weblog_data['tile_bg'] == 'repeat-x' ) ? ' checked="checked"' : '',
	'TILE_BG_VERTICALLY' => ( $weblog_data['tile_bg'] == 'repeat-y' ) ? ' checked="checked"' : '',
	'NO_TILE_BG' => ( $weblog_data['tile_bg'] == 'no-repeat' ) ? ' checked="checked"' : '',
	'YPOS_TOP' => ( $weblog_data['bg_ypos'] == 'top' ) ? ' checked="checked"' : '',
	'YPOS_CENTER' => ( $weblog_data['bg_ypos'] == 'center' ) ? ' checked="checked"' : '',
	'YPOS_BOTTOM' => ( $weblog_data['bg_ypos'] == 'bottom' ) ? ' checked="checked"' : '',
	'XPOS_LEFT' => ( $weblog_data['bg_xpos'] == 'left' ) ? ' checked="checked"' : '',
	'XPOS_CENTER' => ( $weblog_data['bg_xpos'] == 'center' ) ? ' checked="checked"' : '',
	'XPOS_RIGHT' => ( $weblog_data['bg_xpos'] == 'right' ) ? ' checked="checked"' : '',
	'SB_FACE_COLOR' => $weblog_data['sb_face_color'],
	'SB_HIGHLIGHT_COLOR' => $weblog_data['sb_highlight_color'],
	'SB_SHADOW_COLOR' => $weblog_data['sb_shadow_color'],
	'SB_3DLIGHT_COLOR' => $weblog_data['sb_3dlight_color'],
	'SB_ARROW_COLOR' => $weblog_data['sb_arrow_color'],
	'SB_TRACK_COLOR' => $weblog_data['sb_track_color'],
	'SB_DARKSHADOW_COLOR' => $weblog_data['sb_darkshadow_color'],
	'ARIAL_SELECTED' => ( $weblog_data['font'] == 0 ) ? ' selected="selected"' : '',
	'COMIC_SANS_SELECTED' => ( $weblog_data['font'] == 1 ) ? ' selected="selected"' : '',
	'COURIER_NEW_SELECTED' => ( $weblog_data['font'] == 2 ) ? ' selected="selected"' : '',
	'GEORGIA_SELECTED' => ( $weblog_data['font'] == 3 ) ? ' selected="selected"' : '',
	'VERDANA_SELECTED' => ( $weblog_data['font'] == 4 ) ? ' selected="selected"' : '',
	'TIMES_NEW_ROMAN_SELECTED' => ( $weblog_data['font'] == 5 ) ? ' selected="selected"' : '',
	'TREBUCHET_SELECTED' => ( $weblog_data['font'] == 6 ) ? ' selected="selected"' : '',
	'FONT_COLOR' => $weblog_data['font_color'],
	'FONT_SIZE' => $weblog_data['font_size'],
	'NORMAL_LINK_COLOR' => $weblog_data['normal_link_color'],
	'NORMAL_LINK_UNDERLINED' => ( $weblog_data['normal_link_underline'] ) ? ' checked="checked"' : '',
	'ACTIVE_LINK_COLOR' => $weblog_data['active_link_color'],
	'ACTIVE_LINK_UNDERLINED' => ( $weblog_data['active_link_underline'] ) ? ' checked="checked"': '',
	'HOVER_LINK_COLOR' => $weblog_data['hover_link_color'],
	'HOVER_LINK_UNDERLINED' => ( $weblog_data['hover_link_underline'] ) ? ' checked="checked"': '',
	'VISITED_LINK_COLOR' => $weblog_data['visited_link_color'],
	'VISITED_LINK_UNDERLINED' => ( $weblog_data['visited_link_underline'] ) ? ' checked="checked"': '',
	'WEBLOG_TITLE_COLOR' => $weblog_data['weblog_title_color'],
	'WEBLOG_TITLE_FONT_SIZE' => $weblog_data['weblog_title_font_size'],
	'ENTRY_TITLE_COLOR' => $weblog_data['entry_title_color'],
	'ENTRY_TITLE_FONT_SIZE' => $weblog_data['entry_title_font_size'],
	'DATE_TIME_COLOR' => $weblog_data['date_time_color'],
	'DATE_TIME_FONT_SIZE' => $weblog_data['date_time_font_size'],
	'BLOCK_TITLE_COLOR' => $weblog_data['block_title_color'],
	'BLOCK_TITLE_FONT_SIZE' => $weblog_data['block_title_font_size'],
	'BLOCK_BG_COLOR' => $weblog_data['block_bg_color'],
	'BLOCK_BORDER_COLOR' => $weblog_data['block_border_color'],
	'CUSTOM_BLOCK_TITLE' => $weblog_data['custom_block_title'],
	'S_CUSTOM_BLOCK' => $custom_block,

	'WEBLOG_NAME' => ( $weblog_exists ) ? $weblog_data['weblog_name'] : sprintf($weblog_config['default_name'], $userdata['username']),
	'WEBLOG_DESC' => ( $weblog_exists ) ? $weblog_data['weblog_desc'] : sprintf($weblog_config['default_desc'], $userdata['username']),
	'ENTRIES_PERPAGE' => ( $weblog_exists ) ? intval($weblog_data['entries_perpage']) : intval($weblog_config['default_entries_perpage']),
	'POST_REPLY_TEXT' => ( $weblog_exists ) ? $weblog_data['post_reply_text'] : $weblog_config['default_post_reply_text'],
	'REPLIES_TEXT' => ( $weblog_exists ) ? $weblog_data['replies_text'] : $weblog_config['default_replies_text'],
	'WEBLOG_ADVANCED_ON' => ( $weblog_data['weblog_advanced'] ) ? ' checked="checked"' : '',
	'WEBLOG_ADVANCED_OFF' => ( !$weblog_data['weblog_advanced'] ) ? ' checked="checked"' : '',
	'SHOW_PROFILE_INFO_YES' => ( $weblog_data['show_profile_info'] ) ? ' checked="checked"' : '',
	'SHOW_PROFILE_INFO_NO' => ( !$weblog_data['show_profile_info'] ) ? ' checked="checked"' : '',
	'SHOW_CALENDAR_YES' => ( $weblog_data['show_calendar'] ) ? ' checked="checked"' : '',
	'SHOW_CALENDAR_NO' => ( !$weblog_data['show_calendar'] ) ? ' checked="checked"' : '',
	'SHOW_CONTACT_INFO_YES' => ( $weblog_data['show_contact_info'] ) ? ' checked="checked"' : '',
	'SHOW_CONTACT_INFO_NO' => ( !$weblog_data['show_contact_info'] ) ? ' checked="checked"' : '',
	'SHOW_WEBLOG_INFO_YES' => ( $weblog_data['show_weblog_info'] ) ? ' checked="checked"' : '',
	'SHOW_WEBLOG_INFO_NO' => ( !$weblog_data['show_weblog_info'] ) ? ' checked="checked"' : '',
	'SHOW_SHOUTBOX_YES' => ( $weblog_data['show_shoutbox'] ) ? ' checked="checked"' : '',
	'SHOW_SHOUTBOX_NO' => ( !$weblog_data['show_shoutbox'] ) ? ' checked="checked"' : '',
	'REPLY_IN_POPUP_YES' => ( $weblog_data['reply_in_popup'] ) ? ' checked="checked"' : '',
	'REPLY_IN_POPUP_NO' => ( !$weblog_data['reply_in_popup'] ) ? ' checked="checked"' : '',
	'SHOUTBOX_DESC' => ( $weblog_data['weblog_shoutbox_desc'] ) ? ' checked="checked"' : '',
	'SHOUTBOX_ASC' => ( !$weblog_data['weblog_shoutbox_desc'] ) ? ' checked="checked"' : '',
	'PREVIEW_IMG' => ( $weblog_exists ) ? 'weblogs/templates/' . get_template_dir ($template_id) . '/preview_img.gif' : 'weblogs/templates/' . $template_data[0]['template_dir'] . '/preview_img.gif',
	
	'DELETE_NAME' => ( $weblog_data['deleted'] ) ? 'undelete' : 'delete',
	'L_DELETE_WEBLOG' => ( $weblog_data['deleted'] ) ? $lang['Weblog_undelete'] : $lang['Weblog_delete'],

	'MOOD_SET_PREVIEW' => $phpbb_root_path . $preview_mood,
	'SWITCH_RADIO' => ( $userdata['user_allowadvweblog'] ) ? '<input type="radio" id="action_switch_mode" name="weblog_action" value="2" />' : '',
	'TEMPLATE_SELECT' => make_template_select ( $template_id , 'template_select', $weblog_exists ),
	'MOOD_SET_SELECT' => make_mood_set_select ( $weblog_data['mood_set'], 'mood_set_select'),
	'WEBLOG_AUTH_SELECT' => ( $weblog_exists ) ? make_weblog_auth_select ( $weblog_data['weblog_auth'], 'weblog_auth_select') : make_weblog_auth_select ( $weblog_config['default_auth'], 'weblog_auth_select'),
	'REPLIES_AUTH_SELECT' => ( $weblog_exists ) ? make_weblog_auth_select ( $weblog_data['replies_auth'], 'replies_auth_select') : make_weblog_auth_select ( $weblog_config['default_reply_auth'], 'replies_auth_select'),

	'S_WEBLOG_FACEPLATE' => htmlentities($weblog_faceplate),
	'S_WEBLOG_BODY' => htmlentities($weblog_body),
	'S_FORM_ACTION' => append_sid($HTTP_SERVER_VARS['PHP_SELF']))
);

$template->pparse("body");

$template->assign_vars(array(
	'L_POWERED_BY' => sprintf($lang['Weblog_powered_by'], WEBLOGS_MOD_VERSION))
);

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>