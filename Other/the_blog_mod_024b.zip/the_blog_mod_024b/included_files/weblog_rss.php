<?php
/***************************************************************************
 *                              weblog_rss.php
 *                           --------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *   
 *   forum		  : http://www.TheBlogMod.com community
 *   email		  : Managed by support [at] TheBlogMod.com
 *
 *   $Id: weblog_rss.php,v 1.0.0 2004/09/05, 13:17:43 Hyperion Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/bbcode.' . $phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

//	
// Start initial var setup
//
if( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) || isset($HTTP_POST_VARS[POST_WEBLOG_URL]) )
{
	$weblog_id = ( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) ) ? intval($HTTP_GET_VARS[POST_WEBLOG_URL]) : intval($HTTP_POST_VARS[POST_WEBLOG_URL]);
	$weblog_id = intval($weblog_id);
}


//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


//
// Check if the user has actually sent a forum ID with his/her request
// If not give them a nice error page.
//
if( !empty($weblog_id) )
{
	$sql = "SELECT w.*, u.user_id
		FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
		WHERE w.weblog_id = $weblog_id
			AND u.user_weblog = w.weblog_id";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't obtain weblogs information.", "", __LINE__, __FILE__, $sql);
	}

	//
	// If the query doesn't return any rows this isn't a valid forum. Inform
	// the user.
	//
	if( !($weblog_data = $db->sql_fetchrow($result)) )
	{
		message_die(GENERAL_MESSAGE, $lang['Weblog_not_exist']);
	}

	if ( $weblog_data['deleted'] )
	{
		message_die(GENERAL_ERROR, sprintf($lang['Weblog_deactivated'], $weblog_data['weblog_name']));
	}

	//
	// Fetch Contributor data
	//
	$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE weblog_id = $weblog_id AND user_id = " . $userdata['user_id'];
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
	}
	
	$contributor = FALSE;
	if ( $row = $db->sql_fetchrow($result) || $userdata['user_level'] == ADMIN )
	{
		$contributor = TRUE;
	}

	// Get the user's clearence levels
	$auth_level = get_auth_level ( $weblog_data, $contributor );

	// See if user can see this weblog
	if ( $weblog_data['weblog_auth'] > $auth_level )
	{
		message_die(GENERAL_ERROR, $lang['Weblog_noaccess']);
	}

	//
	// Get the owner's data
	//
	$sql = "SELECT * FROM " . USERS_TABLE . "
			WHERE user_weblog = " . $weblog_data['weblog_id'];
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't get weblog owner information.", "", __LINE__, __FILE__, $sql);
	}

	$owner_data = array();
	if ( $row = $db->sql_fetchrow($result) )
	{
		$owner_data = $row;
	}

	//
	// Fetch Entries
	//
	$sql = "SELECT * FROM " . WEBLOG_ENTRIES_TABLE . "
		WHERE weblog_id = " . $weblog_data['weblog_id'] . "
			AND entry_access <= $auth_level
			AND entry_deleted = 0
			AND entry_time <= " . time() . "
		ORDER BY entry_time DESC
		LIMIT " . $weblog_data['entries_perpage'];
	if(!($result = $db->sql_query($sql)))
	{
		message_die(GENERAL_ERROR, 'Could not query weblog entry information', '', __LINE__, __FILE__, $sql);
	}

	$entry_data = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$entry_data[] = $row;
	}
}

// 
// Start output of RSS
//

$server_name = trim($board_config['server_name']);
$server_protocol = ( $board_config['cookie_secure'] ) ? 'https://' : 'http://';
$server_port = ( $board_config['server_port'] <> 80 ) ? ':' . trim($board_config['server_port']) . '/' : '';
$script_name = preg_replace('/^\/?(.*?)\/?$/', '\1', trim($board_config['script_path']));

$basedir = $server_protocol . $server_name .  $server_port . '/' .  $script_name . '/';

$smilies_path = $board_config['smilies_path'];
$smilies_url = $basedir . $smilies_path;
$smilies_path = preg_replace("/\//", "\/", $smilies_path);


header ('Expires: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
header ('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header ('Content-Type: text/xml');

echo ("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>\n");
echo ("  <rss version=\"2.0\">\n");
echo ("	<channel>\n");
if ( $weblog_id )
{
	echo ("	  <title>" . $weblog_data['weblog_name'] . "</title>\n");
	echo ("	  <link>" . $basedir . "weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id" . "</link>\n");
}
else
{
	echo ("	  <title>" . $lang['Latest_weblogs_feed'] . "</title>\n");
	echo ("	  <link>" . $basedir . "weblogs.$phpEx</link>\n");
}
echo ("	  <webMaster>" . $board_config['board_email'] . "</webMaster>\n");
echo ("	  <lastBuildDate>" . gmdate('D, d M Y H:i:s', time()) . " GMT</lastBuildDate>\n");
echo ("	  <generator>The Blog Mod " . WEBLOGS_MOD_VERSION . " by Hyperion</generator>\n");

if ( $weblog_id )
{

//
// Get the moods data
//
$sql = "SELECT *
	FROM " . WEBLOG_MOODS_TABLE . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

//
// Get the actions data
//
$sql = "SELECT *
	FROM " . WEBLOG_ACTIONS_TABLE . "
	ORDER BY action_text";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, "Couldn't obtain action data from database", "", __LINE__, __FILE__, $sql);
}
$action_data = $db->sql_fetchrowset($result);


for ($i = 0; $i < count($entry_data); $i++)
{
	//
	// Prepare every entry
	//
	$entry_data[$i]['entry_text'] = htmlspecialchars($entry_data[$i]['entry_text']);
	
// BBCode
	if ( $entry_data[$i]['enable_bbcode'] )
	{
		$entry_data[$i]['entry_text'] = bbencode_second_pass($entry_data[$i]['entry_text'], $entry_data[$i]['bbcode_uid']);
	}

	// Smilies
	if ( $entry_data[$i]['enable_smilies'] )
	{
		$entry_data[$i]['entry_text'] = smilies_pass($entry_data[$i]['entry_text']);
	}

	$entry_data[$i]['entry_text'] = make_clickable($entry_data[$i]['entry_text']);

	if ( !$weblog_config['censor_weblog'] )
	{
		// Define censored word matches
		$orig_word = array();
		$replacement_word = array();
		obtain_word_list($orig_word, $replacement_word);

		// Censor text and title
		if (count($orig_word))
		{
			$entry_data[$i]['entry_subject'] = preg_replace($orig_word, $replacement_word, $entry_data[$i]['entry_subject']);
			$entry_data[$i]['entry_text'] = preg_replace($orig_word, $replacement_word, $entry_data[$i]['entry_text']);
		}
	}

	$entry_data[$i]['entry_text'] = nl2br($entry_data[$i]['entry_text']);

	// Mood Icons
	$mood = array();
	$mood = find_mood($entry_data[$i]['entry_mood']);

	if ( $mood >= 0 )
	{ 
		$mood = '<strong>[</strong>&nbsp;' . sprintf($lang['Mood:'], '<img src="' . $basedir . 'images/weblogs/' . $mood['mood_url'] . '" alt="' . $mood['mood_text'] . '" style="vertical-align: middle" border="0" />', $mood['mood_text']) . '&nbsp;<strong>]</strong><br />';
	}
	else
	{
		$mood = '';
	}

	// Currently Icons
	$currently = array();
	$currently = find_action($entry_data[$i]['entry_currently']);

	if ( $currently > 0 )
	{
		$action = '<strong>[</strong>&nbsp;' . sprintf($lang['Currently:'], '<img src="' . $basedir . 'images/weblogs/' . $currently['action_url'] . '" alt="' . $currently['action_text'] . ' ' . $entry_data[$i]['currently_text'] . '" style="vertical-align: middle" border="0" />',  $currently['action_text'] . ' ' . $entry_data[$i]['currently_text']) . '&nbsp;<strong>]</strong><br />'; 
	}
	else if ( $entry_data[$i]['currently_text'] && $currently == -2 )
	{
		$action = '<strong>[</strong>' . sprintf($lang['Currently:'], '', $entry_data[$i]['currently_text']) . '&nbsp;<strong>]</strong><br />';
	}
	else
	{
		$action = '';
	}

// better smilies
	$entry_data[$i]['entry_text'] = preg_replace('/img src ?= ?"images/', 'img src="' . $basedir . 'images', $entry_data[$i]['entry_text']);

	$entry_data[$i]['entry_text'] = $mood . $action . $entry_data[$i]['entry_text'];

	$entry_data[$i]['entry_text'] = trim ($entry_data[$i]['entry_text']);

	$entry_data[$i]['entry_text'] = cut_message ( $entry_data[$i]['entry_text'], $entry_data[$i]['entry_id'] );

	// Variable reassignment and reformatting for author
	$entry_author = $owner_data['username'] . ' ';
	if ( ($owner_data['user_viewemail']) || $userdata['user_level'] == ADMIN )
	{
		$entry_author .= $owner_data['user_email'];
	}

	$entry_link = $basedir . "weblog_entry.$phpEx?" . POST_ENTRY_URL . "=" . $entry_data[$i]['entry_id'];

	$entry_time = $entry_data[$i]['entry_time'];
	echo ("	  <item>\n");
	echo ("	    <title>" . $entry_data[$i]['entry_subject'] . "</title>\n");
	echo ("	    <link>" . $entry_link . "</link>\n");
	echo ("	    <description>" . htmlspecialchars($entry_data[$i]['entry_text']) . "</description>\n");
	echo ("	    <author>" . $entry_author . "</author>\n");
	echo ("	    <pubDate>" . gmdate('D, d M Y H:i:s', $entry_data[$i]['entry_time']) . " GMT</pubDate>\n");
	echo ("	  </item>\n");
}

}
else
{
	// Let's do latest weblogs feed

	//
	// Get Weblog Data
	//
	$weblog_data = fetch_visible_weblogs ();

	for ($i = 0; $i < count($weblog_data) && $i < 10; $i++)
	{
		$weblog_link = $basedir . "weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data[$i]['weblog_id'];

		echo ("	  <item>\n");
		echo ("	    <title>" . $weblog_data[$i]['weblog_name'] . "</title>\n");
		echo ("	    <link>" . $weblog_link . "</link>\n");
		echo ("	    <description>" . htmlspecialchars($weblog_data[$i]['weblog_desc']) . "</description>\n");
		echo ("	    <author>" . $weblog_data[$i]['username'] . "</author>\n");
		echo ("	    <pubDate>" . gmdate('D, d M Y H:i:s', $weblog_data[$i]['entry_time']) . " GMT</pubDate>\n");
		echo ("	  </item>\n");
	}
}

echo ("	</channel>\n");
echo ("  </rss>\n");
?>