<?php
/***************************************************************************
 *                                weblog.php
 *                            -------------------
 *   begin                : Monday, September 5, 2004
 *   copyright            : (C) 2005 Hyperion
 *
 *   forum		  : http://www.TheBlogMod.com community
 *   email		  : Managed by support [at] TheBlogMod.com
 *
 *   $Id: weblog.php,v 1.0.1 2006/01/29, 22:01:01 support at blogpoint.com (former Hyperion) Exp $
 *   $Id: weblog.php,v 1.0.2 2006/03/03, 12:34:01 support at blogpoint.com
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

/*****
############################################################## 
## ADDON Title: Addon "Categories" For The Blog Mod (0.24) 
## ADDON Author: E. Queffelec 
## ADDON Description: Adds a Categories System to the Blog Mod 0.24. 
##          Included the changes for the Infinity Template, please update your other templates ! 
## ADDON Version: Alpha 
## 
############################################################## 
*****/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/bbcode.'.$phpEx);
include($phpbb_root_path . 'includes/weblogs_common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_weblog.'.$phpEx);

//	
// Start initial var setup
//
if( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) || isset($HTTP_POST_VARS[POST_WEBLOG_URL]) )
{
	$weblog_id = ( isset($HTTP_GET_VARS[POST_WEBLOG_URL]) ) ? intval($HTTP_GET_VARS[POST_WEBLOG_URL]) : intval($HTTP_POST_VARS[POST_WEBLOG_URL]);
	$username = '';
}
else if( isset($HTTP_GET_VARS[POST_USERS_URL]) || isset($HTTP_POST_VARS[POST_USERS_URL]) )
{
	$username = ( isset($HTTP_GET_VARS[POST_USERS_URL]) ) ? htmlspecialchars($HTTP_GET_VARS[POST_USERS_URL]) : intval($HTTP_POST_VARS[POST_USERS_URL]);
	$weblog_id = 0;
}
else
{
	$username = '';
	$weblog_id = 0;
}


//
// Fetch weblog
//
if( !empty($weblog_id) )
{
	$sql = "SELECT w.*, u.*
		FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
		WHERE w.weblog_id = $weblog_id
			AND w.weblog_id = u.user_weblog";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't obtain weblogs information.", "", __LINE__, __FILE__, $sql);
	}
}
else if ( !empty($username) )
{
	$sql = "SELECT w.*, u.*
		FROM " . WEBLOGS_TABLE . " w, " . USERS_TABLE . " u
		WHERE w.weblog_id = u.user_weblog
			AND u.username = '" . str_replace("\'", "''", $username) . "'";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't obtain weblogs information.", "", __LINE__, __FILE__, $sql);
	}
}
else
{
	message_die(GENERAL_MESSAGE, 'Weblog_not_exist');
}

$weblog_data = array();
if( !($weblog_data = $db->sql_fetchrow($result)) )
{
	message_die(GENERAL_MESSAGE, 'Weblog_not_exist');
}
$weblog_id = $weblog_data['weblog_id'];

//
// Start session management
//
$userdata = session_pagestart($user_ip, 10000 + $weblog_id); // Mimicking a forum for the "Users browsing this blog:" feature
init_userprefs($userdata);
//
// End session management
//

//Category Addon courtesy by willow at TheBlogMod.com
if( isset($HTTP_GET_VARS['category']) )
{
	$category = $HTTP_GET_VARS['category'];
}
else
{
	$category = '';
}
$theCategory = $category;

if( isset($HTTP_GET_VARS['previous']) )
{
	$previous = abs(intval($HTTP_GET_VARS['previous']));
}
else
{
	$previous = 0;
}

if( isset($HTTP_GET_VARS['month']) && !empty($HTTP_GET_VARS['month']) )
{
	$month = intval($HTTP_GET_VARS['month']);

	if ( $month < 1 || $month > 12 )
	{
		$month = create_date("n", time(), $board_config['board_timezone']);
	}
}

if( isset($HTTP_GET_VARS['day']) && !empty($HTTP_GET_VARS['day']) )
{
	$day = intval($HTTP_GET_VARS['day']);

	if ( $day < 1 || $day > 31 )
	{
		$day = create_date("j", time(), $board_config['board_timezone']);
	}
}

if( isset($HTTP_GET_VARS['year']) && !empty($HTTP_GET_VARS['year']) )
{
	$year = intval($HTTP_GET_VARS['year']);

	if ( $year < 1970 || $year > 2038 )
	{
		$year = create_date("Y", time(), $board_config['board_timezone']);
	}
}


$months = array($lang['datetime']['January'],$lang['datetime']['February'],$lang['datetime']['March'],$lang['datetime']['April'],$lang['datetime']['May'],$lang['datetime']['June'], $lang['datetime']['July'], $lang['datetime']['August'], $lang['datetime']['September'], $lang['datetime']['October'], $lang['datetime']['November'], $lang['datetime']['December']);

if ( !$weblog_data['user_allowweblog'] )
{
	message_die(GENERAL_ERROR, sprintf($lang['Owner_is_banned'], $weblog_data['username']));
}
else if ( $weblog_data['deleted'] )
{
	message_die(GENERAL_ERROR, sprintf($lang['Weblog_deactivated'], $weblog_data['weblog_name']));
}


//
// Fetch Contributor data
//
$sql = "SELECT * FROM " . WEBLOG_CONTRIBUTORS_TABLE . " WHERE weblog_id = $weblog_id AND user_id = " . $userdata['user_id'];
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$contributor = FALSE;
if ( $row = $db->sql_fetchrow($result) || $userdata['user_level'] == ADMIN )
{
	$contributor = TRUE;
}

// Get the user's clearence levels
$auth_level = get_auth_level ( $weblog_data, $contributor );

// See if user can see this weblog
if ( $weblog_data['weblog_auth'] > $auth_level )
{
	message_die(GENERAL_ERROR, $lang['Weblog_noaccess']);
}

//
// Fetch Contributor data (2)
//
$sql = "SELECT u.* FROM " . WEBLOG_CONTRIBUTORS_TABLE . " c, " . USERS_TABLE . " u WHERE c.weblog_id = $weblog_id AND c.user_id = u.user_id";
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error querying to find user weblog information', '', __LINE__, __FILE__, $sql);
}

$contributors = '';
while ( $row = $db->sql_fetchrow($result) )
{
	if ( !empty($contributors) )
	{
		$temp_url = append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $row['user_id']);
		$contributors .= ', <a href="' . $temp_url . '">' . $row['username'] . '</a>';
	}
	else
	{
		$temp_url = append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $row['user_id']);
		$contributors = '<a href="' . $temp_url . '">' . $row['username'] . '</a>';
	}
}

if ( empty($contributors) )
{
	$contributors = $lang['(None)'];
}

//
// Take care of shoutbox posting
//
if ( isset ($HTTP_POST_VARS['submit']) && $weblog_data['show_shoutbox'] )
{
	// First do a flood check
	$sql = "SELECT shout_time FROM " . WEBLOG_SHOUTBOX_TABLE . " ORDER BY shout_time DESC LIMIT 1";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not query latest shout time from database', '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$latest_time = $row['shout_time'];
	}

	if ( !empty($latest_time) && (time() - $latest_time) < $weblog_config['shoutbox_flood_delay'] )
	{
		message_die (GENERAL_MESSAGE, sprintf($lang['Shoutbox_flooded'], $weblog_config['shoutbox_flood_delay'] - (time() - $latest_time)) );
	}
	include($phpbb_root_path . 'includes/functions_post.'.$phpEx);

	$post_username = ( isset($HTTP_POST_VARS['username']) ) ? $HTTP_POST_VARS['username'] : '';
	$message = ( isset($HTTP_POST_VARS['message']) ) ? $HTTP_POST_VARS['message'] : '';
	$website = ( isset($HTTP_POST_VARS['www']) ) ? $HTTP_POST_VARS['www'] : '';

	$error_msg = '';

	// Check username
	if (!empty($post_username))
	{
		$post_username = trim(strip_tags($post_username));
	
		if (!$userdata['session_logged_in'] || ($userdata['session_logged_in'] && $post_username != $userdata['username']))
		{
			include($phpbb_root_path . 'includes/functions_validate.'.$phpEx);

			$result = validate_username($post_username);
			if ($result['error'])
			{
				$error_msg .= (!empty($error_msg)) ? '<br />' . $result['error_msg'] : $result['error_msg'];
			}
		}
		else
		{
			$post_username = '';
		}
	}

	// Check message
	if (!empty($message))
	{
		$bbcode_uid = make_bbcode_uid();
		$message = prepare_message(trim($message), 1, 1, 1, $bbcode_uid);
	}
	else
	{
		$error_msg .= (!empty($error_msg)) ? '<br />' . $lang['Empty_message'] : $lang['Empty_message'];
	}

	if ( empty($error_msg) )
	{
		$poster_id = $userdata['user_id'];


		$website = trim(htmlspecialchars($website));

		if ( $website != '' )
		{
			if (!preg_match('#^http[s]?:\/\/#i', $website))
			{
				$website = 'http://' . $website;
			}

			if (!preg_match('#^http[s]?\\:\\/\\/[a-z0-9\-]+\.([a-z0-9\-]+\.)?[a-z]+#i', $website))
			{
				$website = '';
			}
			rawurlencode($website);
		}

		$maximum = 0;

		// First, get the maximum shout id
		$sql = "SELECT MAX(shout_id) AS maximum FROM " . WEBLOG_SHOUTBOX_TABLE;
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not query maximum shout id from database', '', __LINE__, __FILE__, $sql);
		}

		if ( $row = $db->sql_fetchrow($result) )
		{
			$maximum = $row['maximum'];
		}

		$maximum++;

		$sql = "INSERT INTO " . WEBLOG_SHOUTBOX_TABLE . " (shout_id, shout_weblog, shout_text, shout_poster, shout_username, bbcode_uid, shout_time, shout_www)
				VALUES ($maximum, $weblog_id, '" . str_replace("\'", "''", $message) . "', $poster_id, '" . str_replace("\'", "''", $post_username) . "', '$bbcode_uid', " . time() . ", '" . str_replace("\'", "''", $website) . "' )";
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not insert shout into database', '', __LINE__, __FILE__, $sql);
		}
	}
	else
	{
		message_die(GENERAL_ERROR, $error_msg);
	}
}
else if ( isset($HTTP_GET_VARS['d']) )
{
	$shout_id = intval($HTTP_GET_VARS['d']);

	if ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor )
	{
		$sql = "DELETE FROM " . WEBLOG_SHOUTBOX_TABLE . " WHERE shout_id = $shout_id";
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not delete shout.', '', __LINE__, __FILE__, $sql);
		}
	}
}


if ( $weblog_data['weblog_id'] != $userdata['user_weblog'] && !$contributor )
{
	//
	// Update the number of views for this weblog
	//
	$sql = "UPDATE " . WEBLOGS_TABLE . "
		SET weblog_views = weblog_views + 1
		WHERE weblog_id = $weblog_id";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't update weblog views information.", "", __LINE__, __FILE__, $sql);
	}
}

$template_dir = get_template_dir ($weblog_data['template_id']);
$page_title = $weblog_data['weblog_name'];
//
// Start output of page
//
use_weblog_header ( $weblog_data, $template_dir, FALSE );

if ( $weblog_data['weblog_advanced'] )
{
	$template->set_filenames(array(
		'body' => '../../weblogs/weblog_' . $weblog_data['weblog_id'] . '.htm')
	);
}
else
{
	$template_dir = get_template_dir ($weblog_data['template_id']);

	@include($phpbb_root_path . 'weblogs/templates/' . $template_dir . '/' . $template_dir . '.cfg');

	$template->set_filenames(array(
		'header' => '../../weblogs/templates/' . $template_dir . '/weblog_header.htm',
		'body' => '../../weblogs/templates/' . $template_dir . '/weblog_s_body.htm',
		'footer' => '../../weblogs/templates/' . $template_dir . '/weblog_footer.htm')
	);

	if ( $weblog_data['show_profile_info'] )
	{
		$template->assign_block_vars('switch_show_profile', array());
	}
	if ( $weblog_data['show_contact_info'] )
	{
		$template->assign_block_vars('switch_contact_user', array());
	}
	if ( $weblog_data['show_weblog_info'] )
	{
		$template->assign_block_vars('switch_show_info', array());
	}
	if ( $weblog_data['show_calendar'] )
	{
		$template->assign_block_vars('switch_show_calendar', array());
	}

	if ( $weblog_data['show_shoutbox'] )
	{
		$template->assign_block_vars('switch_shoutbox', array());
	}
}

if ( $weblog_data['weblog_id'] == $userdata['user_weblog'] )
{
	$template->assign_block_vars('switch_owner_only', array());
	$template->assign_block_vars('switch_contributor_only', array());
}
else if ( $contributor )
{
	$template->assign_block_vars('switch_contributor_only', array());
}

if ( !$weblog_data['weblog_advanced'] )
{
	$template->pparse('header');
}

// Prepare Avatar Image
$avatar_img = '';
if ( $weblog_data['user_avatar_type'] && $weblog_data['user_allowavatar'] )
{
	switch( $weblog_data['user_avatar_type'] )
	{
		case USER_AVATAR_UPLOAD:
			$avatar_img = ( $board_config['allow_avatar_upload'] ) ? '<img src="' . $board_config['avatar_path'] . '/' . $weblog_data['user_avatar'] . '" alt="" border="0" />' : '';
			break;
		case USER_AVATAR_REMOTE:
			$avatar_img = ( $board_config['allow_avatar_remote'] ) ? '<img src="' . $weblog_data['user_avatar'] . '" alt="" border="0" />' : '';
			break;
		case USER_AVATAR_GALLERY:
			$avatar_img = ( $board_config['allow_avatar_local'] ) ? '<img src="' . $board_config['avatar_gallery_path'] . '/' . $weblog_data['user_avatar'] . '" alt="" border="0" />' : '';
			break;
	}
}


$pm_url = append_sid("privmsg.$phpEx?mode=post&amp;" . POST_USERS_URL . "=" . $weblog_data['user_id']);

if ( ($weblog_data['user_viewemail']) || $userdata['user_level'] == ADMIN )
{
	$email_url = ( $board_config['board_email_form'] ) ? append_sid("profile.$phpEx?mode=email&amp;" . POST_USERS_URL .'=' . $weblog_data['user_id']) : 'mailto:' . $weblog_data['user_email'];
	$email = $weblog_data['user_email'];
}
else
{
	$email_url = '';
	$email = '';
}

if ( !empty($weblog_data['user_aim']) )
{
	$www_url = $weblog_data['user_website'];
}
else
{
	$www_url = '';
}

if ( !empty($weblog_data['user_icq']) )
{
	$icq_url = 'http://wwp.icq.com/scripts/search.dll?to=' . $weblog_data['user_icq'];
	$icq = $weblog_data['user_icq'];
}
else
{
	$icq_url = '';
	$icq = '';
}

if ( !empty($weblog_data['user_aim']) )
{
	$aim_url = 'aim:goim?screenname=' . $weblog_data['user_aim'] . '&amp;message=Hello+Are+you+there?';
	$aim = $weblog_data['user_aim'];
}
else
{
	$aim_url = '';
	$aim = $weblog_data['user_aim'];
}

if ( !empty($weblog_data['user_yim']) )
{
	$yim_url = 'http://edit.yahoo.com/config/send_webmesg?.target=' . $weblog_data['user_yim'] . '&amp;.src=pg';
	$yim = $weblog_data['user_yim'];
}
else
{
	$yim_url = '';
	$yim = '';
}

if ( !empty($weblog_data['user_msnm']) )
{
	$msn = $weblog_data['user_msnm'];
}
else
{
	$msn = '';
}

//
// Fetch Posts from Weblog table
//

// Figure out what to do when a new date is requested
if ( $year && !$month && !$day )
{
	$end_time = mktime(0,0,0,1,1,$year+1);
	$begin_time = mktime(0,0,0,1,1,$year);
}
else if ( $year && $month && !$day )
{
	$end_time = mktime(0,0,0,$month+1,1,$year); // Setting date parameter to zero means same as last day
	$begin_time = mktime(0,0,0,$month,1,$year);
}
else if ( $year && $month && $day )
{
	$end_time = mktime(0,0,0,$month,$day+1,$year);
	$begin_time = mktime(0,0,0,$month,$day,$year);
}
else
{
	$begin_time = 0;
	$end_time = time();
}

//
// Get the moods data
//
$sql = "SELECT *
	FROM " . WEBLOG_MOODS_TABLE . "
	ORDER BY mood_text";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't obtain mood data from database", "", __LINE__, __FILE__, $sql);
}
$mood_data = $db->sql_fetchrowset($result);

//
// Get the actions data
//
$sql = "SELECT *
	FROM " . WEBLOG_ACTIONS_TABLE . "
	ORDER BY action_text";
if( !$result = $db->sql_query($sql) )
{
	weblog_message_die(GENERAL_ERROR, "Couldn't obtain action data from database", "", __LINE__, __FILE__, $sql);
}
$action_data = $db->sql_fetchrowset($result);

// CategoryAddon courtesy by willow at TheBlogPoint.com
$categoryClause = "";
if ($category !='') {
	$categoryClause = " AND e.category = '" .$category ."' ";
	}

//
// Fetch Entries
//
$sql = "SELECT e.*, u.* FROM " . WEBLOG_ENTRIES_TABLE . " e, " . USERS_TABLE . " u
	WHERE e.weblog_id = $weblog_id " . $categoryClause . "
		AND e.entry_poster_id = u.user_id
		AND e.entry_access <= $auth_level
		AND e.entry_deleted <> " . TRUE . "
	ORDER BY e.entry_time DESC";
if(!($result = $db->sql_query($sql)))
{
	weblog_message_die(GENERAL_ERROR, 'Could not query weblog entry information', '', __LINE__, __FILE__, $sql);
}

$entry_data = array();
while ( $row = $db->sql_fetchrow($result) )
{
	$entry_data[] = $row;
}

$entries_processed = 0;
$update_sql = '';		// Lets make a query to increment entry_views all in one request.

for ($i = $previous; $i < count($entry_data) && $entries_processed < $weblog_data['entries_perpage']; $i++)
{
	//
	// Skip entries that are not in our timeframe
	//
	if ( $entry_data[$i]['entry_time'] < $begin_time || $entry_data[$i]['entry_time'] > $end_time )
	{
		continue;
	}

	if ( !$update_sql )
	{
		$update_sql = "UPDATE " . WEBLOG_ENTRIES_TABLE . " SET entry_views = entry_views + 1 WHERE entry_id = " . $entry_data[$i]['entry_id'];
	}
	else
	{
		$update_sql .= " OR entry_id = " . $entry_data[$i]['entry_id'];
	}

	$entry_data[$i]['entry_text'] = cut_message ( $entry_data[$i]['entry_text'], $entry_data[$i]['entry_id'] );

	//
	// Prepare every entry
	//
	if ( !$board_config['allow_html'] )
	{
		if ( $entry_data[$i]['enable_html'] )
		{
			preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $entry_data[$i]['entry_text']);
		}
	}

	// BBCode
	if ( $board_config['allow_bbcode'] )
	{
		if ( $entry_data[$i]['enable_bbcode'] )
		{
			$entry_data[$i]['entry_text'] = ( $entry_data[$i]['bbcode_uid'] ) ? bbencode_second_pass($entry_data[$i]['entry_text'], $entry_data[$i]['bbcode_uid']) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $entry_data[$i]['entry_text']);
		}
	}

	$entry_data[$i]['entry_text'] = make_clickable($entry_data[$i]['entry_text']);

	// Smilies
	if ( $board_config['allow_smilies'] )
	{
		if ( $entry_data[$i]['enable_smilies'] )
		{
			$entry_data[$i]['entry_text'] = smilies_pass($entry_data[$i]['entry_text']);
		}
	}

	if ( $weblog_config['censor_weblog'] )
	{
		// Define censored word matches
		$orig_word = array();
		$replacement_word = array();
		obtain_word_list($orig_word, $replacement_word);

		// Censor text and title
		if (count($orig_word))
		{
			$entry_data[$i]['entry_subject'] = preg_replace($orig_word, $replacement_word, $entry_data[$i]['entry_subject']);
			$entry_data[$i]['entry_text'] = preg_replace($orig_word, $replacement_word, $entry_data[$i]['entry_text']);
			$entry_data[$i]['currently_text'] = preg_replace($orig_word, $replacement_word, $entry_data[$i]['currently_text']);
		}
	}

	$entry_data[$i]['entry_text'] = str_replace("\n", "\n<br />\n", $entry_data[$i]['entry_text']);

	// Mood Icons
	$mood = array();
	$mood = find_mood($entry_data[$i]['entry_mood']);

	if ( $mood >= 0 )
	{ 
		$mood = '<strong>[</strong>&nbsp;' . sprintf($lang['Mood:'], '<img src="images/weblogs/' . $mood['mood_url'] . '" alt="' . $mood_data['mood_text'] . '" style="vertical-align: middle" border="0" />', $mood['mood_text']) . '&nbsp;<strong>]</strong>';
	}
	else
	{
		$mood = '';
	}

	// Currently Icons
	$currently = array();
	$currently = find_action($entry_data[$i]['entry_currently']);

	if ( $currently > 0 )
	{
		$action = '<strong>[</strong>&nbsp;' . sprintf($lang['Currently:'], '<img src="images/weblogs/' . $currently['action_url'] . '" alt="' . $currently['action_text'] . ' ' . $entry_data[$i]['currently_text'] . '" style="vertical-align: middle" border="0" />',  $currently['action_text'] . ' ' . $entry_data[$i]['currently_text']) . '&nbsp;<strong>]</strong>'; 
	}
	else if ( $entry_data[$i]['currently_text'] && $currently == -2 )
	{
		$action = '<strong>[</strong>' . sprintf($lang['Currently:'], '', $entry_data[$i]['currently_text']) . '&nbsp;<strong>]</strong>';
	}
	else
	{
		$action = '';
	}

// CategoryAddon courtesy by Willow at TheBlogMod.com
$category = $entry_data[$i]['category'];
if ( $category !="" )
{
	$category = '<strong>[</strong>&nbsp;' . $lang['Category:'] . '<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;category=$category") .'">' . $category . '</a>'  . '&nbsp;<strong>]</strong>';
}
else
{
	$category = '';
	}
		 
	$time = create_date($board_config['default_dateformat'], $entry_data[$i]['entry_time'], $board_config['board_timezone']);

	$day2 = create_date("j", $entry_data[$i]['entry_time'], $board_config['board_timezone']);
	$month2 = create_date("n", $entry_data[$i]['entry_time'], $board_config['board_timezone']);
	$year2 = create_date("Y", $entry_data[$i]['entry_time'], $board_config['board_timezone']);

	$entry_access = $entry_data[$i]['entry_access'];

	$template->assign_block_vars('entryrow', array(
		'SUBJECT' => $entry_data[$i]['entry_subject'],
		'ENTRY' => $entry_data[$i]['entry_text'],
		'TIME_DATE' => $time,
		'MOOD' => $mood,
		'CURRENTLY' => $action,
		
		'CATEGORY' => $category,

		'LOCKED_ICON' => ( $entry_data[$i]['entry_access'] > WEBLOG_AUTH_ALL ) ? '<img src="weblogs/templates/' . $template_dir . '/images/lock.gif" border="0" alt="' . $lang['Restricted_access'] . '" title="' . $lang['Restricted_access'] . '" style="vertical-align: middle" />&nbsp;' . $weblog_auth_types[$entry_access] : '',
		'TRACKBACKS' => ( !$entry_data[$i]['no_replies'] ) ? sprintf($lang['Trackbacks'], $entry_data[$i]['entry_trackbacks']) : '',
		'U_TRACKBACKS' => ( !$entry_data[$i]['no_replies'] ) ? append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=" . $entry_data[$i]['entry_id'] . "&amp;tb=1") : '',
		'POSTED_BY' => ( !empty($entry_data[$i]['username']) ) ? sprintf($lang['Posted_by'], '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $entry_data[$i]['user_id']) . '">' . $entry_data[$i]['username'] . '</a>') : '',
		'EDIT_LINK' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? '<strong>[ <a href="' . append_sid ("weblog_posting.$phpEx?mode=editentry&amp;" . POST_ENTRY_URL . "=" . $entry_data[$i]['entry_id']) . '">' . $lang['Edit'] . '</a> ]</strong>' : '',
		'DELETE_LINK' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? '<strong>[ <a href="' . append_sid ("weblog_posting.$phpEx?mode=delete&amp;" . POST_ENTRY_URL . "=" . $entry_data[$i]['entry_id']) . '">X</a> ]</strong>' : '',
		'POST_COMMENT' => ( !$entry_data[$i]['no_replies'] ) ? sprintf($weblog_data['post_reply_text'], $entry_data[$i]['entry_replies']) : '',
		'REPLIES' => ( !$entry_data[$i]['no_replies'] ) ? sprintf($weblog_data['replies_text'], $entry_data[$i]['entry_replies']) : '',
		'OPEN_NEW_WINDOW' => ( $weblog_data['reply_in_popup'] ) ? ' onclick="window.open(\'' . append_sid('weblog_posting.' . $phpEx . '?mode=reply&amp;' . POST_ENTRY_URL . '=' . $entry_data[$i]['entry_id'] . '&amp;popup=1') . '\', \'_weblogcomment\', \'HEIGHT=640,resizable=no,scrollbars=yes,WIDTH=550\');return false;" target="_weblogcomment"' : '',
		'NUM_TRACKBACKS' => ( !$entry_data[$i]['no_replies'] ) ? $entry_data[$i]['entry_trackbacks'] : '',
		'TRACKBACK_IMG' => ( !$entry_data[$i]['no_replies'] ) ? '<img src="weblogs/templates/' . $template_dir . '/images/trackback.gif" border="0" alt="' . $lang['Trackback'] . '" title="' . $lang['Trackback'] . '" style="vertical-align: middle" />' : '',
		'EDIT_IMG' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? '<img src="weblogs/templates/' . $template_dir . '/images/edit.gif" border="0" alt="' . $lang['Edit'] . '" title="' . $lang['Edit'] . '" style="vertical-align: middle" />' : '',
		'DELETE_IMG' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? '<img src="weblogs/templates/' . $template_dir . '/images/delete.gif" border="0" alt="' . $lang['Delete'] . '" title="' . $lang['Delete'] . '" style="vertical-align: middle" />' : '',
		'U_EDIT' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? append_sid ("weblog_posting.$phpEx?mode=editentry&amp;" . POST_ENTRY_URL . "=" . $entry_data[$i]['entry_id']) : '',
		'U_DELETE' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? append_sid ("weblog_posting.$phpEx?mode=delete&amp;" . POST_ENTRY_URL . "=" . $entry_data[$i]['entry_id']) : '',
		'U_PERMALINK' => append_sid("weblog_entry.$phpEx?" . POST_ENTRY_URL . "=" . $entry_data[$i]['entry_id']),
		'U_VIEW_COMMENTS' => ( !$entry_data[$i]['no_replies'] ) ? append_sid('weblog_entry.' . $phpEx . '?' . POST_ENTRY_URL . '=' . $entry_data[$i]['entry_id']) : '',
		'U_POST_COMMENT' => ( !$entry_data[$i]['no_replies'] ) ? append_sid('weblog_posting.' . $phpEx . '?mode=reply&amp;' . POST_ENTRY_URL . '=' . $entry_data[$i]['entry_id']) : '')
	);
	$entries_processed++;
}

//
// Update the entry view counter
//
if ( !empty($update_sql) && !$db->sql_query($update_sql) )
{
	echo $update_sql;

	weblog_message_die(GENERAL_ERROR, "Could not update entry views.", '', __LINE__, __FILE__, $update_sql);
}

//
// Prepare the calendar - some parts were borrowed from the Calendar Mod by WebSnail
//
if ( $weblog_data['show_calendar'] )
{
	if ( !$day )
	{
		$day = create_date("j", time(), $board_config['board_timezone']);
	}

	if ( !$month )
	{
		$month = create_date("n", time(), $board_config['board_timezone']);
	}

	if ( !$year )
	{
		$year = create_date("Y", time(), $board_config['board_timezone']);
	}

	$firstday =  (date('w', (mktime(0,0,0,$month,1,$year)))) % 7;
	$firstday = ( $firstday < 0 ) ? ($firstday + 7) : $firstday;

	$lastday = date('t',  mktime(0,0,0,$month,1,$year));
	$end_day = 7 - (($firstday + $lastday) % 7);
	$end_day = ( $end_day == 7 ) ? 0 : $end_day;	// day 7 same as day 0

	// Make table cells for "empty" days (The blank squares in the calendar)
	for ( $i = 0; $i < $firstday; $i++ )
	{
		if ( !$weblog_data['weblog_advanced'] )
		{
			$template->assign_block_vars('switch_show_calendar.no_day', array());
		}
		else
		{
			$template->assign_block_vars('no_day', array());
		}
	}

	// Make table cells with numbers in them. Make a new line whenever all 7 spaces have been filled. Also, put a link if there was an entry on that day
	for ($currentday = 1; $currentday <= $lastday; $currentday++)
	{
		$entries_counted = 0;
		for ($i = 0; $i < count($entry_data); $i++)
		{
			if ( $currentday == create_date("j", $entry_data[$i]['entry_time'], $board_config['board_timezone']) && $month == create_date("n", $entry_data[$i]['entry_time'], $board_config['board_timezone']) && $year == create_date("Y", $entry_data[$i]['entry_time'], $board_config['board_timezone']))
				$entries_counted++;
		}

		if ( !$weblog_data['weblog_advanced'] )
		{
			$template->assign_block_vars('switch_show_calendar.day_cell', array(
				'DAY_CLASS' => ( $entries_counted != 0 ) ? 'daycell' : 'nodaycell',
				'NUM_DAY' => ( $entries_counted != 0 ) ? '<a href="weblog.' . $phpEx . '?' . POST_WEBLOG_URL . '=' . $weblog_data['weblog_id'] . '&amp;month=' . $month . '&amp;year=' . $year . '&amp;day=' . $currentday . '">' . $currentday . '</a>' : $currentday,
				'WEEK_ROW' => ( ($currentday + $firstday) % 7 == 0 ) ? '</tr><tr>' : '')
			);
		}
		else
		{
			$template->assign_block_vars('day_cell', array(
				'DAY_CLASS' => ( $entries_counter != 0 ) ? 'daycell' : 'nodaycell',
				'NUM_DAY' => ( $entries_counted != 0 ) ? '<a href="weblog.' . $phpEx . '?' . POST_WEBLOG_URL . '=' . $weblog_data['weblog_id'] . '&amp;month=' . $month . '&amp;year=' . $year . '&amp;day=' . $currentday . '">' . $currentday . '</a>' : $currentday,
				'WEEK_ROW' => ( ($currentday + $firstday) % 7 == 0 ) ? '</tr><tr>' : '')
			);
		}
	}

	// Make table cells for "empty" days (Fills in the last squares
	for ( $i = 0; $i < $end_day; $i++ )
	{
		if ( !$weblog_data['weblog_advanced'] )
		{
			$template->assign_block_vars('switch_show_calendar.no_day2', array());
		}
		else
		{
			$template->assign_block_vars('no_day2', array());
		}
	}

	// For use with the arrows next to the month/year.
	$nextmonth = ($month < 12) ? ($month + 1) : 1;
	$nextyear = $year + 1;

	$lastmonth = ($month > 1) ? ($month - 1) : 12;
	$lastyear = $year - 1;
}

if ( $weblog_data['show_weblog_info'] )
{
	// Get the total number of replies for this weblog.
	$sql = "SELECT count(r.reply_id) AS total
		FROM " . WEBLOGS_TABLE . " w, " . WEBLOG_ENTRIES_TABLE . " e, " . WEBLOG_REPLIES_TABLE . " r
		WHERE r.entry_id = e.entry_id
			AND e.weblog_id = w.weblog_id
			AND w.weblog_id = $weblog_id";
	if(!($result = $db->sql_query($sql)))
	{
		message_die(GENERAL_ERROR, 'Could not get total number of replies information', '', __LINE__, __FILE__, $sql);
	}

	if ( $row = $db->sql_fetchrow($result) )
	{
		$num_replies = $row['total'];
	}
}

//
// Prepare the Shoutbox!
//
if ( $weblog_data['show_shoutbox'] )
{
	$shout_data = array();

	if ( $weblog_data['weblog_shoutbox_desc'] )
	{
		$order = 'DESC';
	}
	else
	{
		$order = 'ASC';
	}

	//
	// Get shouts information
	//
	$sql = "SELECT s.*, u.username FROM " . WEBLOG_SHOUTBOX_TABLE . " s, " . USERS_TABLE . " u WHERE s.shout_poster = u.user_id AND s.shout_weblog = $weblog_id ORDER BY s.shout_time $order LIMIT 10";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't obtain shoutbox information.", "", __LINE__, __FILE__, $sql);
	}

	$shout_data = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$shout_data[] = $row;
	}

	for ( $i = 0; $i < count($shout_data); $i++ )
	{
		$poster_id = $shout_data[$i]['shout_poster'];
		$poster = ( $poster_id == ANONYMOUS ) ? $lang['Guest'] : $shout_data[$i]['username'];
		$bbcode_uid = $shout_data[$i]['bbcode_uid'];
		$post_date = create_date($board_config['default_dateformat'], $shout_data[$i]['shout_time'], $board_config['board_timezone']);

		//
		// Handle anon users posting with usernames
		//
		if ( $poster_id == ANONYMOUS && $shout_data[$i]['shout_username'] != '' )
		{
			$poster = $shout_data[$i]['shout_username'];
			$poster_age = '';
		}

		//
		// Note! The order used for parsing the message _is_ important, moving things around could break any
		// output
		//
		$message = $shout_data[$i]['shout_text'];

		//
		// If the board has HTML off but the post has HTML
		// on then we process it, else leave it alone
		//
		if ( !$board_config['allow_html'] )
		{
			$message = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $message);
		}

		//
		// Parse message and/or sig for BBCode if reqd
		//
		if ( $board_config['allow_bbcode'] )
		{
			if ( $bbcode_uid != '' )
			{
				$message = bbencode_second_pass($message, $bbcode_uid);
			}
			else
			{
				$message = preg_replace('/\:[0-9a-z\:]+\]/si', ']', $message);
			}
		}

		$message = make_clickable($message);


		//
		// Parse smilies
		//
		if ( $board_config['allow_smilies'] )
		{
			$message = smilies_pass($message);
		}

		if ( $weblog_config['censor_weblog'] )
		{
			//
			// Replace naughty words
			//
			if (count($orig_word))
			{
				$message = str_replace('\"', '"', substr(preg_replace('#(\>(((?>([^><]+|(?R)))*)\<))#se', "preg_replace(\$orig_word, \$replacement_word, '\\0')", '>' . $message . '<'), 1, -1));
			}
		}

		//
		// Replace newlines (we use this rather than nl2br because
		// till recently it wasn't XHTML compliant)
		//
		$message = str_replace("\n", "\n<br />\n", $message);
	
		$row_class = ( $i % 2 ) ? ' class="row2"' : ' class="row1"';
	
		$template->assign_block_vars('switch_shoutbox.shoutrow', array(
			'DELETE_SHOUT' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? '<div style="float: right; font-weight: bold">[&nbsp;<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;d=" . $shout_data[$i]['shout_id']) . '">X</a>&nbsp;]</div>' : '',
			'U_DELETE' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] ) ? append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;d=" . $shout_data[$i]['shout_id']) : '',
			'DELETE_IMG' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? '<img src="weblogs/templates/' . $template_dir . '/images/delete.gif" border="0" alt="' . $lang['Delete'] . '" title="' . $lang['Delete'] . '" style="vertical-align: middle; float: right" />' : '',
			'ROW_CLASS' => $row_class,
			'POSTER' => ( $poster_id == ANONYMOUS ) ? '<a href="' . $shout_data[$i]['shout_www'] . '">' . $poster . '</a>' : '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$poster_id") . '">' . $poster . '</a>',
			'MESSAGE' => $message,
			'TIME_DATE' => $post_date)
		);

		$template->assign_block_vars('shoutrow', array(
			'DELETE_SHOUT' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] ) ? '<div style="float: right; font-weight: bold">[&nbsp;<a href="' . append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;d=" . $shout_data[$i]['shout_id']) . '">X</a>&nbsp;]</div>' : '',
			'U_DELETE' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] ) ? append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;d=" . $shout_data[$i]['shout_id']) : '',
			'DELETE_IMG' => ( $weblog_data['weblog_id'] == $userdata['user_weblog'] || $contributor ) ? '<img src="weblogs/templates/' . $template_dir . '/images/delete.gif" border="0" alt="' . $lang['Delete'] . '" title="' . $lang['Delete'] . '" style="vertical-align: middle; float: right" />' : '',
			'ROW_CLASS' => $row_class,
			'POSTER' => ( $poster_id == ANONYMOUS ) ? '<a href="' . $shout_data[$i]['shout_www'] . '">' . $poster . '</a>' : '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$poster_id") . '">' . $poster . '</a>',
			'MESSAGE' => $message,
			'TIME_DATE' => $post_date)
		);

	}

	if ( count ($shout_data) == 0 )
	{
		$template->assign_block_vars('switch_shoutbox.switch_no_shouts', array());
		$template->assign_block_vars('switch_no_shouts', array());
	}

	if ( !$userdata['session_logged_in'] )
	{
		$template->assign_block_vars('switch_shoutbox.switch_user_logged_out', array());
	}
	else
	{
		$template->assign_block_vars('switch_shoutbox.switch_user_logged_in', array());
	}
}

//
// Generate page
//

// CategoryAddon courtesy by TheBlogMod.com
if ($theCategory !=""){
	$categoryLink = '&amp;category=' .$theCategory;
	}


$template->assign_vars(array(
	'POST_ENTRY_IMG' => 'weblogs/templates/' . $template_dir . '/lang_' . $use_lang . '/newentry.gif',
	'WEBLOG_ID' => $weblog_data['weblog_id'],
	'WEBLOG_NAME' => $weblog_data['weblog_name'],
	'WEBLOG_DESCRIPTION' => $weblog_data['weblog_desc'],
	'WEBLOG_OWNER' => $weblog_data['username'],
	'JOINED_DATE' => 		( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? create_date ($board_config['default_dateformat'], $weblog_data['user_regdate'], $board_config['board_timezone']) : '',
	'LOCATION' => 		( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? $weblog_data['user_from'] : '',
	'OCCUPATION' => 		( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? $weblog_data['user_occ'] : '',
	'INTERESTS' => 		( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? $weblog_data['user_interests'] : '',
	'STARTED_DATE' => 	( $weblog_data['weblog_advanced'] || $weblog_data['show_weblog_info'] ) ? create_date ($board_config['default_dateformat'], $weblog_data['weblog_create_date'], $board_config['board_timezone']) : '',
	'NUMBER_OF_VISITS' => 	( $weblog_data['weblog_advanced'] || $weblog_data['show_weblog_info'] ) ? $weblog_data['weblog_views'] : '',
	'NUMBER_OF_ENTRIES' =>	( $weblog_data['weblog_advanced'] || $weblog_data['show_weblog_info'] ) ? $weblog_data['weblog_entries'] : '',
	'NUMBER_OF_REPLIES' =>	( $weblog_data['weblog_advanced'] || $weblog_data['show_weblog_info'] ) ? $num_replies : '',
	'WEBLOG_AGE' => 		( $weblog_data['weblog_advanced'] || $weblog_data['show_weblog_info'] ) ? sprintf ( $lang['Weblog_age_days'], intval( (time() - $weblog_data['weblog_create_date'])/(60*60*24) ) ) : '',
	'CONTACT_OWNER' => sprintf ($lang['Contact_owner'], $weblog_data['username']),
	'ABOUT_OWNER' => sprintf ($lang['About_owner'], $weblog_data['username']),
	'AVATAR_IMG' => ( $avatar_img ) ? '<br />' . $avatar_img . '<br />' : '',
	'MONTH' => $months[$month-1],
	'YEAR' => $year,
	'EMAIL' =>         ( ($weblog_data['weblog_advanced'] || $weblog_data['show_profile_info']) && (!empty($weblog_data['user_viewemail']) || $userdata['user_level'] == ADMIN ) ) ? $weblog_data['user_email'] : '',
	'MSN_MESSENGER' => 	( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? $msn : '',
	'YAHOO_MESSENGER' => 	( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? $yim : '',
	'AOL_MESSENGER' => 	( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? $aim : '',
	'ICQ_NUMBER' => 		( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? $icq : '',
	'WEBSITE' => 		( $weblog_data['weblog_advanced'] || $weblog_data['show_profile_info'] ) ? $www_url : '',
	'S_SHOUT_ACTION' => append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id"),
	'CONTRIBUTORS' =>		$contributors,
	'S_FORM_ACTION' => append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=$weblog_id"),
	'DATE_SELECT' => make_date_select ( $year, $month, $day ),
	'S_HIDDEN_FIELD' => '<input type="hidden" name="w" value="' . $weblog_id . '" />',

	'L_CONTRIBUTORS' => $lang['Contributors'],
	'L_EDIT_CONTRIBUTORS' => $lang['Edit_contributors'],
	'L_DISABLE_HTML' => $lang['Disable_HTML_post'], 
	'L_DISABLE_BBCODE' => $lang['Disable_BBCode_post'], 
	'L_DISABLE_SMILIES' => $lang['Disable_Smilies_post'], 
	'L_NO_SHOUTS' => $lang['No_shouts'],
	'L_CALENDAR' => ( $weblog_data['show_calendar'] ) ? $lang['Calendar'] : '',
	'L_MOOD' => $lang['Mood'],
	'L_CURRENTLY' => $lang['Currently'],
	'L_WEBLOG_OWNER' => $lang['Weblog_Owner'],
	'L_WEBLOG' => $lang['Weblog'],
	'L_GO' => $lang['Go'],
	'L_WEBLOG_STARTED' => $lang['Start_date'],
	'L_VIEW_ALL_ENTRIES' => $lang['View_all_entries'],
	'L_EMAIL_ADDRESS' => 	$lang['Email_address'],
	'L_PRIVATE_MESSAGE' => 	$lang['Private_Message'],
	'L_MSN_MESSENGER' => 	$lang['MSNM'],
	'L_YAHOO_MESSENGER' => 	$lang['YIM'],
	'L_AIM_ADDRESS' => 	$lang['AIM'],
	'L_ICQ_NUMBER' => 	$lang['ICQ'],
	'L_WEBSITE' =>		$lang['Website'],
	'L_JOINED' => 		$lang['Joined'],
	'L_LOCATION' => 		$lang['Location'],
	'L_OCCUPATION' => 	$lang['Occupation'],
	'L_INTERESTS' => 		$lang['Interests'],
	'L_TOTAL_ENTRIES' => 	$lang['Total_entries'],
	'L_WEBLOG_AGE' => 	$lang['Weblog_age'],
	'L_FRIENDS_LIST' => 	( $userdata['user_showfriends'] ) ? $lang['Friends_list'] : '',
	'L_BLOCKED_LIST' => 	$lang['Blocked_list'],
	'L_SEND_PM' => $lang['Send_private_message'],
	'L_EMAIL' => $lang['Email'],
	'L_INDEX' => sprintf($lang['Forum_Index'], $board_config['sitename']),
	'L_REPLIES' => $lang['Replies'],
	'L_TOTAL_REPLIES' => $lang['Total_replies'],
	'L_VISITS' => $lang['Visits'],
	'L_POST_NEW_ENTRY' => ( $userdata['user_id'] == $weblog_data['user_id'] || $contributor ) ? $lang['Post_new_entry'] : '',
	'L_COMMENT_ON_ENTRY' => $lang['Comment_on_entry'],
	'L_VIEW_COMMENTS' => $lang['View_comments'],
	'L_RSS' => $lang['RSS'],
	'L_WEBLOG_CP' => $lang['Weblog_CP'],
	'L_SHOUTBOX' => $lang['Shoutbox'],
	'L_SHOUT' => $lang['Shout'],
	'L_SUBMIT' => $lang['Submit'],
	'L_RESET' => $lang['Reset'],
	'L_NAME' => $lang['Username'],
	'L_VIEW_SMILIES' => $lang['View_smilies'],
	'L_PERMALINK' => $lang['Permalink'],

	'U_CONTRIBUTORS' => append_sid("weblog_contributors.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']),
	'U_VIEW_SMILIES' => append_sid("posting.$phpEx?mode=smilies"),
	'U_INDEX' => append_sid("index.$phpEx"),
	'U_FORWARD' => ( $previous != 0 ) ? '<a href="weblog.php?' . POST_WEBLOG_URL . '=' . $weblog_data['weblog_id'] . '&amp;previous=' . ($previous - $weblog_data['entries_perpage']) . $categoryLink . '" class="nav">' . $lang['Forward'] . '</a>' : $lang['Forward'],
	'U_BACK' => ( ($previous + $weblog_data['entries_perpage']) < count($entry_data) ) ? '<a href="weblog.php?' . POST_WEBLOG_URL . '=' . $weblog_data['weblog_id'] . '&amp;previous=' . ($previous + $weblog_data['entries_perpage']) . $categoryLink . '" class="nav">' . $lang['Back'] . '</a>' : $lang['Back'],
	'U_PROFILE' => append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $weblog_data['user_id']),
	'U_SEND_EMAIL' => ( $weblog_data['show_contact_info'] ) ? $email_url : '',
	'U_SEND_PRIVATE_MESSAGE' => ( $weblog_data['show_contact_info'] && !empty($pm_url) ) ? $pm_url : '',
	'U_WEBSITE' => ( $weblog_data['show_contact_info'] && !empty($www_url) ) ? $www_url : '',
	'U_ICQ' => ( $weblog_data['show_contact_info'] && !empty($icq_url) ) ? $icq_url : '',
	'U_AIM' => ( $weblog_data['show_contact_info'] && !empty($aim_url) ) ? $aim_url : '',
	'U_YIM' => ( $weblog_data['show_contact_info'] && !empty($yim_url) ) ? $yim_url : '',
	'U_WEBLOG' => append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']),
	'U_WEBLOG_CP' => append_sid("weblog_config.$phpEx"),
	'U_POST_ENTRY' => ( $userdata['user_id'] == $weblog_data['user_id'] || $contributor ) ? append_sid("weblog_posting.$phpEx?mode=newentry&amp;" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']) : '',
	'U_ALL_ENTRIES' => append_sid("weblog_allentries.$phpEx?" . POST_WEBLOG_URL . '=' . $weblog_data['weblog_id']),
	'U_RSS_FEED' => 		append_sid("weblog_rss.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id']),
	'U_FRIENDS_LIST' => 	( $userdata['user_showfriends'] ) ? append_sid("weblog_friends.$phpEx?" . POST_USERS_URL . "=" . $weblog_data['user_id']) : '',
	'U_BLOCKED_LIST' =>	( $userdata['user_id'] == $weblog_data['user_id'] || $contributors ) ? append_sid("weblog_blocked.$phpEx?" . POST_USERS_URL . "=" . $weblog_data['user_id']) : '',
	'U_PREVIOUS_MONTH' => 	( $month == 1 ) ? append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;previous=$previous&amp;month=$lastmonth&amp;year=$lastyear") : append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;previous=$previous&amp;month=$lastmonth&amp;year=$year"),
	'U_NEXT_MONTH' => 	( $month == 12 ) ? append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;previous=$previous&amp;month=$nextmonth&amp;year=$nextyear") : append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;previous=$previous&amp;month=$nextmonth&amp;year=$year"),
	'U_PREVIOUS_YEAR' => 	append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;previous=$previous&amp;month=$month&amp;year=$lastyear"),
	'U_NEXT_YEAR' => 		append_sid("weblog.$phpEx?" . POST_WEBLOG_URL . "=" . $weblog_data['weblog_id'] . "&amp;previous=$previous&amp;month=$month&amp;year=$nextyear"))
);

$template->assign_vars(array(
	'L_POWERED_BY' => sprintf($lang['Weblog_powered_by'], WEBLOGS_MOD_VERSION))
);

//
// Generate the page
//
if ( $weblog_data['font'] >= 0 && $weblog_data['font'] < NUM_WEBLOG_FONTS )
{
	$font = $weblog_fonts[$weblog_data['font']];
}
else
{
	$font = $weblog_fonts[0];
}

if ( $weblog_config['censor_weblog'] )
{
	// Define censored word matches
	$orig_word = array();
	$replacement_word = array();
	obtain_word_list($orig_word, $replacement_word);
}

if ( (!empty($weblog_data['custom_block_title']) || !empty($weblog_data['custom_block'])) && !$weblog_data['weblog_advanced'] )
{
	// BBCode
	if ( $board_config['allow_bbcode'] )
	{
		$weblog_data['custom_block'] = ( $weblog_data['cblock_bbcode_uid'] ) ? bbencode_second_pass($weblog_data['custom_block'], $weblog_data['cblock_bbcode_uid']) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $weblog_data['custom_block']);
	}

	if ( $board_config['allow_smilies'] )
	{
		$weblog_data['custom_block'] = smilies_pass($weblog_data['custom_block']);
	}

	// Censor text and title
	if (count($orig_word))
	{
		$weblog_data['custom_block'] = preg_replace($orig_word, $replacement_word, $weblog_data['custom_block']);
		$weblog_data['custom_block_title'] = preg_replace($orig_word, $replacement_word, $weblog_data['custom_block_title']);
	}

	$weblog_data['custom_block'] = str_replace("\n", "\n<br />\n", $weblog_data['custom_block']);

	$template->assign_block_vars('custom_block', array());
}
$template->assign_vars(array(
	'BACKGROUND_COLOR' => $weblog_data['background_color'],
	'ENTRY_BG_COLOR' => $weblog_data['entry_bg_color'],
	'BORDER_COLOR' => $weblog_data['border_color'],
	'BACKGROUND_IMAGE' => $weblog_data['background_image'],
	'BACKGROUND_IMAGE_FIXED' => ( $weblog_data['background_image_fixed'] ) ? 'fixed' : 'scroll',
	'BACKGROUND_REPEAT' => $weblog_data['tile_bg'],
	'BACKGROUND_POSITION' => $weblog_data['bg_ypos'] . ' ' . $weblog_data['bg_xpos'],
	'SB_FACE_COLOR' => $weblog_data['sb_face_color'],
	'SB_HIGHLIGHT_COLOR' => $weblog_data['sb_highlight_color'],
	'SB_SHADOW_COLOR' => $weblog_data['sb_shadow_color'],
	'SB_3DLIGHT_COLOR' => $weblog_data['sb_3dlight_color'],
	'SB_ARROW_COLOR' => $weblog_data['sb_arrow_color'],
	'SB_TRACK_COLOR' => $weblog_data['sb_track_color'],
	'SB_DARKSHADOW_COLOR' => $weblog_data['sb_darkshadow_color'],
	'FONT' => $font,
	'FONT_COLOR' => $weblog_data['font_color'],
	'FONT_SIZE' => $weblog_data['font_size'],
	'NORMAL_LINK_COLOR' => $weblog_data['normal_link_color'],
	'NORMAL_LINK_UNDERLINED' => ( $weblog_data['normal_link_underline'] ) ? 'underline' : 'none',
	'ACTIVE_LINK_COLOR' => $weblog_data['active_link_color'],
	'ACTIVE_LINK_UNDERLINED' => ( $weblog_data['active_link_underline'] ) ? 'underline': 'none',
	'HOVER_LINK_COLOR' => $weblog_data['hover_link_color'],
	'HOVER_LINK_UNDERLINED' => ( $weblog_data['hover_link_underline'] ) ? 'underline': 'none',
	'VISITED_LINK_COLOR' => $weblog_data['visited_link_color'],
	'VISITED_LINK_UNDERLINED' => ( $weblog_data['visited_link_underline'] ) ? 'underline': 'none',
	'WEBLOG_TITLE_COLOR' => $weblog_data['weblog_title_color'],
	'WEBLOG_TITLE_FONT_SIZE' => $weblog_data['weblog_title_font_size'],
	'ENTRY_TITLE_COLOR' => $weblog_data['entry_title_color'],
	'ENTRY_TITLE_FONT_SIZE' => $weblog_data['entry_title_font_size'],
	'DATE_TIME_COLOR' => $weblog_data['date_time_color'],
	'DATE_TIME_FONT_SIZE' => $weblog_data['date_time_font_size'],
	'BLOCK_TITLE_COLOR' => $weblog_data['block_title_color'],
	'BLOCK_TITLE_FONT_SIZE' => $weblog_data['block_title_font_size'],
	'BLOCK_BG_COLOR' => $weblog_data['block_bg_color'],
	'BLOCK_BORDER_COLOR' => $weblog_data['block_border_color'],
	'CUSTOM_BLOCK_TITLE' => ( $weblog_data['custom_block_title'] && $weblog_data['custom_block'] ) ? (( $weblog_config['censor_weblog'] ) ? preg_replace($orig_word, $replacement_word, $weblog_data['custom_block_title']) : $weblog_data['custom_block_title']) : '',
	'S_CUSTOM_BLOCK' => ( $weblog_data['custom_block_title'] && $weblog_data['custom_block'] ) ? $weblog_data['custom_block'] : '')
);
	

$template->pparse('body');
if ( !$weblog_data['weblog_advanced'] )
{
	$template->pparse('footer');
}

use_weblog_footer ( $weblog_data, $template_dir, FALSE );

?>