<?php
/***************************************************************************
 *                               db_update.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *   project              : http://sourceforge.net/projects/dbgenerator
 *   Website              : http://freakingbooty.no-ip.com/ & http://www.rapiddr3am.net
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=db_update.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<table width="100%" cellspacing="1" cellpadding="2" border="0" class="forumline">';
echo '<tr><th>Updating the database</th></tr><tr><td><span class="genmed"><ul type="circle">';


$sql = array();
$sql[] = "ALTER TABLE " . $table_prefix . "groups ADD group_allow_weblogs TINYINT(1) UNSIGNED NOT NULL DEFAULT '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "users ADD user_allowweblog TINYINT(1) UNSIGNED NOT NULL DEFAULT '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "users ADD user_allowadvweblog TINYINT(1) UNSIGNED NOT NULL DEFAULT '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "users ADD user_showfriends TINYINT(1) UNSIGNED NOT NULL DEFAULT '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "users ADD user_weblog MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0'";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_actions (
	action_id SMALLINT(5) UNSIGNED DEFAULT '0' NOT NULL,
	action_text VARCHAR(50) DEFAULT '',
	action_url VARCHAR(100) DEFAULT '',
	PRIMARY KEY (action_id)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_blocked (
	owner_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	blocked_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (owner_id, blocked_id)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_config (
	config_name VARCHAR(255) NOT NULL DEFAULT '',
	config_value VARCHAR(255) NOT NULL DEFAULT '',
	PRIMARY KEY (config_name)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_contributors (
	weblog_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	user_id MEDIUMINT(8) NOT NULL DEFAULT '0',
	PRIMARY KEY (weblog_id, user_id)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_entries (
	entry_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	weblog_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	entry_access TINYINT(4) UNSIGNED NOT NULL DEFAULT '0',
	entry_subject VARCHAR(60) NOT NULL DEFAULT '',
	entry_text TEXT NOT NULL DEFAULT '',
	bbcode_uid VARCHAR(10) NOT NULL DEFAULT '',
	entry_mood SMALLINT(5) NOT NULL DEFAULT '0',
	entry_currently SMALLINT(5) NOT NULL DEFAULT '0',
	currently_text VARCHAR(60) NOT NULL DEFAULT '',
	entry_time INT(11) NOT NULL DEFAULT '0',
	entry_views MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	enable_bbcode TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	enable_smilies TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	enable_html TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	memorable TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	no_replies TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	entry_replies MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	entry_last_post_userid MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	entry_last_post_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	entry_poster_id MEDIUMINT(8) NOT NULL DEFAULT '0',
	entry_trackbacks SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	entry_deleted TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (entry_id),
	KEY (weblog_id),
	KEY (entry_last_post_userid),
	KEY (entry_last_post_id),
	KEY (entry_poster_id)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_friends (
	owner_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	friend_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (owner_id, friend_id)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_mood_sets (
	set_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	set_name VARCHAR (255) NOT NULL DEFAULT '',
	PRIMARY KEY (set_id)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_moods (
	mood_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	mood_text VARCHAR (255) NOT NULL DEFAULT '',
	mood_url VARCHAR (255) NOT NULL DEFAULT '',
	mood_set MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (mood_id),
	KEY (mood_set)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_replies (
	reply_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	entry_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	poster_id MEDIUMINT(8) NOT NULL DEFAULT '0',
	post_time INT(11),
	post_username VARCHAR(25) NOT NULL DEFAULT '',
	post_subject VARCHAR (60) NOT NULL DEFAULT '',
	enable_bbcode TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	enable_smilies TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	enable_html TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	enable_sig TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	reply_text TEXT NOT NULL DEFAULT '',
	bbcode_uid VARCHAR(10) NOT NULL DEFAULT '',
	PRIMARY KEY (reply_id),
	KEY (entry_id),
	KEY (poster_id)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_shoutbox (
	shout_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	shout_weblog MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	shout_text TEXT NOT NULL DEFAULT '',
	shout_poster MEDIUMINT(8) NOT NULL DEFAULT '0',
	shout_username VARCHAR(25) NOT NULL DEFAULT '',
	bbcode_uid VARCHAR (10) NOT NULL DEFAULT '',
	shout_time INT(11) NOT NULL DEFAULT '0',
	shout_www VARCHAR (100) NOT NULL DEFAULT '',
	PRIMARY KEY (shout_id),
	KEY (shout_weblog),
	KEY (shout_poster)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_templates (
	template_id SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	template_name VARCHAR(100) NOT NULL DEFAULT '',
	template_dir VARCHAR (100) NOT NULL DEFAULT '',
	template_private TINYINT(1) NOT NULL DEFAULT '0',
	PRIMARY KEY (template_id)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblog_trackbacks (
	tb_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	tb_entry MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	tb_blog VARCHAR (255) NOT NULL DEFAULT '',
	tb_time INT(11) NOT NULL DEFAULT '0',
	tb_excerpt VARCHAR(255) NOT NULL DEFAULT '',
	tb_url VARCHAR(255) NOT NULL DEFAULT '',
	tb_title VARCHAR(255) NOT NULL DEFAULT '',
	PRIMARY KEY (tb_id),
	KEY (tb_entry)
)";
$sql[] = "CREATE TABLE " . $table_prefix . "weblogs (
	weblog_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	template_id SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	weblog_name VARCHAR(60) NOT NULL DEFAULT '',
	weblog_desc VARCHAR(255) NOT NULL DEFAULT '',
	weblog_auth TINYINT(4) UNSIGNED NOT NULL DEFAULT '0',
	replies_auth TINYINT(4) UNSIGNED NOT NULL DEFAULT '0',
	weblog_entries MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	entries_perpage SMALLINT(5)  UNSIGNED NOT NULL DEFAULT '5',
	post_reply_text VARCHAR(60) NOT NULL DEFAULT '',
	replies_text VARCHAR(60) NOT NULL DEFAULT '',
	weblog_create_date INT(11) NOT NULL DEFAULT '0',
	weblog_views MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	weblog_advanced TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	weblog_shoutbox_desc TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	show_profile_info TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	show_calendar TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	show_contact_info TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	show_weblog_info TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	show_shoutbox TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	reply_in_popup TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	deleted TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	weblog_last_entry_id MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	mood_set MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	custom_block TEXT NOT NULL DEFAULT '',
	custom_block_title VARCHAR (64) NOT NULL DEFAULT '',
	background_color VARCHAR(6) NOT NULL DEFAULT '',
	entry_bg_color VARCHAR(6) NOT NULL DEFAULT '',
	border_color VARCHAR(6) NOT NULL DEFAULT '',
	background_image VARCHAR(255) NOT NULL DEFAULT '',
	background_image_fixed TINYINT(1) NOT NULL DEFAULT '0',
	tile_bg VARCHAR(9) NOT NULL DEFAULT '',
	sb_face_color VARCHAR(6) NOT NULL DEFAULT '',
	sb_highlight_color VARCHAR(6) NOT NULL DEFAULT '',
	sb_shadow_color VARCHAR(6) NOT NULL DEFAULT '',
	sb_3dlight_color VARCHAR(6) NOT NULL DEFAULT '',
	sb_arrow_color VARCHAR(6) NOT NULL DEFAULT '',
	sb_track_color VARCHAR(6) NOT NULL DEFAULT '',
	sb_darkshadow_color VARCHAR(6) NOT NULL DEFAULT '',
	font SMALLINT(5) NOT NULL DEFAULT '0',
	font_color VARCHAR(6) NOT NULL DEFAULT '000000',
	font_size TINYINT(2) NOT NULL DEFAULT '0',
	normal_link_color VARCHAR(6) NOT NULL DEFAULT '',
	active_link_color VARCHAR(6) NOT NULL DEFAULT '',
	hover_link_color VARCHAR(6) NOT NULL DEFAULT '',
	visited_link_color VARCHAR(6) NOT NULL DEFAULT '',
	weblog_title_color VARCHAR(6) NOT NULL DEFAULT '',
	entry_title_color VARCHAR(6) NOT NULL DEFAULT '',
	date_time_color VARCHAR(6) NOT NULL DEFAULT '',
	block_title_color VARCHAR(6) NOT NULL DEFAULT '',
	block_bg_color VARCHAR(6) NOT NULL DEFAULT '',
	block_border_color VARCHAR(6) NOT NULL DEFAULT '',
	bg_ypos VARCHAR(6) NOT NULL DEFAULT '',
	bg_xpos VARCHAR(6) NOT NULL DEFAULT '',
	normal_link_underline TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	active_link_underline TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	hover_link_underline TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	visited_link_underline TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	weblog_title_font_size TINYINT(2) UNSIGNED NOT NULL DEFAULT '16',
	entry_title_font_size TINYINT(2) UNSIGNED NOT NULL DEFAULT '12',
	date_time_font_size TINYINT(2) UNSIGNED NOT NULL DEFAULT '14',
	block_title_font_size TINYINT(2) UNSIGNED NOT NULL DEFAULT '14',
	cblock_bbcode_uid VARCHAR(10) NOT NULL DEFAULT '',
	PRIMARY KEY (weblog_id),
	KEY (template_id),
	KEY (mood_set)
)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_actions (action_id, action_text, action_url) VALUES (1, 'Eating', 'action_eat.gif')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_actions (action_id, action_text, action_url) VALUES (2, 'Listening to', 'action_listen.gif')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_actions (action_id, action_text, action_url) VALUES (3, 'Playing', 'action_play.gif')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_actions (action_id, action_text, action_url) VALUES (4, 'Reading', 'action_read.gif')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_actions (action_id, action_text, action_url) VALUES (5, 'Watching', 'action_watch.gif')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_actions (action_id, action_text, action_url) VALUES (6, 'Working', 'action_work.gif')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('enable_mod', 1)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('no_avatars_index', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('default_name', '%s\'s blog')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('default_desc', 'Welcome to my Blog')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('main_sorttype', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('main_sortorder', 'desc')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('main_blogsperpage', 10)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('use_default_faceplates', 1)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('condense_index', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('censor_weblog', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('default_auth', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('default_reply_auth', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('default_entries_perpage', 5)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('require_auth', 1)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('default_post_reply_text', '(Post your comment)')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('default_replies_text', '%s Comments')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('index_list_by_username', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('shoutbox_flood_delay', 15)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('max_pic_width', 500)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('max_pic_height', 500)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('max_pic_size', 131072)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_config (config_name, config_value) VALUES ('pic_upload_enabled', 1)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_mood_sets (set_id, set_name) VALUES (0, 'Default Set')";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (1, 'Angelic', 'mood_angelic.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (2, 'Confused', 'mood_confused.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (3, 'Cool', 'mood_cool.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (4, 'Silly', 'mood_silly.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (5, 'Very Sad', 'mood_verysad.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (6, 'Shocked', 'mood_shocked.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (7, 'Evil', 'mood_evil.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (8, 'In Love', 'mood_love.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (9, 'Amused', 'mood_amused.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (10, 'Angry', 'mood_angry.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (11, 'Neutral', 'mood_neutral.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (12, 'Sick', 'mood_sick.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (13, 'Scared', 'mood_scared.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (14, 'Happy', 'mood_happy.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (15, 'Fed Up WIth Life', 'mood_fedup.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (16, 'Distorted', 'mood_distorted.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (17, 'Hypnotized', 'mood_hypnotized.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (18, 'Embarrased', 'mood_embarrased.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_moods (mood_id, mood_text, mood_url, mood_set) VALUES (19, 'Sleepy', 'mood_sleepy.gif', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "weblog_templates (template_id, template_name, template_dir) VALUES (1, 'Infinity', 'Infinity')";
$sql[] = "--
-- Dumping table for category
--
ALTER TABLE `" . $table_prefix . "weblog_entries` ADD `category` VARCHAR( 60 ) NOT NULL DEFAULT ''";
$sql[] = "--
-- Dumping table for weblogs news
--
INSERT INTO `" . $table_prefix . "weblog_config` ( `config_name` , `config_value` )
VALUES (
'hot_level', '5'
)";
$sql[] = "INSERT INTO `" . $table_prefix . "weblog_config` ( `config_name` , `config_value` )
VALUES (
'latest_entry_max', '5'
)";
$sql[] = "INSERT INTO `" . $table_prefix . "weblog_config` ( `config_name` , `config_value` )
VALUES (
'latest_reply_max', '10'
)";
$sql[] = "INSERT INTO `" . $table_prefix . "weblog_config` ( `config_name` , `config_value` )
VALUES (
'show_action', '1'
)";
$sql[] = "INSERT INTO `" . $table_prefix . "weblog_config` ( `config_name` , `config_value` )
VALUES (
'show_comments', '1'
)";
$sql[] = "INSERT INTO `" . $table_prefix . "weblog_config` ( `config_name` , `config_value` )
VALUES (
'show_latest_entries', '1'
)";
$sql[] = "INSERT INTO `" . $table_prefix . "weblog_config` ( `config_name` , `config_value` )
VALUES (
'show_latest_replies', '1'
)";
$sql[] = "INSERT INTO `" . $table_prefix . "weblog_config` ( `config_name` , `config_value` )
VALUES (
'no_blocks_text', 'The Administrator of this website has chosen not to show any blocks on this page'
)";

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successfull</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>End</th></tr><tr><td><span class="genmed">Installation is now finished. Please be sure to delete this file now.<br />If you have run into any errors, please visit the <a href="http://www.phpbbsupport.co.uk" target="_phpbbsupport">phpBBSupport.co.uk</a> and ask someone for help.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Have a nice day</a></span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>